"""One bounded prospective native-record fidelity diagnostic, not an efficacy pass."""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
import os,subprocess,sys,time,zipfile

from flash_study import MODELS,THREADS,read,save,digest,scan
from kaji_langgraph.evaluation import code_digest
import catalogued_readiness as native


def prepare(root):
    assert not (root/'protocol.json').exists()
    entry=read(root/'review-disposition.json')
    assert entry['native_diagnostic_justified'] is True
    previous=read(Path('artifacts/catalogued-readiness-20261105-v2/protocol.json'))
    root.mkdir(exist_ok=True)
    plan=Path(previous['reused_glm_plan']['path'])
    (root/'glm-plan').mkdir()
    save(root/'glm-plan/result.json',read(plan))
    helpers=['evaluation/catalogued_readiness.py','evaluation/flash_study.py','evaluation/runtime_pilot.py','evaluation/flash_component_diagnostic.py']
    config=previous['config']
    config['model'].pop('name',None)  # Actual backends are selected explicitly from MODELS.
    config['model']['assessment_mode']='catalogued'
    p={'models':MODELS,'caps':{'ollama':2,'jev':2},'num_predict':6144,
       'source_sha256':code_digest(),'runner_sha256':digest(Path(__file__)),
       'helpers_sha256':{h:digest(Path(h)) for h in helpers},'config':config,
       'source_result':previous['source_result'],'source_result_sha256':previous['source_result_sha256'],
       'anchor':previous['anchor'],'plans':previous['plans'],
       'reused_glm_plan':{'path':plan.as_posix(),'sha256':digest(plan),'retained_copy_sha256':digest(root/'glm-plan/result.json')},
       'schedule':[{'id':'glm-anchor','model':'glm','kind':'anchor'},
                   {'id':'deepseek-plan','model':'deepseek','kind':'plan'},
                   {'id':'deepseek-anchor','model':'deepseek','kind':'anchor'}],
       'planned_max_sends':{'ollama':5,'jev':4,'search':0,'fetch':0},
       'requested_output_token_cap_total':26624,
       'aggregate_job_seconds_cap':900,
       'assessment_reasoning':entry.get('assessment_reasoning',{'glm':'low','deepseek':False}),
       'review_disposition_sha256':digest(root/'review-disposition.json'),
       'review_report':entry['review_report'],'review_report_sha256':digest(Path(entry['review_report'])),
       'authority_sha256':digest(root/'diagnostic-authority.json'),
       'criterion':entry['criterion'],
       'operations':'One worker, two numerical threads,300s/job. GLM native audit before DS plan, plan audit before DS native. Zero retrieval/retries/semantic output repair. Existing parser may extract JSON from a markdown wrapper; retain raw. Unknown/missing/cross-source IDs still block. First substantive fidelity/service/execution failure closes phase; never retry started cells.',
       'claims':'Native fidelity only, not synthetic utility readiness, acceptance gain, efficacy or guard pass. All failed authored phases remain failed. Any development entry follows the reviewed prospective criterion and original eight/twelve scientific guards unchanged.',
       'review_independence':'same-family','acceptance_status':'provisional'}
    save(root/'protocol.json',p)
    save(root/'receipt.json',{'protocol_sha256':digest(root/'protocol.json'),'planned_max_sends':p['planned_max_sends'],'requested_output_token_cap_total':26624,'prior_diagnostic_usage':'23Flash/6Jev,111687input/47329outputFlash;32198input/1808outputJev;4Search/1Fetch. Historicalusage separate.','budget':'Expanded user diagnostic authority; existing credits/includedquota only, nooverages/Astra. No routine count approval needed.'})
    with zipfile.ZipFile(root/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for folder in (Path('src'),Path('tests')):
            for path in folder.rglob('*.py'):z.write(path,path.as_posix())
        for path in [Path(__file__),*[Path(h) for h in helpers]]:z.write(path,path.as_posix())


def main():
    a=argparse.ArgumentParser();a.add_argument('directory',type=Path);a.add_argument('--prepare',action='store_true');a.add_argument('--worker')
    args=a.parse_args();root=args.directory
    if args.prepare:prepare(root);return
    p=read(root/'protocol.json')
    assert p['models']==MODELS and p['source_sha256']==code_digest()
    assert p['runner_sha256']==digest(Path(__file__))
    assert all(digest(Path(h))==v for h,v in p['helpers_sha256'].items())
    assert digest(Path(p['source_result']))==p['source_result_sha256']
    assert digest(Path(p['reused_glm_plan']['path']))==p['reused_glm_plan']['sha256']
    assert digest(root/'glm-plan/result.json')==p['reused_glm_plan']['retained_copy_sha256']
    assert digest(root/'review-disposition.json')==p['review_disposition_sha256']
    assert digest(Path(p['review_report']))==p['review_report_sha256']
    assert digest(root/'diagnostic-authority.json')==p['authority_sha256']
    assert read(root/'diagnostic-authority.json')['approved'] is True
    assert read(root/'receipt.json')['protocol_sha256']==digest(root/'protocol.json')
    if args.worker:
        try:
            native.execute(root,p,next(t for t in p['schedule'] if t['id']==args.worker))
        except Exception as exc:
            partial=getattr(exc,'partial_assessment',None)
            if partial is not None:
                save(root/args.worker/'partial-assessment.json',partial.model_dump(mode='json'))
            raise
        return
    assert not (root/'readiness-decision.json').exists(),'Closed native phase cannot resume'
    for task in p['schedule']:
        d=root/task['id']
        if d.exists():
            assert (d/'job.json').exists() and not read(d/'job.json')['hard_stop'],'Inspect started failure; no retry'
            continue
        if task['model']=='deepseek':
            assert read(root/'glm-anchor-audit.json')['passed'] is True,'Native DS awaits GLM fidelity audit'
        if task['id']=='deepseek-anchor':
            assert read(root/'deepseek-plan-audit.json')['passed'] is True,'DS anchor awaits neutral plan audit'
        elapsed=sum(read(j)['elapsed_seconds'] for j in root.glob('*/job.json'))
        assert elapsed+300<=p['aggregate_job_seconds_cap'],'Aggregate experiment allowance cannot reserve another job'
        d.mkdir()
        save(d/'attempt.json',{**task,'started_at':datetime.now(timezone.utc).isoformat(),'protocol_sha256':digest(root/'protocol.json')})
        save(d/'live-state.json',{'counts':{'ollama':0,'jev':0},'deadline':time.time()+270,'stop':None})
        start=time.monotonic()
        with (d/'stdout.log').open('wb') as out,(d/'stderr.log').open('wb') as err:
            try:
                result=subprocess.run([sys.executable,__file__,str(root),'--worker',task['id']],timeout=300,stdout=out,stderr=err,env={**os.environ,**THREADS,'PYTHONUTF8':'1'});code=result.returncode
            except subprocess.TimeoutExpired:code=None
        usage=scan(d,MODELS[task['model']]);save(d/'usage.json',usage)
        state=read(d/'live-state.json');counts=Counter(x['service'] for x in usage)
        bad=any(counts[k]!=v for k,v in state['counts'].items()) or any(x.get('status')!=200 or x.get('transport_error') or x.get('accounting_error') or x.get('model_verified') is not True or x.get('incomplete') for x in usage)
        hard=bool(code!=0 or bad or state['stop'])
        save(d/'job.json',{'exit_code':code,'elapsed_seconds':time.monotonic()-start,'accounting_problem':bad,'hard_stop':hard})
        print(task['id'],'STOP' if hard else 'DONE',flush=True)
        if hard:
            save(root/'readiness-decision.json',{'closed':True,'passed':False,'binding_failure':task['id'],'reason':'Execution/service/accounting failure; no retry.','development_released':False,'study_wide_futility':False})
            raise SystemExit('Inspect retained native failure')
        return


if __name__=='__main__':main()
