"""Prospective factored source-answer/adjudication readiness; no efficacy inference.

Reuse the retained source-blind GLM plan; native DeepSeek plan and native Graham
assessment per model, plus five-control batch proxies. No efficacy inference.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace
import zipfile

from pydantic import BaseModel

from flash_study import MODELS,THREADS,FlashLedger,read,save,digest,scan
from flash_component_diagnostic import controls
from kaji_langgraph.config import effective_policy
from kaji_langgraph.evaluation import code_digest
from kaji_langgraph.gate import evidence_gaps
from kaji_langgraph.reference_assessment import paragraph_records
from kaji_langgraph.factored_assessment import SourceLedger,LedgerDecision,binding_issues,compile_factored,extraction_prompt,decision_prompt
from kaji_langgraph.llm import OllamaBackend,heuristic_decomposition,indexed_records
from kaji_langgraph.models import SourceRecord
from kaji_langgraph.study_analysis import replay_sources
from runtime_pilot import load_keys,transport


class SourceBatch(BaseModel):
    ledgers: dict[str,SourceLedger]

class DecisionBatch(BaseModel):
    decisions: dict[str,LedgerDecision]


class Capture:
    def __init__(self,answer):self.answer=answer;self.prompt=None;self.options=None
    def bind(self,**kwargs):self.options=kwargs;return self
    def invoke(self,prompt):self.prompt=prompt;return SimpleNamespace(content=json.dumps(self.answer),usage_metadata={"total_tokens":0})


def backend(model,ledger=None):
    result=OllamaBackend(model=MODELS[model],base_url="http://localhost:11434",temperature=0,
        verdict_mode="averitec",assessment_mode="factored",brief_assessment_tokens=6144,
        line_reasoning_effort="low" if model=="glm" else None)
    if ledger:
        import httpx
        from langchain_ollama import ChatOllama
        result._model=ChatOllama(model=MODELS[model],base_url=result.base_url,temperature=0,
            num_predict=6144,validate_model_on_init=False,client_kwargs={
                "transport":transport(httpx,ledger,"ollama"),"timeout":90,"follow_redirects":False,"trust_env":False})
    return result


def control_inputs():
    result=[]
    for case in controls():
        sources=[]
        for row in case["records"]:
            text="\n\n".join(row["passages"].values())
            sources.append(SourceRecord(url=row["url"],title=row["title"],page_text=text,
                retrieved_at="2026-11-04",content_hash=hashlib.sha256(text.encode()).hexdigest(),
                query="Authored closed-packet review of supporting and opposing records",provider="authored-control"))
        required=list(dict.fromkeys([case["claim"],*heuristic_decomposition(case["claim"])]))
        result.append({"id":case["id"],"claim":case["claim"],"expected_label":case["expected"],
            "expected_structural_eligibility":case["id"] in {"sufficient","attribution","conflicting"},
            "sources":[s.model_dump(mode="json") for s in sources],
            "input":{"original_claim":case["claim"],"domain":"general","reference_date":"2024-06-30",
                "required_components":{f"C{i}":c for i,c in enumerate(required)},
                "planning_statements":[],"verification_questions":[],
                "executed_queries":["Authored closed-packet review of supporting and opposing records"],
                "records":paragraph_records(sources)}})
    return result


def batch_prompt(cases,model,ledgers=None):
    if ledgers is None:
        prefix=extraction_prompt({"original_claim":"CAPTURE"}).split('{"original_claim":',1)[0]
        schema=SourceBatch
    else:
        empty=SourceLedger(findings=[],origins=[],answers=[])
        prefix=decision_prompt({"original_claim":"CAPTURE"},empty).split('{"original_claim":',1)[0]
        schema=DecisionBatch
    visible=[]
    for c in cases:
        item=deepcopy(c["input"])
        item["records"]=[{k:v for k,v in r.items() if k not in {"visible_text","paragraph_offsets"}} for r in item["records"]]
        if ledgers is not None:item["unverified_source_ledger"]=ledgers[c["id"]].model_dump(mode="json")
        visible.append({"id":c["id"],**item})
    return (prefix+"\nEvaluate these five independent authored closed-packet fixtures. "
        "Their records are stipulated, not real-world study acceptances. Keep namespaces separate. "
        "Return entries keyed by exact case ID. Expected labels/confidences are not supplied.\nCases:\n"
        +json.dumps(visible,ensure_ascii=False)+"\nReturn ONLY JSON matching:\n"
        +json.dumps(schema.model_json_schema(),separators=(",",":")))


def prepare(root):
    root.mkdir(exist_ok=True)
    assert not (root/"protocol.json").exists()
    source=Path("artifacts/flash-workflow-20261103/revision-3/development/train-1205-deepseek-baseline/result.json")
    retained=read(source)["result"];trace=retained["research_history"][-1]
    sources=replay_sources(retained,trace)
    case=read(Path("artifacts/flash-workflow-20261103/development-cases.json"))["train-1205"]
    config=read(Path("artifacts/flash-workflow-20261103/revision-8/development.json"))["config"]
    config["model"].update(assessment_mode="factored",decomposition_method="questions_as_guidance")
    config["policy"]["require_independent_provenance_review"]=True
    fixture=control_inputs();plans={};batches={}
    for i,c in enumerate(fixture):c["role"],c["id"]=c["id"],f"case-{chr(65+i)}"
    for model in MODELS:
        cap=Capture({"assertions":[case["claim"]],"questions":["What record establishes the attributed utterance?"]})
        b=backend(model);b._model=cap;b.decompose_with_questions(case["claim"],reference_date=retained["reference_date"])
        plans[model]={"prompt":cap.prompt,"estimated_input_tokens":(len(cap.prompt.encode())+2)//3,"requested_output_tokens":2048}
        prompt=batch_prompt(fixture,model)
        batches[model]={"prompt":prompt,"estimated_input_tokens":(len(prompt.encode())+2)//3,"requested_output_tokens":6144}
    schedule=[{"id":f"{m}-{kind}","model":m,"kind":kind} for m,kinds in [("glm",("ledger","decision","anchor")),("deepseek",("plan","ledger","decision","anchor"))] for kind in kinds]
    p={"models":MODELS,"caps":{"ollama":1,"jev":2},"num_predict":6144,
        "source_sha256":code_digest(),"runner_sha256":digest(Path(__file__)),
        "helpers_sha256":{name:digest(Path(name)) for name in ("evaluation/flash_study.py","evaluation/runtime_pilot.py","evaluation/flash_component_diagnostic.py")},
        "source_result":source.as_posix(),"source_result_sha256":digest(source),
        "config":config,"schedule":schedule,"plans":plans,"control_batches":batches,"controls":fixture,
        "anchor":{"id":"train-1205","claim":case["claim"],"domain":retained["domain"],
            "reference_date":retained["reference_date"],"assertions":list(dict.fromkeys([case["claim"],*heuristic_decomposition(case["claim"])])),
            "sources":[s.model_dump(mode="json") for s in sources],
            "executed_queries":[q for h in retained["research_history"] for q in h["queries"]]},
        "planned_max_sends":{"ollama":9,"jev":4,"search":0,"fetch":0},
        "requested_output_token_cap_total":51200,
        "input_estimate_rule":"Ceiling UTF8 prompt bytes/3, a disclosed estimate. Native anchor actual prompt depends on retained source-blind plan; log its rendered prompt/estimate before dispatch. No estimate is a bill/balance/remote hard cap.",
        "screen":"Prospective combined-workflow READINESS, not efficacy or rescue of a closed diagnostic. A sound audited actual-anchor abstention is allowed. Both models must pass all five controls semantically and all native/retention/accounting checks before twenty new mandatory development attempts may be released. Forty-eight confirmation attempts remain contingent on the original development pass.",
        "control_criteria":["Sufficient, speech-only and established-conflict controls: correct whole-claim verdict at model-chosen High, all material components adjudicated, exact selected-passage support, appropriate distinct evidentiary paths and no invented material gap.",
            "Insufficient embedded content and shared-lineage controls: retain genuine missing-data/causality/lineage blockers and mark unsupported components unresolved. No manufactured independent origin or hidden material issue in nonblocking notes. Event/data dates must not be document dates.",
            "Audit all findings against their SELECTED passages, all component/finding links against the exact original claim, and every origin/action/date entry. Broader source context cannot silently repair a selected-passage failure. Keep all negative fields.",
            "No unsupported actual or would-be acceptance, unknown/missing references, invented source/denial/search/date, lost ledger lookup, parser repair or citation pruning. Plans remain unverified leads and preserve the original attribution/qualifications."],
        "anchor_criteria":"Native analyze_indexed must compile a valid, self-resolving whole-claim/source ledger and a sound evidentiary proposal. A correct FALSE with retained provenance uncertainty and UNVERIFIED is admissible readiness. Any acceptance must pass unchanged deterministic+Jev citation/provenance checks and full passage/whole-claim audit. Unsupported finding or fabricated origin fails even if gate abstains.",
        "operations":"Reuse retained GLM source-blind plan; GLM controls/native anchor first; inspect before DeepSeek. One worker,two numerical threads,300s/job;zero retrieval/repairs/retries. Unexpected model/usage/transport/output overrun or decisive fidelity failure closes this phase; preserve started failures and untouched cells.",
        "limitations":"Authored controls are batch proxies, not native response-reliability observations or completed Jev acceptances. Source-blind planning is native on Graham only. This phase does not isolate causal effects of questions,IDs,exposure,orledger; earlier S/Q/QL observations remain separate negative evidence. Final claims must concern the combined workflow unless a separately authorized matched ablation is completed.",
        "review":"No fresh review of factored code. Prior same-family scope review supplies conservative criteria only; new premise retained in DESIGN.md. Native fresh review round budget for current session is exhausted.",
        "review_independence":"same-family","acceptance_status":"provisional"}
    old_plan=Path("artifacts/indexed-ledger-20261104/glm-plan/result.json")
    p["reused_glm_plan"]={"path":old_plan.as_posix(),"sha256":digest(old_plan),"reason":"Already completed source-blind native plan; fixed retained diagnostic input, not a new outcome."}
    p["mechanism"]="Two actual calls per assessment: source-bound neutral answers/observations without verdict/confidence; then separate adjudication against original records plus unverified ledger. All first findings/material issues retained. Same reference visibility/gates; combined intervention."
    p["source_basis"]="DESIGN.md; observed coupled synthesis/materiality/output failures and independent evidence-coverage audit. CoVe motivates separate contexts, not efficacy or validated materiality. This is an adaptation, not a replication."
    p["criteria_scope"]="All earlier five semantic-control/native criteria retained. Each source ledger must pass manual fidelity audit before its decision call. All five GLM decisions must pass full audit BEFORE GLM anchor; both must pass before DeepSeek. A sound anchor abstention is allowed; this is development-entry readiness only."
    p["caps_by_kind"]={"ledger":{"ollama":1,"jev":0},"decision":{"ollama":1,"jev":0},"plan":{"ollama":1,"jev":0},"anchor":{"ollama":2,"jev":2}}
    p["source_stage_criteria"]="All five source ledgers must preserve exact original targets/qualifications, narrow selected-range support for every finding, accurate origin/date roles, adverse evidence, usable bare-ID links and all declared material questions. No proposed verdict/confidence may appear in the source-ledger schema. A spurious declared material issue on a positive fixture fails; nothing is cleared retrospectively. No automated semantic pass follows from valid references. Inspect before the adjudication send."
    (root/"glm-plan").mkdir()
    save(root/"glm-plan/result.json",read(old_plan))
    save(root/"glm-plan/reuse.json",p["reused_glm_plan"])
    p["reused_glm_plan"]["retained_copy_sha256"]=digest(root/"glm-plan/result.json")
    save(root/"protocol.json",p)
    save(root/"receipt.json",{"protocol_sha256":digest(root/"protocol.json"),"scope":"At most9 Flash+4 Jev sends,zero retrieval;stage-specific2048/6144 output caps,no retries. Existing included/prepaid credits only. Aggregate before this phase11Flash+5Jev,4Search+1Fetch; first request GLM source-ledger only, all further sends conditional on semantic pass. New prospective readiness phase under continuing low-risk authorization.","diagnostic_authority":"PENDING: reconcile additional maximum9Flash diagnostic sends with user few-request limit before any dispatch. Source/settings/estimates are reviewable; no earlier screen authority covers this new diagnostic by default.","development_authority":"User conditionally allowed68 mandatory workflow attempts only after a justified diagnostic;this phase can release20 development only on its complete pass,not automatically."})
    with zipfile.ZipFile(root/"source.zip","w",zipfile.ZIP_DEFLATED) as archive:
        for folder in (Path("src"),Path("tests")):
            for path in folder.rglob("*.py"):archive.write(path,path.as_posix())
        for name in [__file__,*p["helpers_sha256"]]:archive.write(name,Path(name).as_posix())


def execute(root,p,task):
    d=root/task["id"];load_keys();local={**p,"num_predict":2048 if task["kind"]=="plan" else 6144,"caps":{"ollama":2 if task["kind"]=="anchor" else 1,"jev":2 if task["kind"]=="anchor" else 0}}
    class ReadinessLedger(FlashLedger):
        def before(self,service,request):
            if service=="ollama":
                body=request["body"];prompt=body["messages"][-1]["content"]
                save(d/"prepared-request-estimate.json",{"utf8_prompt_bytes":len(prompt.encode()),
                    "estimated_input_tokens":(len(prompt.encode())+2)//3,
                    "requested_output_tokens":body.get("options",{}).get("num_predict"),
                    "prompt_sha256":hashlib.sha256(prompt.encode()).hexdigest(),
                    "caveat":"Prompt-length estimate only,not a bill or enforced remote cap."})
                if task["kind"]=="plan":assert prompt==p["plans"][task["model"]]["prompt"]
                if task["kind"]=="ledger":assert prompt==p["control_batches"][task["model"]]["prompt"]
            return super().before(service,request)
    ledger=ReadinessLedger(d,local,MODELS[task["model"]]);ledger.task=task["id"];b=backend(task["model"],ledger)
    if task["kind"]=="plan":
        plan,tokens=b.decompose_with_questions(p["anchor"]["claim"],reference_date=p["anchor"]["reference_date"])
        save(d/"result.json",{"parsed":True,"plan":plan.model_dump(),"sdk_tokens":tokens});return
    if task["kind"] in {"ledger","decision"}:
        ledgers=None
        if task["kind"]=="decision":
            ledgers={id:SourceLedger.model_validate(value) for id,value in read(root/f"{task['model']}-ledger/result.json")["ledgers"].items()}
        prompt=batch_prompt(p["controls"],task["model"],ledgers)
        raw=b._model.bind(format="json",reasoning=b.line_reasoning_effort or False,
            options={"temperature":0,"num_predict":6144}).invoke(prompt)
        if ledgers is None:
            batch=b._parse_json(SourceBatch,b._message_text(raw))
            assert set(batch.ledgers)=={c["id"] for c in p["controls"]},"Wrong source-ledger case IDs"
            issues={c["id"]:binding_issues(batch.ledgers[c["id"]],c["input"]["required_components"],c["input"]["records"]) for c in p["controls"]}
            save(d/"result.json",{"parsed":True,"ledgers":{k:v.model_dump(mode="json") for k,v in batch.ledgers.items()},
                "inputs":{c["id"]:c["input"] for c in p["controls"]},"binding_issues":issues,"sdk_tokens":b._tokens(raw),"semantic_audit":"pending"})
            assert not any(issues.values()),"Invalid first-stage references; no adjudication released"
            return
        batch=b._parse_json(DecisionBatch,b._message_text(raw))
        assert set(batch.decisions)=={c["id"] for c in p["controls"]},"Wrong decision case IDs"
        rows=[]
        for c in p["controls"]:
            compiled=compile_factored(ledgers[c["id"]],batch.decisions[c["id"]],c["input"]["required_components"],c["input"]["records"])
            compiled.indexed_input.update({k:v for k,v in c["input"].items() if k!="records"})
            sources=[SourceRecord.model_validate(s) for s in c["sources"]]
            gaps=evidence_gaps(compiled,list(c["input"]["required_components"].values()),sources,effective_policy(p["config"],"general"))
            rows.append({"id":c["id"],"role":c["role"],"assessment":compiled.model_dump(mode="json"),"structural_gaps":gaps,
                "structural_eligible":not gaps,"label_matches":compiled.proposed_verdict==c["expected_label"],
                "structural_expectation_matches":(not gaps)==c["expected_structural_eligibility"],"semantic_audit":"pending"})
        save(d/"result.json",{"parsed":True,"controls":rows,"sdk_tokens":b._tokens(raw),"fully_automated_acceptances":False})
        return
    import httpx2
    from typesafe_sdk import TypeSafeClient,RetryPolicy
    import kaji_langgraph.jev as jm
    from kaji_langgraph.graph import WorkflowNodes
    from kaji_langgraph.models import BudgetState
    a=p["anchor"];plan=read(root/f"{task['model']}-plan/result.json")["plan"]
    sources=[SourceRecord.model_validate(s) for s in a["sources"]]
    start=time.monotonic()
    assessment,tokens=b.analyze_indexed(a["claim"],a["domain"],a["assertions"],sources,[],a["reference_date"],
        p["config"].get("domain_guidance",{}).get(a["domain"],{}),verification_questions=plan["questions"],
        planning_statements=plan["assertions"],use_ledger=True,executed_queries=a["executed_queries"])
    assert len(assessment.evidence)<=6,"Exceeded predeclared finding bound;never prune citations"
    def client(**kwargs):return TypeSafeClient(**kwargs,retry=RetryPolicy(max_retries=0),http_client=httpx2.Client(
        transport=transport(httpx2,ledger,"jev"),timeout=15,follow_redirects=False))
    jm.TypeSafeClient=client
    policy=effective_policy(p["config"],a["domain"]);policy["require_independent_provenance_review"]=True
    state={"claim":a["claim"],"domain":a["domain"],"assertions":a["assertions"],"sources":sources,
        "assessment":assessment,"policy":policy,"research_round":1,"research_history":[],"errors":[],"jev_audit":{},"fatal_error":False,
        "budgets":BudgetState(max_seconds=270,started_at_monotonic=start)}
    checked=WorkflowNodes(None,None,p["config"],jm.JevClient(model="jev-1.13.0")).check_evidence(state)
    gate={k:checked[k] for k in ("gaps","errors","fatal_error","jev_audit")}
    save(d/"result.json",{"parsed":True,"assessment":assessment.model_dump(mode="json"),"sdk_tokens":tokens,
        "gate":gate,"gate_eligible":not gate["gaps"] and not gate["fatal_error"],"semantic_audit":"pending"})


def main():
    parser=argparse.ArgumentParser();parser.add_argument("directory",type=Path);parser.add_argument("--prepare",action="store_true");parser.add_argument("--worker")
    args=parser.parse_args();root=args.directory
    if args.prepare:prepare(root);return
    p=read(root/"protocol.json")
    assert p["source_sha256"]==code_digest() and p["runner_sha256"]==digest(Path(__file__))
    assert all(digest(Path(n))==h for n,h in p["helpers_sha256"].items())
    assert digest(Path(p["source_result"]))==p["source_result_sha256"]
    assert digest(Path(p["reused_glm_plan"]["path"]))==p["reused_glm_plan"]["sha256"]
    assert digest(root/"glm-plan/result.json")==p["reused_glm_plan"]["retained_copy_sha256"]
    assert read(root/"receipt.json")["protocol_sha256"]==digest(root/"protocol.json")
    if args.worker:execute(root,p,next(t for t in p["schedule"] if t["id"]==args.worker));return
    assert not (root/"readiness-decision.json").exists(),"Closed/readiness phase cannot resume"
    assert (root/"diagnostic-authority.json").exists() and read(root/"diagnostic-authority.json")["approved"] is True,"Additional diagnostic send authority is pending; no request dispatched"
    for task in p["schedule"]:
        d=root/task["id"]
        if d.exists():
            assert (d/"job.json").exists() and not read(d/"job.json")["hard_stop"],"Inspect failed/unknown outcome;no retry"
            continue
        if task["kind"]=="decision":
            audit=root/f"{task['model']}-ledger-audit.json"
            assert audit.exists() and read(audit)["passed"] is True,"Decision awaits inspected source ledger"
        if task["id"]=="glm-anchor":
            assert (root/"glm-decision-audit.json").exists() and read(root/"glm-decision-audit.json")["passed"] is True,"Native anchor awaits complete GLM control audit"
        if task["id"]=="deepseek-anchor":
            assert (root/"deepseek-decision-audit.json").exists() and read(root/"deepseek-decision-audit.json")["passed"] is True,"Native anchor awaits DeepSeek controls audit"
        if task["model"]=="deepseek":
            assert (root/"glm-readiness.json").exists() and read(root/"glm-readiness.json")["passed"] is True,"DeepSeek awaits complete positive GLM audit"
        d.mkdir();save(d/"attempt.json",{**task,"started_at":datetime.now(timezone.utc).isoformat(),"protocol_sha256":digest(root/"protocol.json")})
        save(d/"live-state.json",{"counts":{"ollama":0,"jev":0},"deadline":time.time()+270,"stop":None})
        start=time.monotonic()
        with (d/"stdout.log").open("wb") as stdout,(d/"stderr.log").open("wb") as stderr:
            try:
                proc=subprocess.run([sys.executable,__file__,str(root),"--worker",task["id"]],timeout=300,stdout=stdout,stderr=stderr,env={**os.environ,**THREADS,"PYTHONUTF8":"1"});code=proc.returncode
            except subprocess.TimeoutExpired:code=None
        usage=scan(d,MODELS[task["model"]]);save(d/"usage.json",usage);state=read(d/"live-state.json")
        from collections import Counter
        counts=Counter(r["service"] for r in usage)
        bad=any(counts[k]!=v for k,v in state["counts"].items()) or any(r.get("status")!=200 or r.get("transport_error") or r.get("accounting_error") or r.get("model_verified") is not True or r.get("incomplete") for r in usage)
        hard=bool(code!=0 or bad or state["stop"])
        save(d/"job.json",{"exit_code":code,"elapsed_seconds":time.monotonic()-start,"accounting_problem":bad,"hard_stop":hard})
        print(task["id"],"STOP" if hard else "DONE",flush=True)
        if hard:
            save(root/"readiness-decision.json",{"closed":True,"passed":False,"binding_failure":task["id"],"reason":"Execution/schema/service/accounting failure;preserve result,do not retry.","development_released":False})
            raise SystemExit("Inspect retained readiness failure")
        return


if __name__=="__main__":main()
