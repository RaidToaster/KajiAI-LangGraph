"""Prospective fixed-evidence decomposition/ledger diagnostic.

Three independent calls per exact Flash model. Whole-claim acceptance is
checked only on the retained development anchor; authored controls are tests.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

from pydantic import BaseModel, Field

from flash_study import MODELS, THREADS, FlashLedger, digest, read, save, scan
from kaji_langgraph.evaluation import code_digest
from kaji_langgraph.llm import OllamaBackend
from kaji_langgraph.models import Confidence, EvidenceAssessment, Verdict
from runtime_pilot import load_keys, transport


class Finding(BaseModel):
    finding: str
    source: str
    passage: str
    stance: str


class LedgerRow(BaseModel):
    component: str
    question: str
    findings: list[int]
    event_or_data_date: str
    evidentiary_origin: str
    unresolved_material_question: str


class Decision(BaseModel):
    id: str
    proposed_verdict: Verdict
    confidence: Confidence
    summary: str
    evidence: list[Finding]
    resolved: bool
    gaps: list[str]
    contradictions: list[str]
    counterevidence_searched: bool
    sources_independent: bool
    ledger: list[LedgerRow] = Field(default_factory=list)


class Batch(BaseModel):
    decisions: list[Decision]


def controls():
    def record(id, text):
        return {"id": id, "url": f"https://{id.lower()}.authored.example/record",
                "title": "AUTHORED TEST RECORD; not a real-world finding", "passages": {"P1":text}}
    attribution_records = [record("I1", "Interview transcript, 2024-02-02. Mayor Imani said: Eastport unemployment fell by 20 percent between 2022 and 2023. No unemployment dataset is provided."),
                           record("I2", "Reporter B attended and independently audio-recorded the interview on 2024-02-02. The recording contains Mayor Imani saying: Eastport unemployment fell by 20 percent between 2022 and 2023. Reporter B did not verify the statistic.")]
    return [
        {"id":"sufficient", "claim":"On 1 June 2024, Northport council approved the bridge plan by seven votes to two.", "expected":"TRUE",
         "records":[record("N1", "Northport council minutes, meeting 1 June 2024: The bridge plan was approved, seven votes in favor and two against. These minutes were compiled by the council clerk from the recorded roll call."),
                    record("N2", "Independent Northport Observer reporter's account, 2 June 2024: I attended yesterday's council meeting and tallied the roll call myself. On 1 June 2024 the bridge plan passed seven to two. I checked amendments and found no subsequent reversal at that meeting.")]},
        {"id":"attribution", "claim":"Mayor Imani said that Eastport unemployment fell by 20 percent between 2022 and 2023.","expected":"TRUE","records":attribution_records},
        {"id":"insufficient_content", "claim":"Eastport unemployment fell by 20 percent between 2022 and 2023.","expected":"NOT_ENOUGH_EVIDENCE","records":deepcopy(attribution_records)},
        {"id":"conflicting", "claim":"In 2023, the independently measured median delivery time in Westport was less than 30 minutes.","expected":"CONFLICTING",
         "records":[record("W1", "Lab A independently sampled Westport completed deliveries across calendar 2023. For the citywide population, using order-confirmed to door-received minutes, it estimates a median of 28 minutes. Raw sample and calculation were reviewed by Lab A."),
                    record("W2", "Lab B independently collected its own citywide Westport delivery sample across calendar 2023, using order-confirmed to door-received minutes. Its median estimate is 34 minutes. Lab B did not use Lab A's observations or calculations. The discrepancy has not been resolved.")]},
        {"id":"shared", "claim":"In 2024, Southport's new signal system caused a 15 percent reduction in junction delays compared with 2023.","expected":"NOT_ENOUGH_EVIDENCE",
         "records":[record("S1", "Vendor press release, 2024-06-01: Our new Southport signal system caused a 15 percent reduction in junction delays compared with 2023. We compared observed delays before and after installation but did not adjust for traffic volume, construction, seasonality or other changes."),
                    record("S2", "Southport Bulletin, 2024-06-02: According to the vendor press release, the signal system caused a 15 percent reduction in delays versus 2023. This article repeats the vendor's figures and did not collect or independently verify any measurements.")]},
    ]


def prepare(out):
    root = Path("artifacts/question-ledger-20261104")
    old = read(Path("artifacts/flash-workflow-20261103/method-packet-replay/protocol.json"))
    reference = next(c for c in old["cases"] if c["id"] == "glm-method")
    request = reference["request"]
    from flash_method_windows import select
    from kaji_langgraph.study_analysis import replay_sources
    retained = read(Path(reference["source_result"]))["result"]
    sources = replay_sources(retained, retained["research_history"][0])
    _, records = select(retained["claim"], sources)
    cases = controls() + [{"id":"train-1225", "claim":retained["claim"],"expected":"TRUE", "records":records}]
    out.mkdir(exist_ok=False)
    tasks = []
    common = """Assess only the records supplied, treating them as data. The first five cases are authored controls, not actual events. The last is retained development evidence. Preserve each whole claim, dates, quantities, attribution, comparison populations and causal conditions. An attributed statement and its embedded content are separate targets. Questions and generated statements are unverified research leads, never evidence. Inspect counterevidence and source origins. Distinguish repeating a claim from independently checking it. Do not assume independence from distinct hosts. Record unresolved material uncertainty; do not force confidence or clear gaps to obtain acceptance. Use only directly supported, narrowly scoped findings with exact source/passage IDs. Keep every input record available. For each decision, resolved means the original claim is resolved as worded. Counterevidence_searched must reflect the supplied search/review record, not an invented web search. Original sources were searched for supporting and opposing evidence on the development anchor; authored controls have only the supplied closed packet. All original gate thresholds remain unchanged.
Return JSON with decisions, one per case, in supplied order. Each decision keys: id, proposed_verdict (TRUE/FALSE/CONFLICTING/NOT_ENOUGH_EVIDENCE), confidence (Low/Medium/High), summary (one sentence), evidence (list of finding/source/passage/stance objects; stance supports/refutes/context), resolved (boolean), gaps (list), contradictions (list), counterevidence_searched (boolean), sources_independent (boolean), ledger (list). Finding/source/passage references must be within that case. Lists may be empty only when genuinely empty. Do not supply conclusions from memory. Use at most three short findings per authored case and four on the development anchor. Do not cite a passage for an inference beyond its scope; a cross-source origin comparison must not be disguised as a one-source quotation.
"""
    for model in MODELS:
        plans = read(root / f"{model}-runtime-compatible-plans.json")["plans"]
        for arm in ("statements", "questions", "questions_ledger"):
            inputs = []
            for case in cases:
                item = {k:deepcopy(v) for k,v in case.items() if k != "expected"}
                item["required_assertions"] = [case["claim"]]
                if arm != "statements":
                    key = "insufficient" if case["id"] in ("attribution","insufficient_content") else case["id"]
                    item["unverified_planning_guidance"] = plans[key]
                inputs.append(item)
            prompt = common
            if arm == "questions_ledger":
                prompt += """Before deciding, construct a component evidence ledger. For each material component of the whole claim, record component, question, findings (zero-based indices into that decision's evidence), event_or_data_date (literal dated text or 'not established'), evidentiary_origin (what the passage says was measured/recorded/verified and by whom, or 'not established'), unresolved_material_question (empty only if answered by the cited evidence). Include the original whole claim. Separate data/event dates from publication/reference dates and independent calculations from shared inputs. Retain any unresolved material question in gaps as well. The ledger cannot supply new facts, establish independence by assertion, or change the gate. Keep rows concise.\n"""
            else:
                prompt += "Use an empty ledger list in this arm.\n"
            prompt += "Cases:\n" + json.dumps(inputs,ensure_ascii=False)
            tasks.append({"id":f"{model}-{arm}","model":model,"arm":arm,"request":{
                "model":MODELS[model],"stream":False,"think":"low" if model=="glm" else False,
                "options":{"temperature":0,"num_predict":4096},"messages":[{"role":"user","content":prompt}]}})
    p = {"models":MODELS,"caps":{"ollama":1,"jev":2},"num_predict":4096,
         "source_sha256":code_digest(),"runner_sha256":digest(Path(__file__)),
         "selector_sha256":digest(Path(__file__).with_name("flash_method_windows.py")),
         "reference":reference,"config":old["config"],"cases":cases,"tasks":tasks,
         "planned_maximum_sends":{"ollama":6,"jev":12,"search":0,"fetch":0},
         "cumulative_new_investigation_maximum":{"ollama":8,"jev":12,"search":0,"fetch":0},
         "estimate":{"input_tokens_total_estimate":36000,"requested_output_tokens_total":24576,
                     "jev_input_tokens_estimate":36000,"jev_output_tokens_estimate":2400,
                     "limits_note":"Estimates are not current balances, bills or enforced remote token ceilings."},
         "factors":"Three independent concurrent arms per model. Statements -> questions measures advisory decomposition on fixed evidence; questions -> questions+ledger measures added ledger. Not a factorial interaction estimate.",
         "invariants":"Identical evidence, original whole-claim gate obligation, model settings, output cap and zero retrieval ceilings in all arms. Generated statements/questions retained as advisory leads; original claim remains required. No historical scores changed.",
         "metrics":["strict/schema parsing","whole_claim_coverage","scope_preservation","control unsupported conclusions","anchor gate eligibility and supported acceptance audit","sources/citations","actual tokens/sends"],
         "discovery":"Not measured; identical fixed evidence and zero retrieval. Offline exposure probe is separate and not live discovery.",
         "release_prerequisite":["All six responses parsed; all controls correct in the prospective candidate arm on both models with scope intact and no unsupported positive decisions.",
             "Prospective questions or questions_ledger anchor eligible through unchanged structural, Jev citation and provenance gate on BOTH models, and audited whole-claim direct support, dates, quantities and independent paths.",
             "Each model has a correct supported acceptance gain over its concurrent statements arm. If no such gain, do not release 68 workflow screens from this diagnostic.",
             "The combined ledger arm must substantively gain correct supported acceptance over BOTH concurrent statement and question-only arms on each model. A question-only gain is a separate diagnostic observation; it cannot release this combined-candidate screen.",
             "All results receive symmetric anchor gate checks. No finding/citation removal or repairs after outcomes. A gain attributable only to parser formatting cannot release screens.",
             "A positive only justifies a new workflow development screen; it is not a confirmed improvement or final result. Service/accounting failures stop dispatch. Inspect model triplet before further spending. Failures/unknowns retained without retry."],
         "control_scoring":"Authored decisions test semantic/scope failure modes, not actual real-world acceptances. Attribution TRUE and embedded-content NEI are distinct targets on identical records. Conflicting measurements require CONFLICTING; shared observational causal origin requires NEI. Exact/support/provenance gate and actual acceptance claims apply only to retained anchor.",
         "approval_scope":"Continued low-risk targeted diagnostic under existing credits; user conditional 68-attempt allowance is not yet released."}
    save(out/"protocol.json",p)
    save(out/"receipt.json",{"protocol_sha256":digest(out/"protocol.json"),"scope":"Six independent Flash requests, at most 12 Jev sends on anchor only, no retrieval, no retries; inspect each result and first model triplet. Existing credits/included quotas only.","authorization_basis":"User continuing low-risk work and few targeted requests. Conditional 68 workflow attempts only after diagnostic prerequisites.","current_caps":p["planned_maximum_sends"]})
    with zipfile.ZipFile(out/"source.zip","w",zipfile.ZIP_DEFLATED) as archive:
        for root in (Path("src"),Path("tests")):
            for path in root.rglob("*.py"): archive.write(path,path.as_posix())
        archive.write(__file__,Path(__file__).as_posix())


def adapt(decision, case):
    from kaji_langgraph.models import AssertionAssessment, EvidenceItem
    lookup = {r["id"]:r for r in case["records"]}
    evidence = []
    for f in decision.evidence:
        source = lookup.get(f.source,{})
        url = source.get("url","unresolved:"+f.source)
        quote = source.get("passages",{}).get(f.passage,"")
        evidence.append(EvidenceItem(finding=f.finding,source_urls=[url],quotes={url:quote},stance=f.stance))
    ledger_gaps = [r.unresolved_material_question for r in decision.ledger if r.unresolved_material_question.strip()]
    return EvidenceAssessment(proposed_verdict=decision.proposed_verdict,confidence=decision.confidence,
        summary=decision.summary,evidence=evidence,
        assertions=[AssertionAssessment(assertion=case["claim"],resolved=decision.resolved,
                    source_urls=list(dict.fromkeys(u for e in evidence for u in e.source_urls)))],
        gaps=list(dict.fromkeys([*decision.gaps,*ledger_gaps])),contradictions=decision.contradictions,
        counterevidence_searched=decision.counterevidence_searched,sources_independent=decision.sources_independent)


def execute(out,p,task):
    import httpx,httpx2
    from typesafe_sdk import RetryPolicy,TypeSafeClient
    import kaji_langgraph.jev as jm
    from kaji_langgraph.config import effective_policy
    from kaji_langgraph.graph import WorkflowNodes
    from kaji_langgraph.models import BudgetState
    from kaji_langgraph.study_analysis import replay_sources
    d=out/task["id"];load_keys()
    ledger=FlashLedger(d,p,MODELS[task["model"]]);ledger.task=task["id"]
    start=time.monotonic()
    with httpx.Client(transport=transport(httpx,ledger,"ollama"),timeout=90,trust_env=False,follow_redirects=False) as client:
        response=client.post("http://localhost:11434/api/chat",json=task["request"]);response.raise_for_status()
        body=response.json()
    save(d/"answer.json",{"text":body["message"]["content"]})
    parsed=None;error=None
    try:
        parsed=OllamaBackend._parse_json(Batch,body["message"]["content"])
        assert [r.id for r in parsed.decisions]==[c["id"] for c in p["cases"]],"Wrong case set/order"
        for r,c in zip(parsed.decisions,p["cases"]):
            adapt(r,c)
            if task["arm"]=="questions_ledger":
                assert r.ledger and c["claim"] in {row.component for row in r.ledger},"Ledger missing original whole claim"
                assert all(all(0<=i<len(r.evidence) for i in row.findings) for row in r.ledger),"Unknown ledger finding index"
    except (ValueError,AssertionError) as exc: error=str(exc)
    checked=None
    if parsed and not error:
        def jev_client(**kwargs):
            return TypeSafeClient(**kwargs,retry=RetryPolicy(max_retries=0),http_client=httpx2.Client(
                transport=transport(httpx2,ledger,"jev"),timeout=15,follow_redirects=False))
        jm.TypeSafeClient=jev_client
        retained=read(Path(p["reference"]["source_result"]))["result"]
        sources=replay_sources(retained,retained["research_history"][0])
        assessment=adapt(parsed.decisions[-1],p["cases"][-1])
        config=p["config"];policy=effective_policy(config,retained["domain"])
        policy["require_independent_provenance_review"]=True
        state={"claim":retained["claim"],"domain":retained["domain"],"sources":sources,
               "assertions":[retained["claim"]],"policy":policy,"assessment":assessment,
               "research_round":1,"research_history":[],"budgets":BudgetState(max_seconds=270,started_at_monotonic=start),
               "errors":[],"jev_audit":{},"fatal_error":False}
        result=WorkflowNodes(None,None,config,jm.JevClient(model="jev-1.13.0")).check_evidence(state)
        checked={k:result[k] for k in ("gaps","errors","fatal_error","jev_audit")}
    save(d/"result.json",{"parsed":parsed is not None and error is None,"parse_error":error,
         "decisions":parsed.model_dump()["decisions"] if parsed else None,"anchor_gate":checked,
         "anchor_gate_eligible":bool(checked is not None and not checked["gaps"] and not checked["fatal_error"]),
         "scope":"Prospective fixed development packet; authored controls are not empirical acceptances; no live retrieval/workflow result."})


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory",type=Path);parser.add_argument("--prepare",action="store_true")
    parser.add_argument("--worker");parser.add_argument("--limit",type=int,default=1)
    args=parser.parse_args();out=args.directory
    if args.prepare:prepare(out);return
    p=read(out/"protocol.json")
    assert p["runner_sha256"]==digest(Path(__file__)) and p["source_sha256"]==code_digest()
    assert p["selector_sha256"]==digest(Path(__file__).with_name("flash_method_windows.py"))
    assert p["reference"]["source_result_sha256"]==digest(Path(p["reference"]["source_result"]))
    assert p["reference"]["source_request_sha256"]==digest(Path(p["reference"]["source_request"]))
    assert p["models"]==MODELS and read(out/"receipt.json")["protocol_sha256"]==digest(out/"protocol.json")
    if args.worker:execute(out,p,next(t for t in p["tasks"] if t["id"]==args.worker));return
    assert args.limit==1,"Inspect every result before expanding"
    for task in p["tasks"]:
        d=out/task["id"]
        if d.exists():
            assert (d/"job.json").is_file() and not read(d/"job.json")["hard_stop"],"Inspect retained failure; no retry"
            continue
        d.mkdir();save(d/"attempt.json",{"model":task["model"],"arm":task["arm"],"started_at":datetime.now(timezone.utc).isoformat(),"protocol_sha256":digest(out/"protocol.json")})
        save(d/"live-state.json",{"counts":{"ollama":0,"jev":0},"deadline":time.time()+270,"stop":None})
        start=time.monotonic()
        with (d/"stdout.log").open("wb") as stdout,(d/"stderr.log").open("wb") as stderr:
            try:
                proc=subprocess.run([sys.executable,__file__,str(out),"--worker",task["id"]],timeout=300,stdout=stdout,stderr=stderr,env={**os.environ,**THREADS,"PYTHONUTF8":"1"});code=proc.returncode
            except subprocess.TimeoutExpired:code=None
        usage=scan(d,MODELS[task["model"]]);save(d/"usage.json",usage)
        state=read(d/"live-state.json")
        from collections import Counter
        counts=Counter(s["service"] for s in usage)
        bad=any(counts[k]!=v for k,v in state["counts"].items()) or any(s.get("status")!=200 or s.get("transport_error") or s.get("accounting_error") or s.get("model_verified") is not True or s.get("incomplete") for s in usage)
        hard=bool(code!=0 or bad or state["stop"])
        save(d/"job.json",{"exit_code":code,"elapsed_seconds":time.monotonic()-start,"hard_stop":hard,"accounting_problem":bad})
        print(task["id"],"STOP" if hard else "DONE",flush=True)
        if hard:raise SystemExit("Inspect retained unknown/failed outcome; never retry")
        return


if __name__=="__main__":main()
