"""One bounded original-record Fetch feasibility request; no model calls."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

from flash_study import THREADS, digest, read, save, recorded_retrieval_sends, retrieval_pause_until
from kaji_langgraph.evaluation import code_digest
from runtime_pilot import Ledger, load_keys, transport


def prepare(root):
    root.mkdir(exist_ok=False)
    protocol = {"url": "https://twitter.com/kunalkamra88/status/1230694630527664128",
        "discovery": "BOOM public article embedded link, manually inspected,2026-11-04; exact tweet ID. Web tool cache miss retained separately. This is not an acquired first-party body.",
        "source": "artifacts/development-gap-audit-20261104/kamra-coverage.json",
        "source_sha256": code_digest(), "runner_sha256": digest(Path(__file__)),
        "caps": {"tinyfish_fetch": 1}, "max_bytes": 1000000,
        "timeout_seconds": 45,
        "screen": "Success requires the actual first-party denial, account and post/time attribution, with readable supporting body. Login/challenge/error/title-only/empty body fails. A readable body is not automatically independent corroboration or accepted evidence.",
        "operations": "One Fetch URL,zero Search/Flash/Jev,retries,repairs or alternate endpoints. One worker,two numerical threads,300seconds. Existing free/included quota only. Preserve all failure and unknown outcomes.",
        "rationale": "Historical full BOOM body reports a public denial and own interview; prior candidate said no primary record. Following its exact original-record link is an evidence-acquisition test, not another scope/prompt rewrite. No model efficacy follows.",
        "workflow_release": False}
    save(root / "protocol.json", protocol)
    save(root / "receipt.json", {"protocol_sha256": digest(root / "protocol.json"),
        "scope": "One free/included Fetch URL only. No model sends; no hidden expansion. Continuing low-risk authority. All workflow screens remain unreleased."})
    with zipfile.ZipFile(root / "source.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for path in Path("src").rglob("*.py"):
            archive.write(path, path.as_posix())
        for path in [Path(__file__), Path("evaluation/runtime_pilot.py"), Path("evaluation/flash_study.py")]:
            archive.write(path, path.as_posix())


def worker(root, protocol):
    import httpx
    load_keys()
    directory = root / "original-post"
    ledger = Ledger(directory, protocol)
    ledger.task = "original-post"
    with httpx.Client(transport=transport(httpx, ledger, "tinyfish_fetch"), timeout=50,
            trust_env=False, follow_redirects=False) as client:
        with client.stream("POST", "https://api.fetch.tinyfish.ai", headers={"X-API-Key": os.environ["TINYFISH_API_KEY"]},
                json={"urls": [protocol["url"]], "format": "markdown", "ttl": 0,
                    "per_url_timeout_ms": protocol["timeout_seconds"] * 1000}) as response:
            response.raise_for_status()
            encoded = bytearray()
            for chunk in response.iter_bytes():
                if len(encoded) + len(chunk) > protocol["max_bytes"]:
                    raise ValueError("Decoded Fetch response exceeded predeclared one-megabyte cap; preserve partial transport, no retry")
                encoded.extend(chunk)
            body = json.loads(encoded)
    assert isinstance(body, dict)
    save(directory / "result.json", {"requested_url": protocol["url"], "response": body,
        "semantic_audit": "pending", "verified_evidence": False})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--worker", action="store_true")
    args = parser.parse_args()
    root = args.directory
    if args.prepare:
        prepare(root)
        return
    protocol = read(root / "protocol.json")
    assert protocol["source_sha256"] == code_digest() and protocol["runner_sha256"] == digest(Path(__file__))
    assert read(root / "receipt.json")["protocol_sha256"] == digest(root / "protocol.json")
    if args.worker:
        worker(root, protocol)
        return
    assert not (root / "decision.json").exists(), "Closed retrieval phase"
    history = sum((recorded_retrieval_sends(Path(x)) for x in ["artifacts/flash-workflow-20261103", "artifacts/temporal-retrieval-20261104-corrected", str(root)]), [])
    limits = {"tinyfish_fetch": [[60, 135], [86400, 900]]}
    assert retrieval_pause_until(history, limits, time.time()) <= time.time(), "Shared free Fetch headroom unavailable"
    directory = root / "original-post"
    assert not directory.exists(), "Started original-post cell cannot be repeated"
    directory.mkdir()
    save(directory / "attempt.json", {"started_at": datetime.now(timezone.utc).isoformat(), "protocol_sha256": digest(root / "protocol.json")})
    save(directory / "live-state.json", {"counts": {"tinyfish_fetch": 0}, "deadline": time.time() + 270, "stop": None})
    started = time.monotonic()
    with (directory / "stdout.log").open("wb") as stdout, (directory / "stderr.log").open("wb") as stderr:
        try:
            proc = subprocess.run([sys.executable, __file__, str(root), "--worker"], stdout=stdout, stderr=stderr,
                timeout=300, env={**os.environ, **THREADS, "PYTHONUTF8": "1"})
            code = proc.returncode
        except subprocess.TimeoutExpired:
            code = None
    state = read(directory / "live-state.json")
    hard = code != 0 or state["counts"]["tinyfish_fetch"] != 1 or bool(state["stop"])
    save(directory / "job.json", {"exit_code": code, "elapsed_seconds": time.monotonic() - started, "hard_stop": hard})
    print("original-post", "STOP" if hard else "DONE")


if __name__ == "__main__":
    main()
