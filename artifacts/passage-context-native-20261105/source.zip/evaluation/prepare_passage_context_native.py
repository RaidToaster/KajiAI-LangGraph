"""Offline preparation and captured-response regression; never sends requests."""
from collections import Counter
from pathlib import Path
import subprocess

from flash_study import MODELS, read, save, digest, scan
from kaji_langgraph.passage_decision import PassageDecision, compile_passage_decision, passage_prompt, unit_table

ROOT = Path('artifacts/passage-context-native-20261105')
OLD = Path('artifacts/passage-decision-native-20261105')


def main():
    ROOT.mkdir(exist_ok=True)
    partial_path = OLD / 'glm-anchor/partial-assessment.json'
    context = read(partial_path)['indexed_input']
    raw = PassageDecision.model_validate(context['passage_decision_response'])
    result = compile_passage_decision(raw, context['required_components'], context['records'])
    assert len(result.evidence) == len(raw.findings) == 6
    assert result.proposed_verdict == raw.proposed_verdict and result.confidence == raw.confidence
    assert not result.sources_independent
    assert len(result.indexed_input['passage_issue_context']) == len(raw.issues)
    save(ROOT / 'offline-regression.json', dict(
        scope='Offline compiler regression only; old native failure remains failed, not rescored.',
        captured_response_sha256=digest(partial_path), findings=len(result.evidence),
        preserved_issues=len(raw.issues), proposed_verdict=result.proposed_verdict,
        confidence=result.confidence, sources_independent=result.sources_independent,
        gaps=result.gaps, contexts=result.indexed_input['passage_issue_context']))
    save(ROOT / 'offline-compiled.json', result.model_dump(mode='json'))
    base = read(OLD / 'prior-accounting.json')
    totals = Counter(base['totals'])
    models = Counter(base['flash_sends_by_requested_model'])
    sends = scan(OLD / 'glm-anchor', MODELS['glm'])
    assert sends == read(OLD / 'glm-anchor/usage.json')
    assert len(sends) == 1 and sends[0]['model_verified'] and sends[0]['status'] == 200
    for send in sends:
        totals[send['service']] += 1
        if send['service'] == 'ollama':
            models[send['requested_model']] += 1
        for key in ('input_tokens', 'output_tokens'):
            totals[send['service'] + '_' + key] += send.get(key, 0)
    save(ROOT / 'prior-accounting.json', {**base, 'totals':dict(totals),
        'flash_sends_by_requested_model':dict(models),
        'additional_phase':OLD.as_posix(), 'additional_phase_sends':sends,
        'scope':'Previous continuation aggregate plus failed passage-decision native call; historical study separate.'})
    (ROOT / 'dirty-status.txt').write_bytes(subprocess.check_output(['git', 'status', '--short']))
    (ROOT / 'dirty-diff.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary']))
    for name in ('diagnostic-authority.json', 'current-headroom-approval.json'):
        save(ROOT / name, read(OLD / name))
    save(ROOT / 'session-boundary.json', dict(old_chat='01a1a5d3-269e-7ce1-8296-e3bf6eb57d5b',
        observed_old_chat_status='notLoaded; latest turn completed',
        observed_workers='Get-Process python*,ollama* returned no processes before preparation',
        user_resume='Alright you can try continuing but make it quick alright? we don\'t have much time left.',
        final_in_this_chat=False, no_old_phase_reopened=True))
    entry = read(OLD / 'review-disposition.json')
    entry.update(prior_accounting=(ROOT / 'prior-accounting.json').as_posix(),
        review_report=(ROOT / 'REVIEW.md').as_posix(),
        additional_helpers=['evaluation/run_passage_context_native.ps1',
            'evaluation/prepare_passage_context_native.py', (ROOT/'prior-accounting.json').as_posix(),
            'src/kaji_langgraph/config/default.yaml', 'pyproject.toml', 'uv.lock'],
        postreview_delta=None,
        mechanism='Separate lossless issue-context passage ledger; no promotion to six verdict findings. Every material issue blocks, unknown/duplicate IDs fail. Previous failed phases remain failed.')
    save(ROOT / 'review-disposition.json', entry)
    estimates = {}
    for model in ('glm', 'deepseek'):
        # The fixed retained plans provide original source-blind guidance.
        # Native execution writes the definitive request estimate before sending.
        estimates[model] = {'max_flash':1, 'max_jev':2, 'requested_output_tokens':6144,
            'prior_native_input_tokens':8192 if model == 'glm' else 'not yet observed',
            'fixed_plan_sha256':digest(OLD / f'{model}-plan/result.json')}
    save(ROOT / 'prompt-estimates.json', dict(models=estimates, total_output_token_ceiling=12288,
        search=0, fetch=0, monetary_scheduling_caps_usd={'ollama':3, 'jev':0.30},
        authority='Existing user-confirmed approximately $60 Ollama/$4.77 Jev; no new purchases or billing changes.'))
    print('Captured native response now compiles offline; six findings and all issues retained. No service requests sent.')


if __name__ == '__main__':
    main()
