"""Prepare a new bounded source-path-feedback diagnostic; no requests."""
from pathlib import Path
from flash_study import read,save,digest

ROOT=Path('artifacts/path-feedback-native-20261105')
OLD=Path('artifacts/passage-context-native-20261105')


def main():
    assert not (ROOT/'protocol.json').exists(), 'Never overwrite a frozen phase'
    ROOT.mkdir(exist_ok=True)
    assert read(OLD/'readiness-decision.json')['closed']
    for name in ('diagnostic-authority.json','current-headroom-approval.json','session-boundary.json'):
        save(ROOT/name,read(OLD/name))
    save(ROOT/'prior-accounting.json',read(OLD/'continuation-accounting.json'))
    entry=read(OLD/'review-disposition.json')
    entry.update(predecision_source_path_review=True,
        caps_by_kind={'anchor':{'ollama':1,'jev':3}},
        planned_max_sends={'ollama':2,'jev':6,'search':0,'fetch':0},
        review_report=(ROOT/'REVIEW.md').as_posix(),
        prior_accounting=(ROOT/'prior-accounting.json').as_posix(),
        additional_helpers=['evaluation/run_path_feedback_native.ps1',
            'evaluation/prepare_path_feedback_native.py',
            (ROOT/'prior-accounting.json').as_posix(),
            'src/kaji_langgraph/config/default.yaml','pyproject.toml','uv.lock'],
        mechanism='Separate Jev evidence-path review on the same retained record view BEFORE adjudication, followed by unchanged citation/provenance acceptance checks. Review is labeled fallible feedback, not evidence or client judgment override.',
        postreview_delta=None)
    save(ROOT/'review-disposition.json',entry)
    save(ROOT/'request-estimates.json',dict(
        max_sends=entry['planned_max_sends'],max_output_tokens=12288,
        estimated_flash_input_tokens_per_call=10000,
        estimated_new_path_review_input_tokens_per_call=8000,
        monetary_scheduling_caps_usd={'ollama':3,'jev':.30},
        prior_confirmed_credits_usd={'ollama':'approximately60','jev':'approximately4.77'},
        no_paid_retrieval_or_billing_changes=True,
        estimate_caveat='Conservative scheduling estimates, not provider billing. Existing request ledger enforces call caps and token accounting.'))
    print('Prepared new prospective review packet; no service requests or old phase retries.')


if __name__=='__main__':main()
