# Development evidence triage

The next prospective intervention needs a way to retrieve direct records for each material part of a claim, retain contrary facts, and keep event dates and record dates separate. This follows the scope failure in the fixed-evidence verdict diagnostic. The same three cases and their saved evidence should remain diagnostic controls.

On train-1218, the revision 6 DeepSeek trace spent two early Fetch reservations on PolitiFact's assessment and its NBC affiliate republication. It also tried the same Sanders press-release URL twice across separate queries. The saved Senate documents concern different votes or omit Sanders's individual final-passage vote. The separately found roll call and conditional statement demonstrate what direct records can add. They also leave room to interpret opposition to an earlier form of the bill differently from opposition to the enacted law. See the fixed-evidence decision and the saved revision 6 progress log.

The nine revision 6 candidate journals contain 69 Fetch reservations and just one exact URL repeat. At that slot the highest-ranked unused alternative was a Congressional Record page that the next reservation already fetched. Deduplicating failed URLs alone has little demonstrated leverage here. See retrieval-opportunity-recount.json. Source-family overlap and the framing of the first searches merit separate tests.

Train-1219 is a second development-only lead with two distinct survey origins. Marist's July 2019 crosstab measures views about checks at gun shows and in private sales among 2016 Trump supporters. The 2013 hunter survey announcement describes support for checks with exceptions. The seven-year gap and the wording of the hunter question matter for the February 2020 claim about what hunters want now. These sources are useful retrieval targets and the packet does not yet establish the entire claim under the unchanged acceptance guard.

- [Marist primary crosstabs, PDF page 25](https://maristpoll.marist.edu/wp-content/uploads/2019/07/NPR_PBS-NewsHour_Marist-Poll_USA-NOS-and-Tables_1907190926.pdf#page=25)
- [Bull Moose Sportsmen's Alliance survey announcement](https://www.prnewswire.com/news-releases/hunters-show-strong-support-for-conservation-background-checks-strong-opposition-to-assault-weapons-ban-200273701.html)

The next offline comparison should score whether a source-ranking intervention reaches independently sourced, time-scoped evidence across development claims within the same Fetch allowance. The ranks and citations must come from the evaluated retrieval method. Manually found records can score retrieval and can define diagnostic inputs. They cannot enter candidate inference during the prospective paired comparison.
