param([ValidateSet('development','confirmation')][string]$Phase='development')
$ErrorActionPreference='Stop'
$taskRoot='artifacts/flash-workflow-20261103/strict-literal-workflow-20261105'
if (Test-Path -LiteralPath "$taskRoot/$Phase-decision.json") { throw 'Phase closed; inspect decision, never resume.' }
$env:OMP_NUM_THREADS='2'; $env:MKL_NUM_THREADS='2'; $env:OPENBLAS_NUM_THREADS='2'; $env:NUMEXPR_NUM_THREADS='2'; $env:PYTHONUTF8='1'; $env:OLLAMA_HOST='127.0.0.1:11434'
$taskSuffix=Get-Date -Format 'yyyyMMdd_HHmmss'
$taskHelper=Start-Process -FilePath 'C:\Users\Axioo Pongo\AppData\Local\Programs\Ollama\ollama.exe' -ArgumentList 'serve' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$taskRoot/ollama-$taskSuffix-stdout.log" -RedirectStandardError "$taskRoot/ollama-$taskSuffix-stderr.log"
try {
    $taskReady=$false
    for ($taskCheck=0; $taskCheck -lt 30; $taskCheck++) {
        try { $taskVersion=Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/version' -NoProxy -TimeoutSec 2; $taskReady=$true; break }
        catch { Start-Sleep -Milliseconds 250 }
    }
    if (-not $taskReady) { throw 'No helper; no screen request dispatched.' }
    $taskVersion | ConvertTo-Json | Set-Content -LiteralPath "$taskRoot/ollama-version-$taskSuffix.json"
    & .venv/Scripts/python.exe evaluation/flash_study.py $taskRoot $Phase --limit 2
    if ($LASTEXITCODE -ne 0) { throw "Retained screen failure, code $LASTEXITCODE; inspect records." }
} finally { if (-not $taskHelper.HasExited) { Stop-Process -Id $taskHelper.Id } }
