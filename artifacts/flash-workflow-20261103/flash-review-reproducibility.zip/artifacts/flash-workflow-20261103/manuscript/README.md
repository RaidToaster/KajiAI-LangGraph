# Review draft and evidence snapshot

The eight-page PDF is a venue-neutral review draft. Its Flash section reports the development no-go. It preserves the previously completed Gemma comparison and controlled stopping findings. Both 500-claim Flash evaluations remain unstarted.

`paper.tex` is the editable main file. Compile it with the adjacent `paper-figures` directory. `verification.json` records the successful build, checked source and PDF digests, embedded fonts, and evidence checks.

To reproduce the compact candidate metrics from the evidence archive, extract it into a clean directory. From that directory, extract `artifacts/flash-workflow-20261103/revision-3/source-v3.zip` into the archive root and set `PYTHONPATH` to the extracted `src` directory. Use the dependencies pinned in `uv.lock`. Run the offline commands in `artifacts/flash-workflow-20261103/REPRODUCE.md` from that root. An extracted-archive check independently reproduced the revision 3 metrics and the historical quote audit.
