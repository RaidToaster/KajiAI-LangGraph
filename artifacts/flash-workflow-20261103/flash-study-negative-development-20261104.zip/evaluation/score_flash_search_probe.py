"""Recount discovery of annotated and prespecified source URLs offline."""
import argparse
import gzip
import json
from pathlib import Path
import re
from urllib.parse import parse_qsl, urlencode, urlsplit

from flash_study import read, save


DIRECT_TARGETS = {
    "train-1218": (
        "https://www.sanders.senate.gov/press-releases/sanders-public-option-critical-to-health-reform/",
    ),
    "train-1219": (
        "https://www.prnewswire.com/news-releases/hunters-show-strong-support-for-conservation-background-checks-strong-opposition-to-assault-weapons-ban-200273701.html",
    ),
}


def document_key(url):
    url = re.sub(r"^https?://web\.archive\.org/web/[^/]+/", "", url or "")
    parsed = urlsplit(url)
    host = (parsed.hostname or "").removeprefix("www.")
    if not host:
        return None
    host = "twitter.com" if host == "x.com" else host
    path = parsed.path.rstrip("/")
    query = {k: v for k, v in parse_qsl(parsed.query)
             if not k.startswith("utm_") and k not in {"ref_src", "ref_url"}}
    if host == "senate.gov" and path.endswith("/roll_call_vote_cfm.cfm"):
        if {"congress", "session", "vote"} <= query.keys() and query["vote"].isdigit():
            congress, session, vote = (query[k] for k in ("congress", "session", "vote"))
            path = f"/legislative/LIS/roll_call_votes/vote{congress}{session}/vote_{congress}_{session}_{int(vote):05}.htm"
    if host == "senate.gov" and "/roll_call_votes/" in path:
        for key in ("congress", "session", "vote"):
            query.pop(key, None)
    if host == "politifact.com":
        path = path.lower()
    return f"{host}{path}" + (f"?{urlencode(sorted(query.items()))}" if query else "")


def score(root):
    train = {f"train-{item['row_idx']}": item["row"] for item in read(root.parent / "train-slice.json")["rows"]}
    protocol = read(root / "protocol.json")
    cells = {}
    rows = {}
    for task in protocol["schedule"]:
        directory = root / task["id"]
        path = directory / "result.json"
        if not path.is_file():
            continue
        result = read(path)["results"]
        request = read(directory / "request-001.json")
        response = read(directory / "response-001.json")
        body = (directory / "response-001.body").read_bytes()
        if body.startswith(b"\x1f\x8b"):
            body = gzip.decompress(body)
        expected = json.loads(body)["results"][:protocol["max_results"]]
        if (request["task"] != task or request["service"] != "tinyfish_search"
                or response["status"] != 200 or response.get("error")
                or result != [row for row in expected if isinstance(row, dict)]):
            raise ValueError(f"Probe result differs from its raw search record: {directory}")
        keys = {document_key(row.get("url") or row.get("href")) for row in result} - {None}
        cells.setdefault(task["case"], {}).setdefault(task["arm"], []).append(keys)
    for case, arms in cells.items():
        if any(len(arms.get(arm, [])) != 2 for arm in ("baseline", "candidate")):
            continue
        row = train[case]
        answer_urls = {document_key(answer["source_url"])
                       for question in row["questions"] for answer in question["answers"]} - {None}
        direct = {document_key(url) for url in DIRECT_TARGETS.get(case, ())}
        article = document_key(row["fact_checking_article"])
        rows[case] = {}
        for arm, pools in arms.items():
            keys = set.union(*pools)
            rows[case][arm] = {"annotated_urls": sorted(answer_urls & keys),
                               "prespecified_direct_urls": sorted(direct & keys),
                               "originating_fact_check": article in keys}
    return {"paired_cases": rows, "planned_cases": len(protocol["schedule"]) // 4,
            "scope": "URL discovery in the first five provider results per query. This is not source support or independence."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    args = parser.parse_args()
    save(args.root / "url-overlap.json", score(args.root))
