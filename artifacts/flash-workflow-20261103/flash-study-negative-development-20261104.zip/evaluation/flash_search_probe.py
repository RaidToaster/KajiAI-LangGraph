"""Paired, search-only development probe for initial query planning."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
import subprocess
import sys
import time

import httpx

from kaji_langgraph.query_planning import evidence_queries
from kaji_langgraph.retrieval import TinyFishRetriever
from flash_study import THREADS, digest, read, recorded_retrieval_sends, retrieval_pause_until, save
from runtime_pilot import Ledger, load_keys, transport


def prepare(root):
    cases_path = root.parent / "development-cases.json"
    cases = read(cases_path)
    schedule = []
    for index, (case, row) in enumerate(cases.items()):
        claim = row["claim"]
        baseline = [f"{claim} evidence", f"{claim} counterevidence"]
        candidate = evidence_queries(claim)
        assert len(set([*baseline, *candidate])) == 4
        for slot, pair in enumerate(zip(baseline, candidate), 1):
            arms = list(zip(("baseline", "candidate"), pair))
            if (index + slot) % 2 == 0:
                arms.reverse()
            for arm, query in arms:
                schedule.append({"id": f"{case}-{arm}-{slot}", "case": case, "arm": arm, "query": query})
    save(root / "protocol.json", {
        "schedule": schedule, "caps": {"tinyfish_search": 1}, "max_results": 5,
        "cases_sha256": digest(cases_path), "runner_sha256": digest(Path(__file__)),
        "planner_sha256": digest(Path(sys.modules[evidence_queries.__module__].__file__)),
        "limits": {"tinyfish_search": [[60, 30], [3600, 500]]},
    })


def worker(root, limit):
    manifest = root / "protocol.json"
    protocol = read(manifest)
    if (protocol["runner_sha256"] != digest(Path(__file__))
            or protocol["planner_sha256"] != digest(Path(sys.modules[evidence_queries.__module__].__file__))
            or protocol["cases_sha256"] != digest(root.parent / "development-cases.json")):
        raise ValueError("Frozen inputs changed")
    load_keys()
    sends = recorded_retrieval_sends(root.parent)
    started = 0
    for task in protocol["schedule"]:
        directory = root / task["id"]
        if directory.exists():
            if not (directory / "result.json").is_file():
                raise SystemExit(f"Unresolved started cell: {directory}")
            continue
        if started == limit:
            break
        now = time.time()
        resume_at = retrieval_pause_until(sends, protocol["limits"], now)
        if resume_at > now:
            print("Next untouched cell can start at", datetime.fromtimestamp(resume_at, timezone.utc), flush=True)
            break
        directory.mkdir()
        save(directory / "attempt.json", {**task, "protocol_sha256": digest(manifest)})
        save(directory / "live-state.json", {"counts": {"tinyfish_search": 0}, "deadline": now + 25, "stop": None})
        ledger = Ledger(directory, protocol)
        ledger.task = task

        class SearchOnly(TinyFishRetriever):
            def _request(self, url, *, payload=None, timeout):
                if payload is not None or not url.startswith("https://api.search.tinyfish.ai?query="):
                    raise ValueError("Only TinyFish Search GET is allowed")
                with httpx.Client(transport=transport(httpx, ledger, "tinyfish_search"), timeout=timeout,
                                  trust_env=False, follow_redirects=False) as client:
                    response = client.get(url, headers={"X-API-Key": os.environ["TINYFISH_API_KEY"]})
                    response.raise_for_status()
                    return response.json()

        results = SearchOnly().search(task["query"], max_results=protocol["max_results"])
        if read(directory / "live-state.json")["stop"]:
            raise SystemExit(f"Provider stop: {directory}")
        save(directory / "result.json", {"results": results})
        request = read(directory / "request-001.json")
        sends.append({"service": request["service"], "sent_at": request["timestamp"]})
        started += 1
        print(task["id"], len(results), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare", action="store_true")
    mode.add_argument("--limit", type=int, choices=(4, 8))
    mode.add_argument("--worker", type=int, choices=(4, 8), help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.prepare:
        if (args.root / "protocol.json").exists():
            raise SystemExit("Search probe already frozen")
        args.root.mkdir(parents=True, exist_ok=True)
        prepare(args.root)
    elif args.worker:
        worker(args.root, args.worker)
    else:
        lock = args.root / "running.lock"
        with lock.open("x", encoding="utf-8") as handle:
            print(os.getpid(), file=handle)
        try:
            subprocess.run([sys.executable, __file__, str(args.root), "--worker", str(args.limit)],
                           env={**os.environ, **THREADS, "PYTHONUTF8": "1"}, timeout=300, check=True)
        finally:
            lock.unlink()


if __name__ == "__main__":
    main()
