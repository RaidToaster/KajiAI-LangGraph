"""Offline, failure-inclusive reconciliation of the Flash development snapshot.

Run from the repository root. No service requests are made; old revision metrics
are recomputed from their own saved results, not rerun with a newer parser.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path

from analyze_flash_study import analyze
from flash_study import MODELS, attempt_path, digest, read, save, scan, task_id


def verify(root: Path) -> dict:
    revisions = []
    unique = {}
    for number in range(1, 9):
        run = root if number == 1 else root / f"revision-{number}"
        protocol = read(run / "development.json")
        report = analyze(run, "development")
        if read(run / "development-analysis.json") != report:
            raise ValueError(f"Saved analysis differs from retained records: {run}")
        rows = []
        for task in protocol["schedule"]:
            directory = attempt_path(run, "development", protocol, task)
            row = {"cell": task_id(task), "path": directory.as_posix(),
                   "started": (directory / "attempt.json").is_file(),
                   "reused": task_id(task) in protocol.get("reused_attempts", {})}
            if row["started"]:
                usage = scan(directory, MODELS[task["model"]])
                if usage != read(directory / "usage.json"):
                    raise ValueError(f"Raw transport mismatch: {directory}")
                job = read(directory / "job.json")
                # Some earlier transport failures legitimately have no response.
                # Preserve them, and report rather than inventing token usage.
                identity = directory.as_posix()
                files = {p.name: digest(p) for p in sorted(directory.iterdir())
                         if p.is_file() and p.suffix not in {".log", ".tmp"}}
                unique[identity] = {"task": task, "files": files, "job": job,
                                    "usage": usage}
            rows.append(row)
        revisions.append({"revision": number, "protocol_sha256": digest(run / "development.json"),
                          "analysis_sha256": digest(run / "development-analysis.json"),
                          "attempted": report["attempted"], "cells": rows,
                          "models": report["models"], "new_usage": report["actual_usage"]})

    final = read(root / "final-cases.json")
    manifest = read(root / "final-case-manifest.json")
    assert len(final) == manifest["n"] == 500
    assert list(final) == manifest["ids"]
    assert digest(root / "final-cases.json") == manifest["cases_sha256"]
    confirm = read(root / "confirmation-cases.json")
    dev = read(root / "development-cases.json")
    normalize = lambda c: " ".join(c["claim"].lower().split())
    sets = [set(map(normalize, values.values())) for values in (dev, confirm, final)]
    assert not (sets[0] & sets[1] or sets[0] & sets[2] or sets[1] & sets[2])
    advanced = []
    for attempt in root.rglob("attempt.json"):
        parts = attempt.relative_to(root).parts
        if "confirmation" in parts or "final" in parts:
            advanced.append(attempt.as_posix())
    # Snapshot has no released candidate. A future started phase must receive its
    # own verifier rather than being silently reported as an untouched phase.
    assert not advanced, advanced
    latest = revisions[-1]
    glm = latest["models"]["glm"]
    bmax = glm["baseline"]["counts"].get("failed", 0) + 8 - glm["baseline"]["raw"]["n"]
    cfailed = glm["candidate"]["counts"].get("failed", 0)
    assert cfailed > bmax
    decision = read(root / "revision-8/development-decision.json")
    assert decision["passed"] is False and decision["closed_early"] is True
    assert decision["binding_guard"]["maximum_baseline_failed"] == bmax
    services = Counter()
    missing = []
    for identity, record in unique.items():
        for send in record["usage"]:
            services[send["service"]] += 1
            if send.get("model_verified") is False:
                raise ValueError(f"Unexpected model identity: {identity}")
            if send["service"] in {"ollama", "jev"} and not send.get("model_verified"):
                missing.append({"path": identity, "send": send})
    packet_root = root / "method-packet-replay"
    packet_decision = read(packet_root / "decision.json")
    packet_usage = []
    for cell in packet_decision["cells"]:
        directory = packet_root / cell["id"]
        if not cell["started"]:
            assert not directory.exists()
            continue
        model = cell["id"].split("-", 1)[0]
        usage = scan(directory, MODELS[model])
        assert usage == read(directory / "usage.json")
        assert not read(directory / "job.json")["hard_stop"]
        assert not read(directory / "result.json")["gate_eligible"]
        assert digest(directory / "result.json") == cell["result_sha256"]
        packet_usage.extend(usage)
    assert packet_decision["passed"] is False
    assert packet_decision["started_attempts"] == 2
    assert len(packet_usage) == 4
    windows = read(root / "method-window-diagnostic/replay.json")
    assert windows["packet_count"] == 26 and windows["changed_packet_count"] == 6
    assert all(p["original_reconstructed"] for p in windows["packets"])
    assert all(not p["changed_sources"] for p in windows["packets"]
               if p["case"] in {"train-1217", "train-1205"})

    # Recount headline historical results from raw per-claim records as well.
    from kaji_langgraph.evaluation import classification_metrics
    history = Path("evaluation/results/study-20261009-v3")
    metrics = read(history / "study-metrics.json")
    historical = {}
    for folder, key in (("full", "full_predictions"), ("closed_book", "closed_book_predictions")):
        with (history / folder / "results.jsonl").open(encoding="utf-8") as stream:
            records = [json.loads(line) for line in stream if line.strip()]
        assert len(records) == len({r["claim_id"] for r in records}) == 500
        computed = classification_metrics([r["gold_label"] for r in records],
                                           [r["predicted_label"] for r in records])
        assert all(metrics["metrics"][key][k] == v for k, v in computed.items())
        historical[folder] = {"n": len(records), "accuracy": computed["accuracy"],
                              "macro_f1": computed["macro_f1"],
                              "raw_sha256": digest(history / folder / "results.jsonl")}
        if folder == "full":
            gate = classification_metrics([r["gold_label"] for r in records],
                                          [r["accepted_label"] for r in records])
            assert all(metrics["metrics"]["full_policy"][k] == v for k, v in gate.items())
            historical[folder]["accepted"] = sum(r["accepted_label"] != "ABSTAIN" for r in records)
            historical[folder]["correct_accepted"] = sum(r["accepted_label"] == r["gold_label"] for r in records)
    return {
        "scope": "Revisions 1-8 workflow cells only; standalone diagnostics remain separately journaled.",
        "status": "Development candidate closed; overall requested study incomplete.",
        "revisions": revisions, "unique_workflow_attempts": len(unique),
        "unique_attempt_records": unique, "service_reservations_unique": dict(services),
        "model_reservations_without_verified_reply": missing,
        "packet_diagnostic": {"started": 2, "untouched": 2, "gate_eligible": 0,
                              "service_reservations": dict(Counter(s["service"] for s in packet_usage)),
                              "decision_sha256": digest(packet_root / "decision.json")},
        "historical_headline_recount": historical,
        "revision_8_futility": {"candidate_failures": cfailed, "baseline_maximum": bmax},
        "confirmation": {"planned_cases": len(confirm), "started_attempts": len(advanced)},
        "final_manifest_sha256": digest(root / "final-case-manifest.json"),
        "final_cases_sha256": manifest["cases_sha256"],
        "final_arms": [{"model": model, "requested_tag": tag, "arm": arm,
                        "planned": len(final), "started": 0, "untouched": len(final)}
                       for model, tag in MODELS.items() for arm in ("baseline", "candidate")],
        "claim_limit": "Untouched final cells are not failed attempts or completed evaluation denominators.",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = verify(args.root)
    destination = args.output or args.root / "snapshot-verification.json"
    save(destination, result)
    print(result["status"])
    print("Unique workflow attempts:", result["unique_workflow_attempts"])
    print("Unique service reservations:", result["service_reservations_unique"])
    print("Final attempts started: 0/2000; no fabricated failures for untouched cells.")
