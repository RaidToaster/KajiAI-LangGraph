"""Check whether already retrieved articles expose underlying source links."""
import argparse
from pathlib import Path
import os
import subprocess
import sys
import time

import httpx

from flash_study import THREADS, digest, read, recorded_retrieval_sends, retrieval_pause_until, save
from runtime_pilot import Ledger, load_keys, transport
from score_flash_search_probe import document_key


def run(root):
    protocol = read(root / "protocol.json")
    source = root.parent / "train-slice.json"
    if (protocol["runner_sha256"] != digest(Path(__file__))
            or protocol["train_slice_sha256"] != digest(source)):
        raise ValueError("Frozen link probe inputs changed")
    load_keys()
    targets = {f"train-{row['row_idx']}": {
        document_key(answer["source_url"])
        for question in row["row"]["questions"] for answer in question["answers"]
    } - {None} for row in read(source)["rows"]}
    sends = recorded_retrieval_sends(root.parent)
    for task in protocol["schedule"]:
        cell = root / task["case"]
        if cell.exists():
            if not (cell / "result.json").is_file():
                raise SystemExit(f"Unresolved started cell: {cell}")
            continue
        parent = Path(task["saved_result"])
        if digest(parent) != task["saved_sha256"]:
            raise ValueError("Parent attempt changed")
        if not any(row["url"] == task["url"] and row["page_text"] for row in read(parent)["result"]["retrieval_ledger"]):
            raise ValueError("Parent URL must have already been fetched in development")
        now = time.time()
        if retrieval_pause_until(sends, {"tinyfish_fetch": [[60, 150], [86400, 1000]]}, now) > now:
            raise SystemExit("Wait for the free Fetch window before starting another cell")
        cell.mkdir()
        save(cell / "attempt.json", {**task, "protocol_sha256": digest(root / "protocol.json")})
        save(cell / "live-state.json", {"counts": {"tinyfish_fetch": 0}, "deadline": now + 30, "stop": None})
        ledger = Ledger(cell, {"caps": {"tinyfish_fetch": 1}})
        ledger.task = task["case"]
        with httpx.Client(transport=transport(httpx, ledger, "tinyfish_fetch"), timeout=25,
                          trust_env=False, follow_redirects=False) as client:
            reply = client.post("https://api.fetch.tinyfish.ai",
                                headers={"X-API-Key": os.environ["TINYFISH_API_KEY"]},
                                json={"urls": [task["url"]], "format": "markdown", "links": True,
                                      "ttl": 0, "per_url_timeout_ms": 20000})
            reply.raise_for_status()
        value = reply.json()
        if read(cell / "live-state.json")["stop"]:
            raise SystemExit(f"Provider stop: {cell}")
        records = value.get("results", [])
        links = records[0].get("links") if records else None
        if links is not None and (not isinstance(links, list) or not all(isinstance(url, str) for url in links)):
            raise ValueError("Unexpected TinyFish links response")
        matches = sorted({document_key(url) for url in links or []} & targets[task["case"]])
        save(cell / "result.json", {"link_count": len(links or []), "has_link_field": links is not None,
                                    "matched_annotation_urls": matches, "errors": value.get("errors", [])})
        reservation = read(cell / "request-001.json")
        sends.append({"service": "tinyfish_fetch", "sent_at": reservation["timestamp"]})
        print(task["case"], len(links or []), matches, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        run(args.root)
    else:
        lock = args.root / "running.lock"
        with lock.open("x", encoding="utf-8") as handle:
            print(os.getpid(), file=handle)
        try:
            subprocess.run([sys.executable, __file__, str(args.root), "--worker"],
                           env={**os.environ, **THREADS, "PYTHONUTF8": "1"}, timeout=300, check=True)
        finally:
            lock.unlink()
