"""Check the development PDF against retained Flash and historical metrics."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil

from pypdf import PdfReader


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def verify(root, visual):
    manuscript = root / "manuscript"
    build = manuscript / "build-20261104/paper.pdf"
    compilation = read(manuscript / "compilation-20261104-live.json")
    assert compilation["exitCode"] == 0 and compilation["pdfExists"]
    assert "Overfull" not in compilation["log"]
    reader = PdfReader(build)
    assert len(reader.pages) == 10
    text = "\n".join(p.extract_text() for p in reader.pages)
    assert "??" not in text and "[?]" not in text
    source = (manuscript / "paper.tex").read_text(encoding="utf-8")
    citations = {k for group in re.findall(r"\\cite\{([^}]+)\}", source) for k in group.split(",")}
    bibliography = set(re.findall(r"\\bibitem\{([^}]+)\}", source))
    assert citations == bibliography and len(bibliography) == 11
    metrics = read(root / "revision-8/development-analysis.json")
    rows = []
    for key, label in (("glm", "GLM"), ("deepseek", "DeepSeek")):
        pair = metrics["models"][key]["paired"]
        for arm, name in (("baseline", "Current"), ("candidate", "Candidate")):
            m = pair[arm]
            n = m["raw"]["n"]
            correct = round(m["raw"]["accuracy"] * n)
            accepted = m["counts"].get("accepted", 0)
            failed = m["counts"].get("failed", 0)
            row = f"{label} & {name} & {correct}/{n} & {m['raw']['macro_f1']:.3f} & {accepted}/{n} & {failed}/{n}"
            assert row in source, row
            rows.append(row)
    history = read(Path("evaluation/results/study-20261009-v3/study-metrics.json"))
    for key in ("full_predictions", "closed_book_predictions"):
        assert f"{history['metrics'][key]['accuracy'] * 100:.1f}" in text
    packet = read(root / "method-packet-replay/decision.json")
    assert packet["started_attempts"] == 2 and packet["untouched_attempts"] == 2
    assert "two GLM sends" in source and "0.79" in source and "0.80" in source
    assert "64 unique workflow attempts" in source
    assert "not a completed Flash evaluation" in source
    fonts = {}

    def resources(resource):
        resource = resource.get_object()
        for value in resource.get("/Font", {}).values():
            font = value.get_object()
            if "/DescendantFonts" in font:
                font = font["/DescendantFonts"][0].get_object()
            desc = font.get("/FontDescriptor")
            desc = desc.get_object() if desc else {}
            fonts[str(font.get("/BaseFont"))] = any(k in desc for k in ("/FontFile", "/FontFile2", "/FontFile3"))
        for obj in resource.get("/XObject", {}).values():
            obj = obj.get_object()
            if "/Resources" in obj:
                resources(obj["/Resources"])

    for page in reader.pages:
        resources(page["/Resources"])
    assert fonts and all(fonts.values())
    assert visual, "Inspect rendered pages before recording verification"
    shutil.copyfile(build, manuscript / "paper.pdf")
    result = {"pages": len(reader.pages), "paper_sha256": digest(manuscript / "paper.pdf"),
              "source_sha256": digest(manuscript / "paper.tex"), "embedded_fonts": fonts,
              "checks": ["successful Tectonic build", "zero overfull boxes or unresolved text markers",
                         "all pages rendered and visually inspected", "all fonts embedded",
                         "revision 8 paired table rebuilt from retained records",
                         "historical headline and packet diagnostic counts checked"],
              "paired_table_rows": rows,
              "snapshot_sha256": digest(root / "snapshot-verification.json"),
              "claim_map_sha256": digest(root / "CLAIM_RECORD_MAP.md"),
              "scope": "Verified negative development review draft. Full requested Flash study incomplete; confirmation and all final arms untouched."}
    (manuscript / "verification.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("pages", "paper_sha256", "source_sha256", "scope")}, indent=2))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("root", type=Path)
    p.add_argument("--visual-review-complete", action="store_true")
    args = p.parse_args()
    verify(args.root, args.visual_review_complete)
