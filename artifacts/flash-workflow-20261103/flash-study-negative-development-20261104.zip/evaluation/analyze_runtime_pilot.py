"""Analyze all planned pilot attempts, including missing and failed conditions."""
import argparse
from collections import Counter
import json
import gzip
from pathlib import Path

from kaji_langgraph.evaluation import load_dataset, prediction_label
from kaji_langgraph.graph import _unused_queries
from kaji_langgraph.models import EvidenceAssessment


def analyze(run):
    protocol=json.loads((run/"pilot-protocol.json").read_text(encoding="utf8"))
    data=load_dataset(Path("evaluation/results/study-20261009-v3/dataset-snapshot.json"))
    requests=[json.loads(p.read_text(encoding="utf8")) for p in sorted(run.glob("request-*.json"))]
    counts=Counter(x["service"] for x in requests)
    observed_ollama_tokens=0
    observed_jev_tokens=0
    missing_jev_usage=0
    missing_usage=0
    outputs=[]
    for path in sorted(run.glob("request-*.json")):
        request=json.loads(path.read_text(encoding="utf8"))
        body=run/path.name.replace("request-","response-").replace(".json",".body")
        if request["service"] == "jev":
            if body.exists():
                raw=body.read_bytes()
                value=json.loads(gzip.decompress(raw) if raw.startswith(b"\x1f\x8b") else raw)
                usage=value.get("usage",{})
                if all(isinstance(usage.get(k),int) for k in ["input_tokens","output_tokens"]):
                    observed_jev_tokens+=usage["input_tokens"]+usage["output_tokens"]
                else:missing_jev_usage+=1
            else:missing_jev_usage+=1
            continue
        if request["service"] != "ollama":continue
        done=[]
        if body.exists():
            for line in body.read_bytes().splitlines():
                try:
                    value=json.loads(line)
                    if value.get("done"):done.append(value)
                except ValueError:pass
        if done and all(isinstance(done[-1].get(k),int) for k in ["prompt_eval_count","eval_count"]):
            observed_ollama_tokens+=done[-1]["prompt_eval_count"]+done[-1]["eval_count"]
            outputs.append(done[-1]["eval_count"])
        else:missing_usage+=1
    rows=[]
    for claim_id in protocol["claim_ids"]:
        for condition in ["baseline","query_exhaustion"]:
            task=f"{claim_id}-{condition}"
            path=run/f"{task}.result.json"
            row={"claim_id":claim_id,"condition":condition,"gold":data[claim_id]["label"],
                 "status":"missing","predicted_label":"ABSTAIN","accepted_label":"ABSTAIN",
                 "stop_reason":"not_completed","requests":dict(Counter(x["service"] for x in requests if x.get("task")==task))}
            if path.exists():
                value=json.loads(path.read_text(encoding="utf8"));result=value["result"]
                row.update(status=result["verification_status"],predicted_label=value["predicted_label"],
                    accepted_label=value["accepted_label"],stop_reason=result["stop_reason"],
                    elapsed_seconds=result["elapsed_seconds"],rounds=len(result["research_history"]),
                    observed_graph_tokens=result["budget"]["tokens_used"],
                    graph_usage_complete=result["budget"]["token_usage_complete"],errors=result["errors"],
                    assertion_count=len(result["assertions"]),
                    resolved_assertions=sum(a["resolved"] for a in result["research_history"][-1]["assessment"]["assertions"]) if result["research_history"] else 0,
                    citations=sum(len(e["source_urls"]) for e in result["evidence"]),
                    literal_quotes_valid=sum(any(quote in (s["page_text"] or s["snippet"])
                        for s in result["retrieval_ledger"] if s["url"]==url)
                        for e in result["evidence"] for url,quote in e["quotes"].items()),
                    automated_citation_reviews=len(result["jev_audit"].get("citations",[])))
                used=[]
                eligibility=[]
                for history in result["research_history"]:
                    used.extend(history["queries"])
                    if history["round_number"]>=3:continue
                    exhausted=not _unused_queries({"claim":result["claim"],"assertions":result["assertions"],
                        "assessment":EvidenceAssessment.model_validate(history["assessment"]),"search_queries":used})
                    eligibility.append({"round":history["round_number"],"query_inventory_exhausted":exhausted,
                        "semantic_review_guard_blocked":bool(history["semantic_gaps"]),"semantic_gaps":history["semantic_gaps"]})
                row["prelimit_stop_eligibility"]=eligibility
            rows.append(row)
    paired=[]
    for claim_id in protocol["claim_ids"]:
        base,candidate=[x for x in rows if x["claim_id"]==claim_id]
        complete=all(x["status"] not in {"missing","execution_error"} for x in [base,candidate])
        paired.append({"claim_id":claim_id,"complete_successful_pair":complete,
            "candidate_triggered":candidate["stop_reason"]=="query_exhausted",
            "label_loss":complete and base["predicted_label"]==base["gold"] and candidate["predicted_label"]!=candidate["gold"],
            "label_gain":complete and base["predicted_label"]!=base["gold"] and candidate["predicted_label"]==candidate["gold"],
            "acceptance_loss":complete and base["accepted_label"]!="ABSTAIN" and candidate["accepted_label"]=="ABSTAIN",
            "ollama_call_delta":candidate["requests"].get("ollama",0)-base["requests"].get("ollama",0) if complete else None})
    result={"scope":"Two-claim development feasibility pilot; contemporary live web, no generalization claim",
        "planned_workflows":4,"saved_workflow_results":sum(x["status"]!="missing" for x in rows),
        "successful_workflows":sum(x["status"] not in {"missing","execution_error"} for x in rows),
        "requests":dict(counts),"total_actual_requests":len(requests),
        "ollama_transport_observed_tokens_including_failed_attempts_and_smoke":observed_ollama_tokens,
        "ollama_usage_missing_requests":missing_usage,"ollama_output_tokens":outputs,
        "jev_transport_observed_tokens_including_failed_attempts":observed_jev_tokens,
        "jev_usage_missing_requests":missing_jev_usage,
        "rows":rows,"paired":paired,"full_study_decision":"NO GO",
        "human_citation_validation":"not performed; human fields remain blank",
        "caveats":["One early attempt failed because of local UTF-8 logging; retain in denominator.",
                   "Only untouched conditions continued after all dispatched outcomes were verified; original counters/deadline retained.",
                   "Independent web and model responses can drift across conditions.",
                   "Requested output cap and disabled retries differ from historical execution for both arms.",
                   "Missing/failed conditions prevent paired efficacy conclusions; do not impute outcomes.",
                   "Observed transport usage can exceed graph usage after a local exception; neither is a monetary estimate."]}
    (run/"pilot-analysis.json").write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding="utf8")
    lines=["# Actual bounded live pilot", "",f"Actual service requests: {len(requests)}. Planned workflow denominator: 4.","",
        "| Claim | Condition | Status | Prediction | Accepted | Stop | Ollama sends |",
        "|---|---|---|---|---|---|---:|"]
    for row in rows:
        lines.append(f"| {row['claim_id']} | {row['condition']} | {row['status']} | {row['predicted_label']} | {row['accepted_label']} | {row['stop_reason']} | {row['requests'].get('ollama',0)} |")
    lines.extend(["","Full study: **NO GO**. Raw attempts and failures remain separate from the completed historical study.","",
                  "Both candidate trajectories exhausted queries after round 2, but uncertain or contradicting citation reviews kept the conservative semantic-review guard active. Both therefore retained round 3; this pilot demonstrates no stopping savings.","",
                  "Human citation validation was not performed. No automated review is represented as human evidence.","",*result["caveats"]])
    (run/"LIVE_RESULTS.md").write_text("\n".join(lines)+"\n",encoding="utf8")
    return result


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--run",required=True,type=Path)
    args=parser.parse_args();result=analyze(args.run)
    print(json.dumps({k:v for k,v in result.items() if k not in {"rows","paired","caveats"}},indent=2))
