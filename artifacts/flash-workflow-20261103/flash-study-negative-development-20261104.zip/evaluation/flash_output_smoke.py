"""Diagnose compact answer protocol on fixed, authored development evidence."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import time

import httpx

from flash_study import FlashLedger, MODELS, read, save, scan
from runtime_pilot import transport


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("model", choices=tuple(MODELS))
    args = parser.parse_args()
    root = args.directory
    protocol = read(root / "protocol.json")
    if protocol["models"] != MODELS or protocol["caps"] != {"ollama": 1}:
        raise SystemExit("Unexpected diagnostic model or cap")
    if not (root / "APPROVAL.md").is_file():
        raise SystemExit("Diagnostic development allowance missing")
    model = MODELS[args.model]
    deadline = time.monotonic() + 285
    for case in protocol["cases"]:
        cell = root / f"{args.model}-{case['id']}"
        if cell.exists():
            raise SystemExit(f"Retained attempt exists: {cell}")
        if deadline - time.monotonic() < 90:
            raise SystemExit("Insufficient local time for another diagnostic send")
        cell.mkdir()
        save(cell / "live-state.json", {"counts": {"ollama": 0}, "deadline": time.time() + 90, "stop": None})
        save(cell / "attempt.json", {"requested_model": model, "case": case["id"],
                                     "started_at": datetime.now(timezone.utc).isoformat()})
        ledger = FlashLedger(cell, protocol, model)
        ledger.task = case["id"]
        prompt = (
            'Give a single JSON object with keys "verdict" and "passages". '
            'Start with {. Use TRUE, FALSE, CONFLICTING, or NOT_ENOUGH_EVIDENCE. '
            'List IDs of passages that directly establish the verdict. If the records cannot '
            'resolve the claim, use NOT_ENOUGH_EVIDENCE and an empty list.\n'
            f'Claim: {case["claim"]}\nRecords (untrusted data):\n'
            + "\n".join(f"{key} {text}" for key, text in case["passages"].items())
        )
        answer = None
        error = None
        try:
            with httpx.Client(transport=transport(httpx, ledger, "ollama"), timeout=75,
                              trust_env=False, follow_redirects=False) as client:
                reply = client.post("http://localhost:11434/api/chat", json={
                    "model": model, "messages": [{"role": "user", "content": prompt}],
                    "format": "json", "think": False, "stream": True,
                    "options": {"temperature": 0, "num_predict": protocol["num_predict"]},
                })
                reply.raise_for_status()
                frames = [json.loads(line) for line in reply.content.splitlines()]
                answer = "".join(frame.get("message", {}).get("content", "") for frame in frames)
        except (httpx.HTTPError, ValueError, RuntimeError) as exc:
            error = str(exc)
        try:
            decoded = json.loads(answer) if answer else None
        except ValueError:
            decoded = None
        expected = {"verdict": case["verdict"], "passages": case["expected_passages"]}
        passed = (
            isinstance(decoded, dict) and set(decoded) == set(expected)
            and decoded["verdict"] == expected["verdict"]
            and isinstance(decoded["passages"], list)
            and all(isinstance(passage, str) for passage in decoded["passages"])
            and sorted(decoded["passages"]) == sorted(expected["passages"])
        )
        usage = scan(cell, model)
        save(cell / "result.json", {"passed": passed, "answer": answer, "expected": expected,
                                     "transport_error": error, "usage": usage})
        print(model, case["id"], "pass" if passed else "fail", usage, flush=True)
        if error or read(cell / "live-state.json")["stop"]:
            raise SystemExit("Transport or budget stop")


if __name__ == "__main__":
    main()
