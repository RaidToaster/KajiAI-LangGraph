"""Package a local negative-development snapshot without secrets or Git state."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def collect():
    files = set()

    def tree(root, keep=lambda p: True):
        for path in root.rglob("*"):
            if (path.is_file() and "__pycache__" not in path.parts
                    and not path.name.startswith(".env") and keep(path)):
                files.add(path)

    study = Path("artifacts/flash-workflow-20261103")

    def study_keep(path):
        relative = path.relative_to(study)
        if len(relative.parts) == 1 and path.suffix == ".zip":
            return path.name.startswith("source-")
        if any(part.startswith("render") or part.startswith("pytest") for part in relative.parts):
            return False
        if "manuscript" in relative.parts and any(part.startswith("build") for part in relative.parts):
            return relative.as_posix() == "manuscript/build-20261104/paper.pdf"
        return path.suffix != ".tmp"

    tree(study, study_keep)
    tree(Path("src"))
    tree(Path("tests"), lambda p: p.suffix in {".py", ".json", ".yaml", ".yml", ".md"})
    tree(Path("evaluation/results/study-20261009-v3"))
    for path in Path("evaluation").glob("*.py"):
        files.add(path)
    stopping = Path("artifacts/aris/run_20261103_exhaustion_9c7e12bf")
    tree(stopping, lambda p: not any(part.startswith(("render", "pytest", "paper-build"))
                                    for part in p.relative_to(stopping).parts))
    pilot = Path("artifacts/aris/run_20261102_222304_bdd31bb4")
    for path in pilot.iterdir():
        if not path.is_file():
            continue
        if (path.name.startswith(("request-", "response-")) or path.name.endswith((".result.json", ".job.json"))
                or path.name in {"pilot-analysis.json", "USAGE.json", "PILOT_PROTOCOL.md", "pilot-protocol.json",
                                 "LIVE_APPROVAL.json", "LIVE_RESULTS.md", "FULL_STUDY_DECISION.md",
                                 "environment.json", "source-final.zip", "recovery-unstarted.json"}):
            files.add(path)
    for name in ("AGENTS.md", "SESSION_HANDOFF.md", "CONTINUATION.md", "pyproject.toml", "uv.lock", "README.md"):
        files.add(Path(name))
    return sorted(files)


def main():
    output = Path("artifacts/flash-workflow-20261103/flash-study-negative-development-20261104.zip")
    if output.exists():
        raise SystemExit("Snapshot already exists; choose a new name rather than overwrite evidence")
    files = collect()
    manifest = {path.as_posix(): {"sha256": sha(path), "bytes": path.stat().st_size} for path in files}
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files:
            archive.write(path, path.as_posix())
        archive.writestr("PACKAGE_MANIFEST.json", json.dumps({
            "scope": "Verified negative development snapshot; final Flash study incomplete.",
            "file_count": len(files), "files": manifest,
        }, indent=2) + "\n")
    checksum = {"archive": output.as_posix(), "sha256": sha(output),
                "bytes": output.stat().st_size, "file_count": len(files),
                "scope": "No qualifying workflow; no confirmation or final attempts."}
    output.with_suffix(".sha256.json").write_text(json.dumps(checksum, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(checksum, indent=2))


if __name__ == "__main__":
    main()
