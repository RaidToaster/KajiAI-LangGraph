"""Rebuild Flash service counts and answer-shape diagnostics from raw replies."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path

from kaji_langgraph.llm import OllamaBackend
from kaji_langgraph.models import BenchmarkAssessment

from flash_study import MODELS, read, save, scan


def answer_content(path):
    frames = (json.loads(line) for line in path.read_bytes().splitlines())
    return "".join(frame.get("message", {}).get("content", "") for frame in frames)


def audit(root):
    totals = Counter()
    rows = []
    for usage_path in sorted(root.rglob("usage.json")):
        directory = usage_path.parent
        if directory == root:
            continue  # Windows also matches the phase-wide USAGE.json here.
        attempt = read(directory / "attempt.json")
        model = MODELS[attempt["model"]]
        sends = scan(directory, model)
        if sends != read(usage_path):
            raise ValueError(f"Usage does not match raw transport in {directory}")
        group = directory.relative_to(root).parts[0]
        revision = group if group.startswith("revision") else "original"
        for send in sends:
            service = send["service"]
            totals[service] += 1
            totals[f"{service}_input_tokens"] += send.get("input_tokens", 0)
            totals[f"{service}_output_tokens"] += send.get("output_tokens", 0)
            totals["incomplete"] += bool(send.get("incomplete"))
            if service != "ollama" or not send.get("model_verified"):
                continue
            index = send["request_id"]
            request = read(directory / f"request-{index}.json")["request"]["body"]
            prompt = request["messages"][-1]["content"]
            if prompt.startswith("You are an evidence analyst"):
                kind = "assessment"
            elif prompt.startswith("Convert the draft below"):
                kind = "empty_draft_repair" if not prompt.rpartition("\nDraft:\n")[2].strip() else "repair"
            else:
                continue
            content = answer_content(directory / f"response-{index}.body")
            try:
                parsed = OllamaBackend._parse_json(BenchmarkAssessment, content)
            except ValueError:
                parsed = None
            rows.append({
                "revision": revision, "attempt": directory.name, "model": model,
                "arm": attempt["arm"], "kind": kind, "request_id": index,
                "input_tokens": send["input_tokens"], "output_tokens": send["output_tokens"],
                "done_reason": send["done_reason"], "answer_characters": len(content),
                "parsed_verdict": parsed.proposed_verdict if parsed else None,
                "findings": len(parsed.evidence) if parsed else None,
            })
    return {"totals": dict(totals), "assessment_sends": rows}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    args = parser.parse_args()
    result = audit(args.run)
    save(args.run / "transport-recount.json", result)
    print(result["totals"])


if __name__ == "__main__":
    main()
