"""Bounded paired fixed-packet test of replication-window visibility."""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from flash_study import FlashLedger, MODELS, THREADS, digest, read, save, scan
from flash_method_windows import select
from kaji_langgraph.evaluation import code_digest
from kaji_langgraph.study_analysis import replay_sources
from recount_flash_transport import answer_content
from runtime_pilot import load_keys, transport


def prepare(root, out):
    replay = read(root / "method-window-diagnostic/replay.json")
    config = read(root / "revision-8/development.json")["config"]
    cells = []
    for model, arm in (("glm", "original"), ("glm", "method"),
                       ("deepseek", "method"), ("deepseek", "original")):
        packet = next(p for p in replay["packets"] if p["case"] == "train-1225"
                      and p["model"] == model and p["round"] == 1)
        request = Path(packet["request"])
        source_result = request.parent / "result.json"
        result = read(source_result)["result"]
        body = deepcopy(read(request)["request"]["body"])
        prompt = body["messages"][-1]["content"]
        before, rest = prompt.split("Retrieved records:\n", 1)
        _, end = json.JSONDecoder().raw_decode(rest)
        records = packet["candidate_records"] if arm == "method" else packet["original_records"]
        body["messages"][-1]["content"] = before + "Retrieved records:\n" + json.dumps(records, ensure_ascii=False) + rest[end:]
        cells.append({"id": f"{model}-{arm}", "model": model, "arm": arm,
                      "source_request": request.as_posix(), "source_result": source_result.as_posix(),
                      "source_request_sha256": digest(request), "source_result_sha256": digest(source_result),
                      "request": body})
    out.mkdir(exist_ok=True)
    if (out / "protocol.json").exists():
        raise SystemExit("Protocol already frozen")
    save(out / "protocol.json", {
        "models": MODELS, "caps": {"ollama": 1, "jev": 4}, "num_predict": 8192,
        "config": config, "source_sha256": code_digest(), "cases": cells,
        "runner_sha256": digest(Path(__file__)),
        "selector_sha256": digest(Path(__file__).with_name("flash_method_windows.py")),
        "screen": "Both revised packets must yield a parseable TRUE proposal with valid exact passage IDs, correctly describe and cite the distinct replication, and pass the unchanged structural, Jev citation and provenance gates. Report matched original packets. No loss of raw correctness or added unsupported acceptance. Failures remain in the four-send denominator. A positive is a development fixed-packet existence test only, not prospective workflow or confirmation evidence.",
        "audit_limits": "Assess historical data quantities, conversion, shared SCF input and separate calculation action. High confidence is measured, never forced. Research-agent audit remains separate from human annotation.",
    })


def execute(out, protocol, case):
    import httpx
    import httpx2
    from typesafe_sdk import RetryPolicy, TypeSafeClient
    import kaji_langgraph.jev as jev_module
    from kaji_langgraph.assessment_lines import parse_assessment_lines
    from kaji_langgraph.config import effective_policy
    from kaji_langgraph.graph import WorkflowNodes
    from kaji_langgraph.llm import _resolve_passage_ids
    from kaji_langgraph.models import BudgetState

    directory = out / case["id"]
    load_keys()
    original = read(Path(case["source_request"]))["request"]["body"]
    result = read(Path(case["source_result"]))["result"]
    trace = result["research_history"][0]
    sources = replay_sources(result, trace)
    old, new = select(result["claim"], sources)
    expected = deepcopy(original)
    before, rest = expected["messages"][-1]["content"].split("Retrieved records:\n", 1)
    saved, end = json.JSONDecoder().raw_decode(rest)
    assert old == saved
    expected["messages"][-1]["content"] = before + "Retrieved records:\n" + json.dumps(new if case["arm"] == "method" else old, ensure_ascii=False) + rest[end:]
    assert case["request"] == expected
    assert expected["model"] == MODELS[case["model"]]
    assert expected["options"]["num_predict"] == 8192
    ledger = FlashLedger(directory, protocol, MODELS[case["model"]])
    ledger.task = case["id"]
    started = time.monotonic()
    with httpx.Client(transport=transport(httpx, ledger, "ollama"), timeout=90,
                      trust_env=False, follow_redirects=False) as client:
        response = client.post("http://localhost:11434/api/chat", json=expected)
        response.raise_for_status()
    usage = scan(directory, MODELS[case["model"]])
    answer = answer_content(directory / "response-001.body")
    error = None
    parsed = None
    gates = None
    try:
        parsed = parse_assessment_lines(answer, stopped_normally=usage[0].get("done_reason") == "stop",
                                        retain_unresolved_proposal=case["model"] == "glm")
    except ValueError as exc:
        error = str(exc)
    if parsed:
        records = new if case["arm"] == "method" else old
        lookup = {item["id"]: (item["url"], item["passages"]) for item in records}
        parsed = _resolve_passage_ids(parsed, lookup)

        def jev_client(**kwargs):
            return TypeSafeClient(**kwargs, retry=RetryPolicy(max_retries=0),
                                  http_client=httpx2.Client(transport=transport(httpx2, ledger, "jev"),
                                                            timeout=15, follow_redirects=False))

        jev_module.TypeSafeClient = jev_client
        config = protocol["config"]
        policy = effective_policy(config, result["domain"])
        policy["require_independent_provenance_review"] = True
        state = {"claim": result["claim"], "domain": result["domain"],
                 "sources": sources, "assertions": result["assertions"], "policy": policy,
                 "assessment": parsed, "research_round": 1, "research_history": [],
                 "budgets": BudgetState(max_seconds=270, started_at_monotonic=started),
                 "errors": [], "jev_audit": {}, "fatal_error": False}
        nodes = WorkflowNodes(None, None, config, jev_module.JevClient(model="jev-1.13.0"))
        checked = nodes.check_evidence(state)
        gates = {key: checked[key] for key in ("gaps", "errors", "fatal_error", "jev_audit")}
    save(directory / "result.json", {"model": case["model"], "arm": case["arm"],
                                      "parsed": parsed is not None, "parse_error": error,
                                      "assessment": parsed.model_dump(mode="json") if parsed else None,
                                      "gate": gates,
                                      "gate_eligible": bool(parsed and gates and not gates["gaps"] and not gates["fatal_error"]),
                                      "scope": "Fixed saved development packet; no live retrieval or full workflow result."})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--prepare-from", type=Path)
    parser.add_argument("--cell")
    parser.add_argument("--limit", type=int, default=1)
    args = parser.parse_args()
    out = args.directory
    if args.prepare_from:
        prepare(args.prepare_from, out)
        return
    p = read(out / "protocol.json")
    assert p["models"] == MODELS and p["caps"] == {"ollama": 1, "jev": 4}
    assert p["source_sha256"] == code_digest()
    assert p["runner_sha256"] == digest(Path(__file__))
    assert p["selector_sha256"] == digest(Path(__file__).with_name("flash_method_windows.py"))
    assert read(out / "approval.json")["approved_protocol_sha256"] == digest(out / "protocol.json")
    for c in p["cases"]:
        assert digest(Path(c["source_request"])) == c["source_request_sha256"]
        assert digest(Path(c["source_result"])) == c["source_result_sha256"]
    if args.cell:
        c = next(c for c in p["cases"] if c["id"] == args.cell)
        d = out / c["id"]
        assert (d / "attempt.json").exists() and not list(d.glob("request-*.json"))
        execute(out, p, c)
        return
    assert 1 <= args.limit <= 4
    count = 0
    for c in p["cases"]:
        d = out / c["id"]
        if d.exists():
            if not (d / "job.json").is_file() or read(d / "job.json")["hard_stop"]:
                raise SystemExit("Unresolved retained attempt; do not retry")
            continue
        if count >= args.limit:
            break
        d.mkdir()
        save(d / "attempt.json", {"model": c["model"], "arm": c["arm"],
                                  "protocol_sha256": digest(out / "protocol.json"),
                                  "started_at": datetime.now(timezone.utc).isoformat()})
        save(d / "live-state.json", {"counts": {"ollama": 0, "jev": 0}, "deadline": time.time() + 270, "stop": None})
        begin = time.monotonic()
        with (d / "stdout.log").open("wb") as stdout, (d / "stderr.log").open("wb") as stderr:
            try:
                worker = subprocess.run([sys.executable, __file__, str(out), "--cell", c["id"]],
                                        timeout=300, stdout=stdout, stderr=stderr,
                                        env={**os.environ, **THREADS, "PYTHONUTF8": "1"})
                code = worker.returncode
            except subprocess.TimeoutExpired:
                code = None
        usage = scan(d, MODELS[c["model"]])
        save(d / "usage.json", usage)
        state = read(d / "live-state.json")
        bad = any(s.get("status") != 200 or s.get("incomplete") or s.get("accounting_error")
                  or s.get("transport_error") or s.get("model_verified") is False for s in usage)
        from collections import Counter
        counts = Counter(s["service"] for s in usage)
        bad = bad or any(counts[k] != v for k, v in state["counts"].items())
        hard_stop = bool(code != 0 or bad or state["stop"])
        save(d / "job.json", {"exit_code": code, "elapsed_seconds": time.monotonic() - begin,
                               "hard_stop": hard_stop, "accounting_problem": bad})
        print(c["id"], "STOP" if hard_stop else "DONE", flush=True)
        count += 1
        if hard_stop:
            raise SystemExit("Inspect retained diagnostic attempt")


if __name__ == "__main__":
    main()
