# Completed LangGraph computational evaluation

Claims per live condition: 500.

Development-set, contemporary open-web results; local label metrics, not the official AVeriTeC evidence score.

| Condition | Accuracy | Macro F1 | Coverage | Accuracy among covered outputs |
|---|---:|---:|---:|---:|
| full_predictions | 67.4% | 0.500 | 98.4% | 68.5% |
| full_failure_inclusive | 67.4% | 0.500 | 98.4% | 68.5% |
| closed_book_predictions | 53.8% | 0.417 | 99.0% | 54.3% |
| structural_only | 9.0% | 0.086 | 10.0% | 90.0% |
| full_policy | 8.4% | 0.083 | 8.8% | 95.5% |
| first_round_prediction | 68.8% | 0.530 | 99.2% | 69.4% |
| first_round_verified | 2.8% | 0.029 | 2.8% | 100.0% |
| semantic_threshold_0.50 | 8.6% | 0.084 | 9.2% | 93.5% |
| semantic_threshold_0.60 | 8.6% | 0.084 | 9.0% | 95.6% |
| semantic_threshold_0.70 | 8.4% | 0.083 | 8.8% | 95.5% |
| semantic_threshold_0.80 | 8.4% | 0.083 | 8.8% | 95.5% |
| semantic_threshold_0.90 | 5.6% | 0.057 | 6.0% | 93.3% |
| semantic_threshold_0.95 | 4.4% | 0.046 | 4.8% | 91.7% |
| without_high_confidence | 8.4% | 0.083 | 8.8% | 95.5% |
| without_exact_quotes | 15.6% | 0.158 | 17.2% | 90.7% |
| without_host_diversity | 8.4% | 0.083 | 8.8% | 95.5% |
| without_duplicate_check | 8.4% | 0.083 | 9.0% | 93.3% |
| without_independence_flag | 12.8% | 0.129 | 13.4% | 95.5% |
| without_assertion_coverage | 8.4% | 0.083 | 8.8% | 95.5% |
| without_counterevidence_flag | 8.4% | 0.083 | 8.8% | 95.5% |
| without_peer_review_flag | 8.4% | 0.083 | 8.8% | 95.5% |
| majority_baseline | 61.0% | 0.189 | 100.0% | 61.0% |

## Interpretation boundaries

- Model-only control has no verification gate; use its prediction metrics.
- Structural-only, rule-removal and threshold results replay the SAME final assessments and evidence. They measure acceptance policy, not complete alternative workflows.
- First-round results truncate the same saved live trace. They isolate additional research on that trace rather than rerunning changing web searches.
- NEI remains a factual prediction but is outside decisive acceptance; accepted NEI recall is zero by design.
- Full predictions preserve model assessments even if a later service fails. Failure-inclusive metrics count those operational failures as abstentions.
- Threshold curves are descriptive development analyses, not independently validated optimal thresholds.
- Confidence intervals and paired accuracy bootstrap use claims as units. API/model/search drift is not captured by these intervals.
- Jev citation judgments are automated measurements, not human ground truth. Human audit fields remain blank.
- Published fact checks and later documents can be retrieved; no historical cutoff was enforced.

## Citation checks

Final-assessment citations: 2611; exact quotations: 1914; Jev-reviewed: 1914.
Exact quotations whose Jev review did not support the finding: 34; uncertain support: 158.
Claims citing the same host as their dataset fact-check article: 0/500 (proxy only).

## Paired accuracy differences

```json
{
  "full_minus_closed_book": {
    "n": 500,
    "delta_b_minus_a": 0.136,
    "ci95": [
      0.086,
      0.186
    ]
  },
  "full_minus_first_round": {
    "n": 500,
    "delta_b_minus_a": -0.014,
    "ci95": [
      -0.04,
      0.012
    ]
  }
}
```

## Artifacts

- study-metrics.json: metrics, Wilson intervals, paired bootstrap, execution and citation diagnostics.
- policy-replay.csv: per-claim policy decisions.
- human-citation-audit.csv: blinded worksheet, with unfilled human judgments.
- human-audit-key.json: keep separate from human reviewers.
- source-snapshot.zip and manifest.json: frozen source and run settings.
