# KajiAI AVeriTeC evaluation

Completed 500 of 500 selected claims.

Local label-only metrics, NOT the official AVeriTeC evidence score.

| Output | Accuracy | Macro F1 (4 classes) | Coverage | Accuracy on covered claims |
|---|---:|---:|---:|---:|
| predictions | 0.674 | 0.500 | 0.984 | 0.685 |
| failure_inclusive_predictions | 0.674 | 0.500 | 0.984 | 0.685 |
| verified | 0.084 | 0.083 | 0.088 | 0.955 |

Abstentions count as incorrect in overall accuracy. Raw predictions preserve an available model assessment even if a later service fails; failure-inclusive predictions count execution failures as abstentions. Selective accuracy excludes abstentions and must be reported alongside coverage. Missing selected claims are not yet scored; partial runs are not full benchmark results.

## Prediction performance by class

| Class | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| Supported | 0.792 | 0.656 | 0.717 | 122 |
| Refuted | 0.879 | 0.761 | 0.815 | 305 |
| Not Enough Evidence | 0.207 | 0.171 | 0.188 | 35 |
| Conflicting Evidence/Cherrypicking | 0.194 | 0.500 | 0.279 | 38 |

## Execution

- Error rate: 0.016
- Mean elapsed seconds: 79.2
- Searches / page fetches: 2049 / 3953
- Observed tokens: 34452832
- Complete token accounting: False

## Stop reasons

- max_rounds: 443
- evidence_sufficient: 44
- stagnant_research: 5
- execution_error: 8

## Most frequent verification gaps

- Establish source independence; copied reporting is not corroboration.: 357
- Each citation needs an exact quote from its retrieved text.: 353
- Evidence confidence remains below High.: 71
- No supported verdict yet.: 37
- Find relevant evidence from at least two source hosts.: 35
- This domain requires peer-reviewed evidence.: 27
- Some cited hosts repeat substantially similar text; verify original-source lineage.: 9
- A conflicting verdict requires cited evidence on both sides.: 8
- The model did not return a valid evidence assessment.: 8
- Search for evidence against the proposed conclusion.: 8
- Every finding needs retrieved citations.: 8
- Some citations were not retrieved.: 7
- Citation support is uncertain for https://www.usatoday.com/story/news/factcheck/2020/10/03/fact-check-false-claim-trumps-covid-19-test-result-con/5894945002/.: 2
- Citation support is uncertain for https://en.wikipedia.org/wiki/List_of_federal_judges_appointed_by_Donald_Trump.: 2
- Citation support is uncertain for https://africacheck.org/fact-checks/reports/nigerias-population-economy-and-history-fact-checking-buharis-independence-day.: 2
