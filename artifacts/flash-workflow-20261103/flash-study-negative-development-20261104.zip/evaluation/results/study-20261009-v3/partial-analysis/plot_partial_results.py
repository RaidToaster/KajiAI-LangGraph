"""Generate descriptive study figures from the quota-interrupted saved metrics.

Run with Python + matplotlib: python plot_results.py
No service calls and no changes to evaluated source code.
"""
from pathlib import Path
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
data = json.loads((ROOT / "partial-study-metrics.json").read_text(encoding="utf-8"))
assert not data["complete"], "These figures describe a partial study"
metrics = data["matched_metrics"]
plt.rcParams.update({"font.size": 10, "axes.spines.top": False,
                     "axes.spines.right": False, "svg.fonttype": "none"})
FIGURES = ROOT / "figures"
FIGURES.mkdir(exist_ok=True)


def save(fig, name):
    for suffix in ["png", "pdf", "svg"]:
        fig.savefig(FIGURES / f"{name}.{suffix}", dpi=180, bbox_inches="tight")
    plt.close(fig)


fig, axes = plt.subplots(1, 2, figsize=(10, 4.5), layout="constrained")
conditions = ["majority_baseline", "closed_book_predictions", "first_round_prediction", "full_predictions"]
labels = ["Majority label", "Model only", "First round", "Full workflow"]
x = np.arange(len(conditions))
accuracy = np.array([metrics[c]["accuracy"] for c in conditions])
ci = np.array([metrics[c]["accuracy_ci95"] for c in conditions])
axes[0].bar(x, accuracy, color="#386cb0", width=0.55)
axes[0].errorbar(x, accuracy, yerr=[accuracy-ci[:, 0], ci[:, 1]-accuracy],
                 color="black", capsize=4, linestyle="none")
axes[0].set(xticks=x, xticklabels=labels, ylim=(0, 1), ylabel="Label accuracy",
            title="A. Prediction accuracy (95% Wilson intervals)")
axes[0].tick_params(axis="x", labelrotation=25)
axes[1].bar(x, [metrics[c]["macro_f1"] for c in conditions], color="#7b3294", width=0.55)
axes[1].set(xticks=x, xticklabels=labels, ylim=(0, 1), ylabel="Four-class macro F1",
            title="B. Class-balanced prediction performance")
axes[1].tick_params(axis="x", labelrotation=25)
fig.suptitle(f"PARTIAL study; matched n={data['matched_n']}; contemporary web; label-only scoring", fontsize=11)
save(fig, "prediction-performance")

metrics = data["all_full_metrics"]
fig, axes = plt.subplots(1, 2, figsize=(9, 4.5), layout="constrained")
conditions = ["structural_only", "full_policy"]
labels = ["Structural rules only", "Structural + semantic review"]
for ax, field, interval, title in zip(axes,
                                     ["coverage", "selective_accuracy"],
                                     ["coverage_ci95", "selective_accuracy_ci95"],
                                     ["A. Fraction accepted", "B. Label accuracy among accepted"]):
    values = [metrics[c][field] for c in conditions]
    for i, (c, value) in enumerate(zip(conditions, values)):
        if value is None:
            ax.text(i, 0.05, "Undefined", ha="center")
        else:
            bounds = metrics[c][interval]
            ax.bar(i, value, color=["#777777", "#1b7837"][i], width=0.5)
            ax.errorbar(i, value, yerr=[[value-bounds[0]], [bounds[1]-value]],
                        color="black", capsize=4, linestyle="none")
    ax.set(xticks=range(2), xticklabels=labels, ylim=(0, 1), title=title)
    ax.tick_params(axis="x", labelrotation=15)
fig.suptitle("PARTIAL study; all 302 attempts; acceptance-policy replay (95% Wilson intervals)", fontsize=11)
save(fig, "verification-coverage-and-accuracy")

metrics = data["matched_metrics"]
names = ["Supported", "Refuted", "Not Enough Evidence", "Conflicting Evidence/Cherrypicking"]
short = ["Supported", "Refuted", "NEI", "Conflicting"]
fig, axes = plt.subplots(1, 3, figsize=(13, 4.5), layout="constrained")
for ax, condition, title in zip(axes,
                               ["closed_book_predictions", "full_predictions", "full_policy"],
                               ["Model only", "Full prediction", "Accepted verdict"]):
    matrix = metrics[condition]["confusion_matrix"]
    counts = np.array([[matrix[g][p] for p in [*names, "ABSTAIN"]] for g in names])
    proportions = np.divide(counts, counts.sum(axis=1, keepdims=True),
                            out=np.zeros_like(counts, dtype=float), where=counts.sum(axis=1, keepdims=True)>0)
    ax.imshow(proportions, vmin=0, vmax=1, cmap="Blues")
    for (i, j), count in np.ndenumerate(counts):
        ax.text(j, i, str(count), ha="center", va="center", color="white" if proportions[i,j]>0.6 else "black")
    ax.set(xticks=range(5), xticklabels=[*short, "Abstain"], yticks=range(4), yticklabels=short,
           title=title, xlabel="Prediction", ylabel="Gold label")
    ax.tick_params(axis="x", labelrotation=45)
fig.suptitle("PARTIAL study; matched n=177; counts annotated; shading normalized within gold-label rows", fontsize=11)
save(fig, "confusion-matrices")

metrics = data["all_full_metrics"]
fig, ax = plt.subplots(figsize=(6, 4), layout="constrained")
thresholds = [0.5, 0.6, 0.7, 0.8, 0.9, 0.95]
ax.plot(thresholds, [metrics[f"semantic_threshold_{t:.2f}"]["coverage"] for t in thresholds],
         "o-", color="#1b7837", label="Coverage")
ax.plot(thresholds, [metrics[f"semantic_threshold_{t:.2f}"]["selective_accuracy"] for t in thresholds],
         "s--", color="#386cb0", label="Accuracy among accepted")
ax.set(xlabel="Jev citation confidence threshold", ylabel="Fraction", ylim=(0, 1.05),
       title="PARTIAL study; n=302; descriptive threshold replay")
ax.legend(loc="best")
save(fig, "semantic-threshold-replay")
print(FIGURES)
