# Partial LangGraph evaluation — interrupted by external quota

Status: **incomplete**. Ollama returned HTTP 429 after reaching the account's monthly usage limit. Recorded at 2026-10-09T19:09:31.973124+00:00.

Planned: 500 unique AVeriTeC development claims, each assessed by the full workflow and model-only control (1,000 assessments). Stored: 302 full-workflow attempts and 283 model-only attempts, including five and two execution failures respectively. Remaining: 198 full and 217 model-only assessments. There are 177 matching claims in both conditions.

This report is an evaluation artifact, not a paper draft. Raw outputs and failed attempts are preserved; the study can resume with its frozen configuration. Earlier exploratory runs were excluded because their source versions differ.

## Same-claim comparison

Use this matched subset for the primary comparison. The 302-claim and 283-claim aggregate accuracies use different claim sets and must not be compared as a paired experiment. The quota interruption can bias the observed subset; statistical intervals do not correct that missingness.

| Condition | Accuracy (95% Wilson CI) | Macro F1 | Coverage | Accuracy among accepted/non-abstaining |
|---|---:|---:|---:|---:|
| majority_baseline | 56.5% (49.1%–63.6%) | 0.181 | 100.0% | 56.5% |
| closed_book_predictions | 49.2% (41.9%–56.5%) | 0.413 | 99.4% | 49.4% |
| first_round_prediction | 65.5% (58.3%–72.1%) | 0.534 | 98.9% | 66.3% |
| full_predictions | 63.3% (56.0%–70.0%) | 0.502 | 97.2% | 65.1% |
| full_policy | 7.3% (4.3%–12.2%) | 0.077 | 7.3% | 100.0% |

Full minus model-only accuracy: 14.12 percentage points; claim-level bootstrap 95% interval 6.21 to 22.60 points (2,000 resamples). Exact two-sided McNemar p=0.001547. Full-only correct: 42; model-only correct: 17; both correct: 70; neither correct: 48. This is a provisional development-set result, not a held-out generalization claim.

## All full-workflow attempts: acceptance and iteration

| Condition | Accuracy (95% Wilson CI) | Macro F1 | Coverage | Accuracy among accepted/non-abstaining |
|---|---:|---:|---:|---:|
| majority_baseline | 57.6% (52.0%–63.1%) | 0.183 | 100.0% | 57.6% |
| first_round_prediction | 69.5% (64.1%–74.5%) | 0.563 | 99.3% | 70.0% |
| full_predictions | 65.6% (60.0%–70.7%) | 0.505 | 98.3% | 66.7% |
| full_failure_inclusive | 65.6% (60.0%–70.7%) | 0.505 | 98.3% | 66.7% |
| structural_only | 7.0% (4.6%–10.4%) | 0.072 | 7.9% | 87.5% |
| full_policy | 6.3% (4.1%–9.6%) | 0.067 | 6.3% | 100.0% |

The full gate accepted 19 of 302 attempts (five Supported, fourteen Refuted). All 19 labels matched the dataset. Accepted-label accuracy has a 95% Wilson interval of 83.2%–100.0%; coverage interval 4.1%–9.6%. This small selected set does not demonstrate perfect reliability. The gate rejected 179 correct raw predictions and 104 wrong raw predictions, so it sacrifices substantial coverage.

Additional rounds changed 40 final predictions: eight wrong-to-correct, twenty correct-to-wrong, and twelve changes between wrong labels. The final-minus-first accuracy difference was -3.97 percentage points on these saved trajectories (bootstrap interval -7.28 to -0.66 points). This is trace truncation, not a separately rerun one-round experiment. Excluding the five fatal quota attempts, the difference on 297 nonfatal attempts was -3.03 points (interval -6.40 to 0.00), so operational quota failures alone do not explain the deterioration.

There were 573 rounds after the first, including 153 with no new ledger records. These rounds consumed 655 searches, 1,266 fetch attempts and 14,822,163 observed model tokens. A new ledger record need not be newly usable independent evidence. More research did not improve label accuracy in this partial run.

## Citation checks and rejection causes

Final-assessment citation occurrences: 1626; literal quotes in canonical retrieved text: 1190; Jev-reviewed quote occurrences: 1190. Of those reviewed exact quotes, 15 did not support their attached finding and 107 had supporting confidence below 0.8. Repeated citations across findings are counted separately. These are automated checks, not human judgments.

The final structural gate reported insufficient source-independence flags for 224 claims and missing exact quotes for 218. These causes overlap. A missing literal quote can reflect citation/provenance mismatch and must not automatically be counted as a hallucination. Source independence is partly model-assessed; distinct hosts alone do not establish independent corroboration.

134/302 final assessments cited a host matching the dataset's fact-check article, after unwrapping Wayback Machine URLs to their original host. Host equality is only an exposure proxy: it does not prove exact article exposure, and lack of a match does not establish no leakage. Published fact checks and newer documents were available during contemporary web retrieval. The complete-study analysis helper currently compares archive wrapper hosts; this partial postprocessor corrects that proxy without changing the frozen inference code.

## Operational costs

Full workflow: 1,259 searches; 2,460 fetch attempts; 21,606,324 observed tokens; mean 81.2 seconds per attempted claim (median 78.4, p90 123.7). Model-only mean 5.6 seconds. Concurrent per-claim durations are not study wall-clock time.

Model-only observed tokens: 103,773. Token accounting is incomplete, so these counts are lower-bound observations and cannot support an exact monetary cost estimate. Full execution error rate 1.7%; model-only 0.7%. There were 354 recorded fetch failures and two Jev ranking failures; these recoverable errors are distinct from the seven fatal quota failures.

## Evaluated configuration and reproducibility

Full workflow: validate, classify domain, decompose claim, retrieve, assess evidence, apply structural and Jev citation checks, route another research round, finalize. Control: same Ollama model and claim/date inputs, one structured label response, no search or verification gate. The model-only control isolates the combined workflow's contribution; it does not isolate LangGraph as a framework or Jev by itself.

Model: gemma4:31b-cloud via Ollama, temperature 0. Jev: jev-1.13.0, citation confidence threshold 0.8. TinyFish supplies search and fetching. Seed 20261009; three workers; maximum three research rounds and 300-second soft scheduling budget per full claim. In-flight calls can finish after the soft budget. Current configuration, full claim ordering, package versions, source hash and dataset hash are archived in manifest.json and source-snapshot.zip.

Frozen inference source SHA-256: `624a8d2fa125aa3c82b5d4a8fc5f19da9c9a4e32040ee715e6245753459ac973`. Dataset SHA-256: `499793726b4a5406780928a3d9dedc48d6dd53de778f22437d129cacdb08e300`. No evaluation source changes were made during this frozen v3 run. Analysis code is stored separately and hashed in partial-study-metrics.json.

Policy replays change acceptance decisions using the same final evidence/assessment, not the research process. Threshold curves are descriptive and cannot establish optimal thresholds. Removing the exact-quote requirement also affects eligibility for semantic review, so it is not an isolated semantic ablation. NEI is a factual label, but decisive acceptance excludes it by design, making accepted NEI recall zero.

## Code fixes completed before the frozen run

1. Fixed inconsistent whitespace handling: the structural gate had trimmed citation quotes while semantic review and retention matched the literal string. A padded non-matching quote could therefore pass the structural check, skip semantic review and disappear from retained evidence. Structural checks now match literal quotes consistently. Regression tests cover both Jev-enabled and disabled paths.
2. Fixed JSONL reading: Unicode paragraph/line separator characters inside valid JSON strings were incorrectly treated as record boundaries by splitlines(). Readers now iterate actual file lines. Regression coverage includes U+2028, U+2029 and U+0085.
3. Added exact source-version and assessment traces, resumable matched controls, source/configuration freezing, failure-inclusive scoring, confidence intervals and reproducible offline policy replay. Final verification: 60 tests passed. The bug fixes improve correctness; no separate measured gain is attributed to those fixes.

## What remains before using this as final paper evidence

- Restore Ollama capacity and finish the frozen 500-by-two run. Do not merge a different model/configuration into this condition. Existing fatal attempts remain in the denominator.
- Perform an independent human citation audit. The blinded CSV is prepared with blank human fields and a separate key; no human audit has been performed. An LLM reviewing its own experiment is not independent human validation.
- Treat these as local four-class label metrics, not official AVeriTeC evidence/QA scores. No claim is made about benchmark leadership, verified hallucination reduction, clinical safety or historical fact-check reconstruction.
- This is a repeatedly used development split with current-web access; it is not a pristine held-out test. Accuracy can be helped by published verdicts and changed by temporal drift.
- Review iteration harm and the low acceptance coverage before making deployment claims. Changing the policy after inspecting these outcomes requires a separately versioned evaluation rather than silently tuning this run.

## Saved artifacts

- partial-study-metrics.json: matched metrics, all-attempt metrics, confidence intervals, costs, citation and failure diagnostics.
- per-claim-results.csv: all full claims with available matched control labels and offline policy decisions.
- human-citation-audit.csv: blinded evidence worksheet with blank human annotations. Keep human-audit-key.json separate from reviewers.
- figures/: PNG, PDF and SVG descriptive figures, all explicitly marked partial.
- Parent directory full/results.jsonl and closed_book/results.jsonl: original raw assessments, sources, budgets and errors.

Resume from the repository root once the same model has capacity:

```powershell
uv run --offline --env-file .env python -m kaji_langgraph.study --limit 500 --workers 3 --seed 20261009 --max-rounds 3 --max-seconds 300 --output evaluation/results/study-20261009-v3 --resume
```
