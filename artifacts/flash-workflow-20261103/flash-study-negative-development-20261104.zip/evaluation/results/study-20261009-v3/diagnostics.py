"""Additional offline diagnostics; includes errors, partial-run flags, and paired claims."""
from collections import Counter, defaultdict
from pathlib import Path
import json
import math
import statistics

ROOT = Path(__file__).resolve().parent
ABSTAIN = "ABSTAIN"
LABEL_MAP = {"TRUE": "Supported", "FALSE": "Refuted", "CONFLICTING": "Conflicting Evidence/Cherrypicking",
             "NOT_ENOUGH_EVIDENCE": "Not Enough Evidence"}


def read(condition):
    path = ROOT / condition / "results.jsonl"
    if not path.exists():
        return []
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def latency(rows):
    times = sorted(r["result"]["elapsed_seconds"] for r in rows)
    return {"n": len(rows), "mean_seconds": statistics.mean(times) if times else None,
            "median_seconds": statistics.median(times) if times else None,
            "p90_seconds": times[min(len(times)-1, math.ceil(0.9*len(times))-1)] if times else None}


full, closed = read("full"), read("closed_book")
full_by_id = {r["claim_id"]: r for r in full}
closed_by_id = {r["claim_id"]: r for r in closed}
manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
complete = len(full_by_id) == len(closed_by_id) == len(manifest["claim_ids"])
paired = sorted(full_by_id.keys() & closed_by_id.keys())
pair_counts = Counter()
changes = Counter()
confidence = defaultdict(Counter)
domains = defaultdict(list)
errors = Counter()
structural = Counter()
semantic = Counter()
rejections = Counter()
rounds = Counter()
quote_only_issues = []
wrong_accepted = []
trace_less = []
for index in paired:
    f, c = full_by_id[index], closed_by_id[index]
    fc, cc = f["predicted_label"] == f["gold_label"], c["predicted_label"] == c["gold_label"]
    pair_counts[f"full_{'correct' if fc else 'wrong'}__control_{'correct' if cc else 'wrong'}"] += 1
for row in full:
    result = row["result"]
    domains[result["domain"]].append(row)
    correct = row["predicted_label"] == row["gold_label"]
    confidence[result["prediction_confidence"]]["total"] += 1
    confidence[result["prediction_confidence"]]["correct"] += int(correct)
    for message in set(result["errors"]):
        errors[message.split(":", 1)[0]] += 1
    history = result["research_history"]
    rounds[str(len(history))] += 1
    if not history:
        trace_less.append(row["claim_id"])
        continue
    first = LABEL_MAP.get(history[0]["assessment"]["proposed_verdict"], ABSTAIN)
    changes["predictions_changed"] += int(first != row["predicted_label"])
    changes["wrong_to_correct"] += int(first != row["gold_label"] and correct)
    changes["correct_to_wrong"] += int(first == row["gold_label"] and not correct)
    changes["extra_rounds"] += len(history)-1
    changes["extra_rounds_without_new_sources"] += sum(t["new_sources"] == 0 for t in history[1:])
    budget = result["budget"]
    initial_budget = history[0].get("budget") or {}
    changes["searches_after_first_round"] += budget["search_calls"]-initial_budget.get("search_calls", 0)
    changes["fetches_after_first_round"] += budget["scrapes"]-initial_budget.get("scrapes", 0)
    changes["observed_tokens_after_first_round"] += budget["tokens_used"]-initial_budget.get("tokens_used", 0)
    trace = history[-1]
    structural.update(set(trace["structural_gaps"]))
    semantic.update(set(trace["semantic_gaps"]))
    if row["accepted_label"] == ABSTAIN:
        rejections[f"raw_{'correct' if correct else 'wrong'}"] += 1
        rejections["structural_and_semantic"] += int(bool(trace["structural_gaps"]) and bool(trace["semantic_gaps"]))
        rejections["structural_only"] += int(bool(trace["structural_gaps"]) and not trace["semantic_gaps"])
        rejections["semantic_only"] += int(not trace["structural_gaps"] and bool(trace["semantic_gaps"]))
        quote_gap = "Each citation needs an exact quote from its retrieved text."
        if trace["structural_gaps"] == [quote_gap] and not trace["semantic_gaps"]:
            quote_only_issues.append(row["claim_id"])
    elif row["accepted_label"] != row["gold_label"]:
        wrong_accepted.append({"claim_id": row["claim_id"], "claim": result["claim"],
                               "gold_label": row["gold_label"], "accepted_label": row["accepted_label"],
                               "summary": result["prediction_summary"]})
wins = pair_counts["full_correct__control_wrong"]
losses = pair_counts["full_wrong__control_correct"]
discordant = wins+losses
p = min(1, 2*sum(math.comb(discordant, k) for k in range(min(wins, losses)+1))/2**discordant) if discordant else 1.0
payload = {"complete": complete, "full_completed": len(full), "control_completed": len(closed),
           "paired_n": len(paired), "paired_correctness": dict(pair_counts),
           "accuracy_mcnemar_exact_two_sided_p": p, "extra_research": dict(changes),
           "raw_self_reported_confidence": {k: dict(v) for k,v in confidence.items()},
           "domain_latency": {k: latency(v) for k,v in domains.items()},
           "full_latency": latency(full), "control_latency": latency(closed),
           "round_count_distribution": dict(rounds), "recorded_error_categories": dict(errors),
           "structural_gap_claim_counts": dict(structural), "semantic_gap_claim_counts": dict(semantic),
           "rejected_predictions": dict(rejections), "wrong_accepted_claims": wrong_accepted,
           "claims_without_research_trace": trace_less,
           "only_missing_quote_rejection_claims": quote_only_issues,
           "caveat": "Labels measure dataset agreement, not citation truth. Extra research is trajectory truncation, not a separate live run. Removing the exact-quote rule can also bypass semantic review for unmatched quotes because that review requires quote provenance."}
(ROOT / "diagnostics.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
print(json.dumps({k: payload[k] for k in ["complete", "full_completed", "control_completed", "paired_n",
                                         "paired_correctness", "extra_research", "recorded_error_categories"]}, indent=2))
