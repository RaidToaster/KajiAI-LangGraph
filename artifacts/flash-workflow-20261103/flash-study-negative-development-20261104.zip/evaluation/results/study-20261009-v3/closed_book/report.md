# KajiAI AVeriTeC evaluation

Completed 500 of 500 selected claims.

Local label-only metrics, NOT the official AVeriTeC evidence score.

| Output | Accuracy | Macro F1 (4 classes) | Coverage | Accuracy on covered claims |
|---|---:|---:|---:|---:|
| predictions | 0.538 | 0.417 | 0.990 | 0.543 |
| failure_inclusive_predictions | 0.538 | 0.417 | 0.990 | 0.543 |
| verified | 0.000 | 0.000 | 0.000 | N/A |

Abstentions count as incorrect in overall accuracy. Raw predictions preserve an available model assessment even if a later service fails; failure-inclusive predictions count execution failures as abstentions. Selective accuracy excludes abstentions and must be reported alongside coverage. Missing selected claims are not yet scored; partial runs are not full benchmark results.

## Prediction performance by class

| Class | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| Supported | 0.561 | 0.607 | 0.583 | 122 |
| Refuted | 0.804 | 0.564 | 0.663 | 305 |
| Not Enough Evidence | 0.131 | 0.400 | 0.197 | 35 |
| Conflicting Evidence/Cherrypicking | 0.214 | 0.237 | 0.225 | 38 |

## Execution

- Error rate: 0.010
- Mean elapsed seconds: 7.7
- Searches / page fetches: 0 / 0
- Observed tokens: 183416
- Complete token accounting: False

## Stop reasons

- model_only_control: 495
- execution_error: 5

## Most frequent verification gaps

