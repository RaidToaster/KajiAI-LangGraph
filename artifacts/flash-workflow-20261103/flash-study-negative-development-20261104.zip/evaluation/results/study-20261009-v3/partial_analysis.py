"""Offline analysis of the quota-interrupted study; never labels it complete."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import urlsplit

from kaji_langgraph.evaluation import ABSTAIN, load_dataset, summarize
from kaji_langgraph.graph import _citation_key
from kaji_langgraph.study_analysis import (
    human_audit, paired_accuracy, percent, read_rows, replay_labels,
    replay_sources, scored,
)

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "partial-analysis"
OUT.mkdir(exist_ok=True)
manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
status = json.loads((ROOT / "status.json").read_text(encoding="utf-8"))
assert not status["complete"], "Use the complete-study analysis after resuming"
full = sorted(read_rows(ROOT / "full/results.jsonl"), key=lambda r: r["claim_id"])
control = sorted(read_rows(ROOT / "closed_book/results.jsonl"), key=lambda r: r["claim_id"])
expected = set(manifest["claim_ids"])
for rows in [full, control]:
    ids = [r["claim_id"] for r in rows]
    assert len(set(ids)) == len(ids) and set(ids) <= expected
control_by_id = {r["claim_id"]: r for r in control}
matched = [r for r in full if r["claim_id"] in control_by_id]
assert all(r["gold_label"] == control_by_id[r["claim_id"]]["gold_label"] for r in matched)
policies = {r["claim_id"]: replay_labels(r, manifest["config"]) for r in full}


def metrics_for(rows, with_control=False):
    gold = [r["gold_label"] for r in rows]
    raw = [r["predicted_label"] for r in rows]
    output = {
        "full_predictions": scored(gold, raw),
        "full_failure_inclusive": scored(gold, [ABSTAIN if r["result"]["verification_status"] == "execution_error" else r["predicted_label"] for r in rows]),
        "majority_baseline": scored(gold, ["Refuted"] * len(gold)),
    }
    for name in next(iter(policies.values())):
        output[name] = scored(gold, [policies[r["claim_id"]][name] for r in rows])
    if with_control:
        output["closed_book_predictions"] = scored(gold, [control_by_id[r["claim_id"]]["predicted_label"] for r in rows])
    return output


matched_metrics = metrics_for(matched, True)
all_full_metrics = metrics_for(full)
matched_gold = [r["gold_label"] for r in matched]
comparisons = {
    "matched_full_minus_model_only": paired_accuracy(matched_gold, [control_by_id[r["claim_id"]]["predicted_label"] for r in matched], [r["predicted_label"] for r in matched]),
    "all_full_minus_first_round": paired_accuracy([r["gold_label"] for r in full], [policies[r["claim_id"]]["first_round_prediction"] for r in full], [r["predicted_label"] for r in full]),
}
nonfatal = [r for r in full if r["result"]["verification_status"] != "execution_error"]
comparisons["nonfatal_full_minus_first_round"] = paired_accuracy([r["gold_label"] for r in nonfatal], [policies[r["claim_id"]]["first_round_prediction"] for r in nonfatal], [r["predicted_label"] for r in nonfatal])
diagnostics = json.loads((ROOT / "diagnostics.json").read_text(encoding="utf-8"))
assert len(matched) == diagnostics["paired_n"]
citations = Counter()
relations = Counter()
dataset_path = ROOT / "dataset-snapshot.json"
assert hashlib.sha256(dataset_path.read_bytes()).hexdigest() == manifest["dataset_sha256"]
dataset = load_dataset(dataset_path)
same_host = 0
def host(url):
    parsed = urlsplit(url)
    if parsed.hostname == "web.archive.org":
        archived = re.match(r"/web/[^/]+/(https?://.+)", parsed.path)
        if archived:
            parsed = urlsplit(archived.group(1))
    return (parsed.hostname or "").removeprefix("www.")

assert host("https://web.archive.org/web/20201130144023/https://www.example.com/a") == "example.com"
assert host("https://www.example.com/a") == "example.com"
for row in full:
    result = row["result"]
    trace = result["research_history"][-1]
    sources = {s.url: s for s in replay_sources(result, trace)}
    reviews = {r["key"]: r for r in result["jev_audit"].get("citations", []) if r["round"] == trace["round_number"]}
    gold_host = host(dataset[row["claim_id"]].get("fact_checking_article", ""))
    urls = {url for item in trace["assessment"]["evidence"] for url in item["source_urls"]}
    same_host += bool(gold_host and any(host(url) == gold_host for url in urls))
    for item in trace["assessment"]["evidence"]:
        for url in item["source_urls"]:
            citations["total"] += 1
            source = sources.get(url)
            quote = item["quotes"].get(url, "")
            if source and quote and quote in source.retrieved_text:
                citations["exact_quote"] += 1
                review = reviews.get(_citation_key(item["finding"], url, quote, source.content_hash))
                if review:
                    citations["reviewed"] += 1
                    relations[review["relation"]] += 1
                    if review["relation"] != "supports":
                        citations["jev_does_not_support"] += 1
                    elif review["confidence"] < manifest["config"]["jev"]["citation_min_confidence"]:
                        citations["jev_uncertain_support"] += 1

payload = {
    "complete": False, "halt_reason": "Ollama monthly usage limit (HTTP 429)",
    "planned_per_condition": len(expected), "full_attempted": len(full), "model_only_attempted": len(control),
    "remaining_full": len(expected)-len(full), "remaining_model_only": len(expected)-len(control),
    "matched_n": len(matched), "matched_claim_ids": [r["claim_id"] for r in matched],
    "matched_gold_distribution": dict(Counter(matched_gold)),
    "matched_metrics": matched_metrics, "all_full_metrics": all_full_metrics,
    "all_model_only_metrics": scored([r["gold_label"] for r in control], [r["predicted_label"] for r in control]),
    "paired_accuracy_comparisons": comparisons, "diagnostics": diagnostics,
    "full_execution": summarize(full), "model_only_execution": summarize(control),
    "citations": dict(citations), "jev_relations": dict(relations),
    "same_host_as_gold_fact_check_cited": same_host,
    "human_audit_performed": False,
    "analysis_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "frozen_inference_source_sha256": manifest["code_sha256"],
    "status_updated_at": status["updated_at"],
}
(OUT / "partial-study-metrics.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
human_audit(full, OUT)
with (OUT / "per-claim-results.csv").open("w", newline="", encoding="utf-8-sig") as handle:
    fields = ["claim_id", "claim", "gold", "model_only", "raw_prediction", "accepted_label", "verification_status", "rounds", "searches", "fetches", "observed_tokens", "elapsed_seconds", *next(iter(policies.values()))]
    writer = csv.DictWriter(handle, fieldnames=fields)
    writer.writeheader()
    for row in full:
        result = row["result"]
        writer.writerow(dict(claim_id=row["claim_id"], claim=result["claim"], gold=row["gold_label"], model_only=control_by_id.get(row["claim_id"], {}).get("predicted_label", "NOT_RUN"), raw_prediction=row["predicted_label"], accepted_label=row["accepted_label"], verification_status=result["verification_status"], rounds=len(result["research_history"]), searches=result["budget"]["search_calls"], fetches=result["budget"]["scrapes"], observed_tokens=result["budget"]["tokens_used"], elapsed_seconds=result["elapsed_seconds"], **policies[row["claim_id"]]))


def ci(bounds):
    return "undefined" if bounds is None else f"{percent(bounds[0])}–{percent(bounds[1])}"


def metric_table(metrics, names):
    lines = ["| Condition | Accuracy (95% Wilson CI) | Macro F1 | Coverage | Accuracy among accepted/non-abstaining |", "|---|---:|---:|---:|---:|"]
    for name in names:
        m = metrics[name]
        lines.append(f"| {name} | {percent(m['accuracy'])} ({ci(m['accuracy_ci95'])}) | {m['macro_f1']:.3f} | {percent(m['coverage'])} | {percent(m['selective_accuracy'])} |")
    return lines


full_exec = payload["full_execution"]
control_exec = payload["model_only_execution"]
accepted = all_full_metrics["full_policy"]
diff = comparisons["matched_full_minus_model_only"]
extra = comparisons["all_full_minus_first_round"]
nonfatal_extra = comparisons["nonfatal_full_minus_first_round"]
lines = [
    "# Partial LangGraph evaluation — interrupted by external quota", "",
    f"Status: **incomplete**. Ollama returned HTTP 429 after reaching the account's monthly usage limit. Recorded at {status['updated_at']}.", "",
    f"Planned: 500 unique AVeriTeC development claims, each assessed by the full workflow and model-only control (1,000 assessments). Stored: {len(full)} full-workflow attempts and {len(control)} model-only attempts, including five and two execution failures respectively. Remaining: {500-len(full)} full and {500-len(control)} model-only assessments. There are {len(matched)} matching claims in both conditions.", "",
    "This report is an evaluation artifact, not a paper draft. Raw outputs and failed attempts are preserved; the study can resume with its frozen configuration. Earlier exploratory runs were excluded because their source versions differ.", "",
    "## Same-claim comparison", "",
    "Use this matched subset for the primary comparison. The 302-claim and 283-claim aggregate accuracies use different claim sets and must not be compared as a paired experiment. The quota interruption can bias the observed subset; statistical intervals do not correct that missingness.", "",
    *metric_table(matched_metrics, ["majority_baseline", "closed_book_predictions", "first_round_prediction", "full_predictions", "full_policy"]), "",
    f"Full minus model-only accuracy: {100*diff['delta_b_minus_a']:.2f} percentage points; claim-level bootstrap 95% interval {100*diff['ci95'][0]:.2f} to {100*diff['ci95'][1]:.2f} points (2,000 resamples). Exact two-sided McNemar p={diagnostics['accuracy_mcnemar_exact_two_sided_p']:.6f}. Full-only correct: 42; model-only correct: 17; both correct: 70; neither correct: 48. This is a provisional development-set result, not a held-out generalization claim.", "",
    "## All full-workflow attempts: acceptance and iteration", "",
    *metric_table(all_full_metrics, ["majority_baseline", "first_round_prediction", "full_predictions", "full_failure_inclusive", "structural_only", "full_policy"]), "",
    f"The full gate accepted 19 of {len(full)} attempts (five Supported, fourteen Refuted). All 19 labels matched the dataset. Accepted-label accuracy has a 95% Wilson interval of {ci(accepted['selective_accuracy_ci95'])}; coverage interval {ci(accepted['coverage_ci95'])}. This small selected set does not demonstrate perfect reliability. The gate rejected 179 correct raw predictions and 104 wrong raw predictions, so it sacrifices substantial coverage.", "",
    f"Additional rounds changed 40 final predictions: eight wrong-to-correct, twenty correct-to-wrong, and twelve changes between wrong labels. The final-minus-first accuracy difference was {100*extra['delta_b_minus_a']:.2f} percentage points on these saved trajectories (bootstrap interval {100*extra['ci95'][0]:.2f} to {100*extra['ci95'][1]:.2f} points). This is trace truncation, not a separately rerun one-round experiment. Excluding the five fatal quota attempts, the difference on {len(nonfatal)} nonfatal attempts was {100*nonfatal_extra['delta_b_minus_a']:.2f} points (interval {100*nonfatal_extra['ci95'][0]:.2f} to {100*nonfatal_extra['ci95'][1]:.2f}), so operational quota failures alone do not explain the deterioration.", "",
    "There were 573 rounds after the first, including 153 with no new ledger records. These rounds consumed 655 searches, 1,266 fetch attempts and 14,822,163 observed model tokens. A new ledger record need not be newly usable independent evidence. More research did not improve label accuracy in this partial run.", "",
    "## Citation checks and rejection causes", "",
    f"Final-assessment citation occurrences: {citations['total']}; literal quotes in canonical retrieved text: {citations['exact_quote']}; Jev-reviewed quote occurrences: {citations['reviewed']}. Of those reviewed exact quotes, {citations['jev_does_not_support']} did not support their attached finding and {citations['jev_uncertain_support']} had supporting confidence below 0.8. Repeated citations across findings are counted separately. These are automated checks, not human judgments.", "",
    "The final structural gate reported insufficient source-independence flags for 224 claims and missing exact quotes for 218. These causes overlap. A missing literal quote can reflect citation/provenance mismatch and must not automatically be counted as a hallucination. Source independence is partly model-assessed; distinct hosts alone do not establish independent corroboration.", "",
    f"{same_host}/{len(full)} final assessments cited a host matching the dataset's fact-check article, after unwrapping Wayback Machine URLs to their original host. Host equality is only an exposure proxy: it does not prove exact article exposure, and lack of a match does not establish no leakage. Published fact checks and newer documents were available during contemporary web retrieval. The complete-study analysis helper currently compares archive wrapper hosts; this partial postprocessor corrects that proxy without changing the frozen inference code.", "",
    "## Operational costs", "",
    f"Full workflow: {full_exec['total_searches']:,} searches; {full_exec['total_page_fetches']:,} fetch attempts; {full_exec['total_observed_tokens']:,} observed tokens; mean {full_exec['mean_elapsed_seconds']:.1f} seconds per attempted claim (median {diagnostics['full_latency']['median_seconds']:.1f}, p90 {diagnostics['full_latency']['p90_seconds']:.1f}). Model-only mean {control_exec['mean_elapsed_seconds']:.1f} seconds. Concurrent per-claim durations are not study wall-clock time.", "",
    f"Model-only observed tokens: {control_exec['total_observed_tokens']:,}. Token accounting is incomplete, so these counts are lower-bound observations and cannot support an exact monetary cost estimate. Full execution error rate {percent(full_exec['execution_error_rate'])}; model-only {percent(control_exec['execution_error_rate'])}. There were 354 recorded fetch failures and two Jev ranking failures; these recoverable errors are distinct from the seven fatal quota failures.", "",
    "## Evaluated configuration and reproducibility", "",
    "Full workflow: validate, classify domain, decompose claim, retrieve, assess evidence, apply structural and Jev citation checks, route another research round, finalize. Control: same Ollama model and claim/date inputs, one structured label response, no search or verification gate. The model-only control isolates the combined workflow's contribution; it does not isolate LangGraph as a framework or Jev by itself.", "",
    "Model: gemma4:31b-cloud via Ollama, temperature 0. Jev: jev-1.13.0, citation confidence threshold 0.8. TinyFish supplies search and fetching. Seed 20261009; three workers; maximum three research rounds and 300-second soft scheduling budget per full claim. In-flight calls can finish after the soft budget. Current configuration, full claim ordering, package versions, source hash and dataset hash are archived in manifest.json and source-snapshot.zip.", "",
    f"Frozen inference source SHA-256: `{manifest['code_sha256']}`. Dataset SHA-256: `{manifest['dataset_sha256']}`. No evaluation source changes were made during this frozen v3 run. Analysis code is stored separately and hashed in partial-study-metrics.json.", "",
    "Policy replays change acceptance decisions using the same final evidence/assessment, not the research process. Threshold curves are descriptive and cannot establish optimal thresholds. Removing the exact-quote requirement also affects eligibility for semantic review, so it is not an isolated semantic ablation. NEI is a factual label, but decisive acceptance excludes it by design, making accepted NEI recall zero.", "",
    "## Code fixes completed before the frozen run", "",
    "1. Fixed inconsistent whitespace handling: the structural gate had trimmed citation quotes while semantic review and retention matched the literal string. A padded non-matching quote could therefore pass the structural check, skip semantic review and disappear from retained evidence. Structural checks now match literal quotes consistently. Regression tests cover both Jev-enabled and disabled paths.",
    "2. Fixed JSONL reading: Unicode paragraph/line separator characters inside valid JSON strings were incorrectly treated as record boundaries by splitlines(). Readers now iterate actual file lines. Regression coverage includes U+2028, U+2029 and U+0085.",
    "3. Added exact source-version and assessment traces, resumable matched controls, source/configuration freezing, failure-inclusive scoring, confidence intervals and reproducible offline policy replay. Final verification: 60 tests passed. The bug fixes improve correctness; no separate measured gain is attributed to those fixes.", "",
    "## What remains before using this as final paper evidence", "",
    "- Restore Ollama capacity and finish the frozen 500-by-two run. Do not merge a different model/configuration into this condition. Existing fatal attempts remain in the denominator.",
    "- Perform an independent human citation audit. The blinded CSV is prepared with blank human fields and a separate key; no human audit has been performed. An LLM reviewing its own experiment is not independent human validation.",
    "- Treat these as local four-class label metrics, not official AVeriTeC evidence/QA scores. No claim is made about benchmark leadership, verified hallucination reduction, clinical safety or historical fact-check reconstruction.",
    "- This is a repeatedly used development split with current-web access; it is not a pristine held-out test. Accuracy can be helped by published verdicts and changed by temporal drift.",
    "- Review iteration harm and the low acceptance coverage before making deployment claims. Changing the policy after inspecting these outcomes requires a separately versioned evaluation rather than silently tuning this run.", "",
    "## Saved artifacts", "",
    "- partial-study-metrics.json: matched metrics, all-attempt metrics, confidence intervals, costs, citation and failure diagnostics.",
    "- per-claim-results.csv: all full claims with available matched control labels and offline policy decisions.",
    "- human-citation-audit.csv: blinded evidence worksheet with blank human annotations. Keep human-audit-key.json separate from reviewers.",
    "- figures/: PNG, PDF and SVG descriptive figures, all explicitly marked partial.",
    "- Parent directory full/results.jsonl and closed_book/results.jsonl: original raw assessments, sources, budgets and errors.", "",
    "Resume from the repository root once the same model has capacity:", "",
    "```powershell", "uv run --offline --env-file .env python -m kaji_langgraph.study --limit 500 --workers 3 --seed 20261009 --max-rounds 3 --max-seconds 300 --output evaluation/results/study-20261009-v3 --resume", "```", "",
]
(OUT / "PARTIAL_RESULTS.md").write_text("\n".join(lines), encoding="utf-8")
print(json.dumps({"output": str(OUT), "comparisons": comparisons, "citations": dict(citations), "same_host": same_host}, indent=2))
