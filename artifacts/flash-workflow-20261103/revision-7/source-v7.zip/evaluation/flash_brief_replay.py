"""Compare a shorter response contract on frozen compact-passage requests."""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import httpx

from kaji_langgraph.assessment_lines import LINE_CITATIONS, LINE_CONTRACT, parse_assessment_lines
from kaji_langgraph.llm import OllamaBackend
from kaji_langgraph.models import BenchmarkAssessment

from flash_study import FlashLedger, MODELS, THREADS, digest, read, save, scan
from recount_flash_transport import answer_content
from runtime_pilot import transport


SCHEMA_EXAMPLE = {
    "proposed_verdict": "FALSE",
    "confidence": "High",
    "summary": "One sentence.",
    "evidence": [{"finding": "One fact", "stance": "refutes",
                  "source_urls": ["S1"], "quotes": {"S1": "P1"}}],
    "assertions": [{"assertion": "Copy the required assertion", "resolved": True,
                    "source_urls": ["S1"]}],
    "gaps": [],
    "contradictions": [],
    "counterevidence_searched": True,
    "sources_independent": True,
    "peer_reviewed_sources": False,
    "next_queries": [],
}


def brief_request(request):
    body = deepcopy(request)
    original = body["messages"][-1]["content"]
    prompt, separator, _ = original.rpartition("\n\nReturn ONLY one JSON object matching this JSON Schema. ")
    if not separator:
        raise ValueError("Unexpected original schema suffix")
    body["messages"][-1]["content"] = (
        prompt + "\n\nReturn one compact JSON object. Start with {. "
        "Use the keys and nesting below and choose every value from the evidence. "
        "Example values are placeholders. Use TRUE, FALSE, CONFLICTING or NOT_ENOUGH_EVIDENCE. "
        "Use High, Medium or Low confidence and supports, refutes or context for stance. "
        "Use at most four short findings unless more are required to cover the listed assertions. "
        "Use one source and passage ID per finding. Include only gaps that affect the verdict. "
        "Use empty lists for fields with no entries.\n"
        + json.dumps(SCHEMA_EXAMPLE, separators=(",", ":"))
    )
    return body


def parsed_assessment(answer):
    try:
        return OllamaBackend._parse_json(BenchmarkAssessment, answer)
    except ValueError:
        return None


def line_request(request):
    body = deepcopy(request)
    original = body["messages"][-1]["content"]
    prompt, separator, _ = original.rpartition("\n\nReturn one compact JSON object.")
    left, start, rest = prompt.partition("Use short findings. For each finding and assertion,")
    _, end, right = rest.partition("you cite. Keep summary and rationales to one sentence each.")
    if not (separator and start and end):
        raise ValueError("Unexpected compact request")
    body["messages"][-1]["content"] = (
        (left + LINE_CITATIONS + right).replace(" Follow the restricted JSON schema below.", "")
        + LINE_CONTRACT
    )
    body.pop("format", None)
    return body


def prepare(run, out):
    root = run / "revision-3" / "development"
    cases = []
    for model, claim in (("glm", "1218"), ("glm", "1225"), ("glm", "1217"), ("deepseek", "1225")):
        directory = root / f"train-{claim}-{model}-candidate"
        primaries = []
        for path in sorted(directory.glob("request-*.json")):
            record = read(path)
            if record["service"] != "ollama":
                continue
            body = record["request"]["body"]
            prompt = body["messages"][-1]["content"]
            if not prompt.startswith("You are an evidence analyst"):
                continue
            suffix = path.stem.split("-")[1]
            response = directory / f"response-{suffix}.body"
            old = parsed_assessment(answer_content(response))
            if model == "glm" and old is not None:
                continue
            if model == "deepseek" and (old is None or old.proposed_verdict != "TRUE"):
                continue
            primaries.append((path, response, body, old))
        path, response, body, old = primaries[-1]
        cases.append({
            "id": f"{model}-{claim}", "model": model, "old_request": path.as_posix(),
            "old_response": response.as_posix(), "old_request_sha256": digest(path),
            "old_response_sha256": digest(response), "old_proposal": old.proposed_verdict if old else None,
            "brief_request": brief_request(body),
        })
    out.mkdir(exist_ok=True)
    save(out / "protocol.json", {
        "cases": cases, "models": MODELS, "caps": {"ollama": 1}, "num_predict": 4096,
        "screen": "Require valid evidence-bearing output and valid IDs in all four replies, and keep the DeepSeek Supported proposal. The screen concerns the output contract on fixed evidence.",
    })


def execute(out, protocol, case):
    cell = out / case["id"]
    body = case["brief_request"]
    model = MODELS[case["model"]]
    if body["model"] != model or body["options"]["num_predict"] != protocol["num_predict"]:
        raise ValueError("Frozen model or generation cap mismatch")
    original = read(Path(case["old_request"]))["request"]["body"]
    expected = line_request(original) if protocol.get("line_only") else brief_request(original)
    if protocol.get("cap_only"):
        expected["options"]["num_predict"] = protocol["num_predict"]
    if (digest(Path(case["old_request"])) != case["old_request_sha256"]
            or digest(Path(case["old_response"])) != case["old_response_sha256"]
            or expected != body):
        raise ValueError("Saved pair does not match the frozen request")
    ledger = FlashLedger(cell, protocol, model)
    ledger.task = case["id"]
    with httpx.Client(transport=transport(httpx, ledger, "ollama"), timeout=90,
                      trust_env=False, follow_redirects=False) as client:
        reply = client.post("http://localhost:11434/api/chat", json=body)
        reply.raise_for_status()
    usage = scan(cell, model)
    answer = answer_content(cell / "response-001.body")
    if protocol.get("line_only"):
        try:
            assessment = parse_assessment_lines(
                answer, stopped_normally=bool(usage and usage[0].get("done_reason") == "stop")
            )
        except ValueError:
            assessment = None
    else:
        assessment = parsed_assessment(answer)
    prompt = body["messages"][-1]["content"]
    source_text = prompt.split("Retrieved records:\n", 1)[1].split("\n\nThe jev_scores", 1)[0]
    sources = {item["id"]: item["passages"] for item in json.loads(source_text)}
    refs = [(source_id, item.quotes.get(source_id)) for item in (assessment.evidence if assessment else [])
            for source_id in item.source_urls]
    valid = bool(refs) and all(passage in sources.get(source_id, {}) for source_id, passage in refs)
    proposal = assessment.proposed_verdict if assessment else None
    if protocol.get("line_only"):
        content_ok = bool(assessment and (valid or (proposal == "NOT_ENOUGH_EVIDENCE" and not refs)))
    elif protocol.get("cap_only"):
        expected_verdict = case["expected_verdict"]
        evidence_ok = valid or (expected_verdict == "NOT_ENOUGH_EVIDENCE" and not refs)
        content_ok = proposal == expected_verdict and evidence_ok
    else:
        content_ok = valid and (case["model"] != "deepseek" or proposal == "TRUE")
    passed = bool(content_ok and len(usage) == 1 and usage[0].get("model_verified")
                  and not usage[0].get("incomplete"))
    save(cell / "result.json", {"passed": passed, "parsed": assessment is not None,
                              "valid_passage_ids": valid, "proposed_verdict": proposal,
                              "assessment": assessment.model_dump() if assessment else None, "usage": usage})


def launch(out, protocol):
    for case in protocol["cases"]:
        cell = out / case["id"]
        if cell.exists():
            raise SystemExit(f"Attempt already reserved: {cell}")
        cell.mkdir()
        save(cell / "attempt.json", {"id": case["id"], "started_at": datetime.now(timezone.utc).isoformat()})
        save(cell / "live-state.json", {"counts": {"ollama": 0}, "deadline": time.time() + 270, "stop": None})
        started = time.monotonic()
        with (cell / "stdout.log").open("wb") as stdout, (cell / "stderr.log").open("wb") as stderr:
            try:
                job = subprocess.run([sys.executable, __file__, str(out), "--cell", case["id"]],
                                     timeout=300, env={**os.environ, **THREADS, "PYTHONUTF8": "1"},
                                     stdout=stdout, stderr=stderr)
                exit_code = job.returncode
            except subprocess.TimeoutExpired:
                exit_code = None
        save(cell / "job.json", {"exit_code": exit_code, "elapsed_seconds": time.monotonic() - started})
        result = read(cell / "result.json") if (cell / "result.json").is_file() else {}
        print(case["id"], result.get("passed"), flush=True)
        if exit_code != 0 or read(cell / "live-state.json").get("stop"):
            raise SystemExit("Transport or worker stop. Preserve the started cell.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--prepare-from", type=Path)
    parser.add_argument("--cell")
    args = parser.parse_args()
    out = args.directory.resolve()
    if args.prepare_from:
        prepare(args.prepare_from, out)
        return
    protocol = read(out / "protocol.json")
    approval = out / "approval.json"
    if not approval.exists() or read(approval).get("approved_protocol_sha256") != digest(out / "protocol.json"):
        raise SystemExit("No matching allowance for this replay")
    if args.cell:
        case = next(case for case in protocol["cases"] if case["id"] == args.cell)
        cell = out / case["id"]
        if not (cell / "attempt.json").exists() or list(cell.glob("request-*.json")):
            raise SystemExit("Replay requires a fresh reservation")
        execute(out, protocol, case)
    else:
        launch(out, protocol)


if __name__ == "__main__":
    main()
