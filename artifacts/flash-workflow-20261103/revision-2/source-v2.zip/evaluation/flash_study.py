"""Sequential Flash workflow comparison with an auditable per-attempt journal."""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from runtime_pilot import Ledger, LimitReached, load_keys, transport


MODELS = {
    "glm": "glm-5.3-flash:cloud",
    "deepseek": "deepseek-v4.1-flash:cloud",
}
CAPS = {"ollama": 8, "jev": 40, "tinyfish_search": 6, "tinyfish_fetch": 12}
THREADS = dict.fromkeys(("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                        "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"), "2")


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def task_id(task):
    return f"{task['case']}-{task['model']}-{task['arm']}"


def attempt_path(run, phase, protocol, task):
    identity = task_id(task)
    if identity in protocol.get("reused_attempts", {}):
        return Path(protocol["reused_attempts"][identity])
    return run / phase / identity


def scan(directory, model):
    """Read raw response bodies, including compressed SDK responses."""
    sends = []
    for path in sorted(directory.glob("request-*.json")):
        request = read(path)
        service = request["service"]
        suffix = path.stem.split("-")[1]
        meta = directory / f"response-{suffix}.json"
        body = directory / f"response-{suffix}.body"
        response = read(meta) if meta.exists() else {}
        record = {"service": service, "request_id": suffix, "sent_at": request["timestamp"],
                  "status": response.get("status"), "transport_error": response.get("error")}
        if not body.exists() or not meta.exists():
            record["incomplete"] = True
        elif response["status"] == 200 and service in {"ollama", "jev"}:
            try:
                raw = body.read_bytes()
                if raw.startswith(b"\x1f\x8b"):
                    raw = gzip.decompress(raw)
                if service == "ollama":
                    value = json.loads(raw.splitlines()[-1])
                    record.update(returned_model=value["model"], requested_model=model,
                                  done=value["done"], done_reason=value.get("done_reason"),
                                  input_tokens=value["prompt_eval_count"], output_tokens=value["eval_count"])
                    record["model_verified"] = value["model"] in {model, model.removesuffix(":cloud")}
                    record["incomplete"] = not value["done"]
                else:
                    value = json.loads(raw)
                    record.update(returned_model=value["model"], requested_model="jev-1.13.0",
                                  model_verified=value["model"] == "jev-1.13.0", **value["usage"])
            except (ValueError, OSError, IndexError, KeyError) as exc:
                record["accounting_error"] = str(exc)
        sends.append(record)
    return sends


class FlashLedger(Ledger):
    def __init__(self, directory, protocol, model):
        super().__init__(directory, protocol)
        self.model = model

    def response(self, number, status, body):
        super().response(number, status, body)
        path = self.directory / f"request-{number:03}.json"
        if read(path)["service"] != "ollama" or status != 200:
            return
        try:
            response = json.loads(body.splitlines()[-1])
            if not response.get("done") or response.get("model") not in {
                self.model, self.model.removesuffix(":cloud")
            }:
                raise LimitReached("Unexpected Ollama model ID or incomplete terminal reply")
        except (ValueError, IndexError, LimitReached) as exc:
            self.failed(number, exc)
            raise


def run_cell(directory, protocol, task, case):
    import httpx
    import httpx2
    import urllib.error
    import urllib.request
    from langchain_ollama import ChatOllama
    from typesafe_sdk import RetryPolicy, TypeSafeClient
    import kaji_langgraph.jev as jev_module
    from kaji_langgraph.evaluation import model_input, prediction_label
    from kaji_langgraph.graph import run_claim
    from kaji_langgraph.llm import OllamaBackend
    from kaji_langgraph.retrieval import TinyFishRetriever

    load_keys()
    model = MODELS[task["model"]]
    config = deepcopy(protocol["config"])
    config["model"].update(name=model, canonical_evidence_prompt=task["arm"] == "candidate")
    recover = task["arm"] == "candidate" and protocol.get("recover_empty_assessment", False)
    ledger = FlashLedger(directory, protocol, model)
    ledger.task = task_id(task)
    backend = OllamaBackend(model=model, base_url=config["model"]["base_url"], temperature=0,
                            verdict_mode="averitec",
                            canonical_evidence_prompt=config["model"]["canonical_evidence_prompt"],
                            recover_empty_assessment=recover)
    backend._model = ChatOllama(
        model=model, base_url=backend.base_url, temperature=0,
        num_predict=protocol["num_predict"], validate_model_on_init=False,
        client_kwargs={"transport": transport(httpx, ledger, "ollama"), "timeout": 90,
                       "follow_redirects": False, "trust_env": False},
    )

    def jev_client(**kwargs):
        return TypeSafeClient(**kwargs, retry=RetryPolicy(max_retries=0),
                              http_client=httpx2.Client(
                                  transport=transport(httpx2, ledger, "jev"), timeout=15,
                                  follow_redirects=False))

    jev_module.TypeSafeClient = jev_client

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None

    opener = urllib.request.build_opener(NoRedirect())

    class LoggedRetriever(TinyFishRetriever):
        def _request(self, url, *, payload=None, timeout):
            service = "tinyfish_search" if payload is None else "tinyfish_fetch"
            number = ledger.before(service, {"url": url, "body": payload})
            request = urllib.request.Request(
                url, data=None if payload is None else json.dumps(payload).encode("utf-8"),
                headers={"X-API-Key": os.environ["TINYFISH_API_KEY"], "Accept": "application/json",
                         "Content-Type": "application/json"},
            )
            try:
                try:
                    response = opener.open(request, timeout=timeout)
                except urllib.error.HTTPError as exc:
                    response = exc
                with response:
                    status = response.status
                    body = response.read(2_000_001)
                ledger.response(number, status, body[:2_000_000])
                if status != 200 or len(body) > 2_000_000:
                    raise RuntimeError(f"TinyFish HTTP {status}; response size {len(body)}")
                value = json.loads(body)
                if not isinstance(value, dict):
                    raise ValueError("Expected TinyFish JSON object")
                return value
            except Exception as exc:
                ledger.failed(number, exc)
                raise

    with (directory / "progress.log").open("w", encoding="utf-8") as log:
        def progress(message):
            print(message, file=log, flush=True)

        result = run_claim(
            **model_input(case), config=config, max_rounds=protocol["rounds"],
            model=backend, retriever=LoggedRetriever(),
            jev=jev_module.JevClient(model=config["jev"]["model"]), progress=progress,
        )
    save(directory / "result.json", {
        **task, "requested_model": model, "gold_label": case["label"],
        "predicted_label": prediction_label(result.predicted_verdict),
        "accepted_label": prediction_label(result.verdict), "result": result.model_dump(mode="json"),
    })


def check_protocol(run, phase, protocol):
    from kaji_langgraph.evaluation import code_digest

    if protocol["source_sha256"] != code_digest():
        raise SystemExit("Runtime source differs from the frozen phase")
    for name, expected in protocol["file_sha256"].items():
        if digest(Path(name)) != expected:
            raise SystemExit(f"Frozen input changed: {name}")
    if protocol["models"] != MODELS or protocol["caps"] != CAPS:
        raise SystemExit("Unexpected service model or request limits")
    if not (run / "headroom.json").is_file():
        raise SystemExit("Included service headroom has not been recorded")
    approval = run / f"{phase}-approval.json"
    if not approval.is_file() or read(approval).get("approved_protocol_sha256") != digest(run / f"{phase}.json"):
        raise SystemExit("No matching live allowance for the frozen phase")
    if phase != "development":
        prior = "development" if phase == "confirmation" else "confirmation"
        decision = run / f"{prior}-decision.json"
        if not decision.is_file() or read(decision).get("passed") is not True:
            raise SystemExit(f"{prior} quality screen has not passed")


def tally(run, phase):
    sends = []
    for path in (run / phase).glob("*/usage.json"):
        sends.extend(read(path))
    totals = Counter()
    for send in sends:
        totals[send["service"]] += 1
        for key in ("input_tokens", "output_tokens"):
            totals[f"{send['service']}_{key}"] += send.get(key, 0)
        if send["service"] == "ollama":
            inp, out = (0.15, 0.50) if send["requested_model"] == MODELS["glm"] else (0.30, 1.20)
            totals["ollama_estimated_usd"] += (
                inp * send.get("input_tokens", 0) + out * send.get("output_tokens", 0)
            ) / 1_000_000
    totals["jev_estimated_usd"] = totals["jev_input_tokens"] * 0.042 / 1_000_000
    return dict(totals)


def launch(run, phase, protocol, limit):
    stage = run / phase
    stage.mkdir(exist_ok=True)
    # An exclusive claim of the phase prevents concurrent execution.
    lock = stage / "running.lock"
    with lock.open("x", encoding="utf-8") as handle:
        print(os.getpid(), file=handle)
    try:
        for directory in stage.iterdir():
            if not directory.is_dir():
                continue
            job = directory / "job.json"
            if not job.exists():
                raise SystemExit(f"Started attempt needs adjudication: {directory.name}")
            if read(job).get("hard_stop") and not (directory / "resume-review.json").is_file():
                raise SystemExit(f"Unresolved service/transport stop: {directory.name}")
        started = 0
        for task in protocol["schedule"]:
            directory = attempt_path(run, phase, protocol, task)
            if directory.exists():
                continue
            totals = tally(run, phase)
            if any(totals.get(key, 0) >= amount for key, amount in protocol["usage_stop"].items()):
                raise SystemExit(f"Phase allowance reached: {totals}")
            if started == limit:
                break
            directory.mkdir()
            started += 1
            begin = time.monotonic()
            save(directory / "attempt.json", {
                **task, "started_at": datetime.now(timezone.utc).isoformat(),
                "protocol_sha256": digest(run / f"{phase}.json"),
            })
            save(directory / "live-state.json", {
                "counts": dict.fromkeys(CAPS, 0), "deadline": time.time() + 285, "stop": None,
            })
            with (directory / "stdout.log").open("wb") as out, (directory / "stderr.log").open("wb") as err:
                try:
                    result = subprocess.run(
                        [sys.executable, __file__, str(run), phase, "--cell", task_id(task)],
                        timeout=300, stdout=out, stderr=err,
                        env={**os.environ, **THREADS, "PYTHONUTF8": "1"},
                    )
                    exit_code = result.returncode
                except subprocess.TimeoutExpired:
                    exit_code = None
            usage = scan(directory, MODELS[task["model"]])
            save(directory / "usage.json", usage)
            counts = Counter(send["service"] for send in usage)
            state = read(directory / "live-state.json")
            invalid_usage = (
                any(send.get("status") != 200 or send.get("incomplete") or send.get("accounting_error")
                    or send.get("model_verified") is False or send.get("transport_error") for send in usage)
                or any(counts[key] != value for key, value in state["counts"].items())
            )
            hard_stop = bool(exit_code != 0 or state["stop"] or invalid_usage)
            save(directory / "job.json", {
                "exit_code": exit_code, "elapsed_seconds": time.monotonic() - begin,
                "hard_stop": hard_stop, "stop_reason": state["stop"],
                "accounting_problem": invalid_usage,
            })
            totals = tally(run, phase)
            print(task_id(task), "STOP" if hard_stop else "DONE", totals, flush=True)
            if hard_stop:
                raise SystemExit(f"Inspect retained attempt before resuming: {directory.name}")
    finally:
        lock.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    parser.add_argument("phase", choices=("development", "confirmation", "final"))
    parser.add_argument("--limit", type=int, default=1)
    parser.add_argument("--cell")
    args = parser.parse_args()
    run = args.run.resolve()
    protocol = read(run / f"{args.phase}.json")
    check_protocol(run, args.phase, protocol)
    if args.cell:
        task = next(task for task in protocol["schedule"] if task_id(task) == args.cell)
        cases = read(Path(protocol["cases"]))
        directory = run / args.phase / args.cell
        if not (directory / "attempt.json").is_file() or list(directory.glob("request-*.json")):
            raise SystemExit("Worker requires a reserved untouched attempt")
        run_cell(directory, protocol, task, cases[task["case"]])
    else:
        if args.limit < 1:
            parser.error("--limit must be positive")
        launch(run, args.phase, protocol, args.limit)


if __name__ == "__main__":
    main()
