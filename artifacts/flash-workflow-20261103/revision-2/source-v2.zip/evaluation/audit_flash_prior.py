"""Recount historical quotation failures that motivated the Flash candidate."""
from collections import Counter
import json
from pathlib import Path
import unicodedata


STUDY = Path("evaluation/results/study-20261009-v3")
PUNCTUATION = str.maketrans({"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-"})


def normalize(text):
    return " ".join(unicodedata.normalize("NFC", text).translate(PUNCTUATION).split())


def recount():
    diagnostics = json.loads((STUDY / "diagnostics.json").read_text(encoding="utf-8"))
    selected = set(diagnostics["only_missing_quote_rejection_claims"])
    counts = Counter()
    examples = {}
    with (STUDY / "full/results.jsonl").open(encoding="utf-8") as handle:
        for line in handle:
            row = json.loads(line)
            if row["claim_id"] not in selected:
                continue
            counts["claims"] += 1
            correct = row["predicted_label"] == row["gold_label"]
            counts["correct_label"] += correct
            result = row["result"]
            trace = result["research_history"][-1]
            versions = {(s["url"], s["content_hash"]): s for s in result["retrieval_ledger"]}
            sources = {url: versions[url, digest] for url, digest in trace["usable_source_keys"]}
            failures = set()
            for item in trace["assessment"]["evidence"]:
                for url in item["source_urls"]:
                    quote = item["quotes"].get(url, "")
                    source = sources[url]
                    body = source["page_text"] or source["snippet"]
                    if quote.strip() and quote in body:
                        continue
                    if not quote.strip():
                        reason = "empty"
                    elif normalize(quote) in normalize(body):
                        reason = "typographic"
                    elif quote in source["snippet"]:
                        reason = "noncanonical_snippet"
                    else:
                        reason = "other"
                    failures.add(reason)
                    counts[reason] += 1
                    examples.setdefault(reason, []).append({"claim_id": row["claim_id"], "url": url})
            if failures == {"typographic"}:
                counts["fully_typographic"] += 1
                counts["fully_typographic_and_correct_label"] += correct
    if counts["claims"] != len(selected):
        raise ValueError("Historical replay rows do not match the saved diagnostic case set")
    return {"counts": dict(counts), "failed_citations": examples,
            "scope": "Diagnostic normalization only. No gate replay, semantic support, or live inference."}


if __name__ == "__main__":
    print(json.dumps(recount(), ensure_ascii=False, indent=2))
