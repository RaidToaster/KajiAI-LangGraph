"""Recount paired Flash results and extract citation audit records offline."""
from __future__ import annotations

import argparse
from collections import Counter
from pathlib import Path
import random

from kaji_langgraph.evaluation import ABSTAIN, classification_metrics
from kaji_langgraph.graph import _citation_key
from kaji_langgraph.study_analysis import replay_sources

from flash_study import MODELS, attempt_path, digest, read, save, tally, task_id


def extract_citations(result, threshold):
    history = result["research_history"]
    if not history or not history[-1]["assessment"]:
        return []
    trace = history[-1]
    sources = {s.url: s for s in replay_sources(result, trace)}
    reviews = {r["key"]: r for r in result["jev_audit"].get("citations", [])
               if r["round"] == trace["round_number"]}
    citations = []
    for item in trace["assessment"]["evidence"]:
        for url in item["source_urls"]:
            source = sources.get(url)
            quote = item["quotes"].get(url, "")
            exact = bool(source and quote.strip() and quote in source.retrieved_text)
            review = None
            context = None
            if exact:
                offset = source.retrieved_text.index(quote)
                context = source.retrieved_text[max(0, offset - 1200):offset + len(quote) + 1200]
                review = reviews.get(_citation_key(item["finding"], url, quote, source.content_hash))
            citations.append({
                "finding": item["finding"], "stance": item["stance"], "url": url, "quote": quote,
                "content_hash": source.content_hash if source else None,
                "exact": exact, "review": review,
                "supports": bool(review and review["relation"] == "supports"
                                 and review["confidence"] >= threshold),
                "context": context,
            })
    return citations


def summarize(rows):
    gold = [r["gold_label"] for r in rows]
    pred = classification_metrics(gold, [r["prediction"] for r in rows])
    accepted = classification_metrics(gold, [r["accepted"] for r in rows])
    counts = Counter()
    for row in rows:
        counts["failed"] += row["failed"]
        if row["accepted"] != ABSTAIN:
            counts["accepted"] += 1
            counts["correct_accepted"] += row["accepted"] == row["gold_label"]
            counts["incorrect_accepted"] += row["accepted"] != row["gold_label"]
            counts["acceptance_missing_citation_checks"] += not (
                row["citations"] and all(c["exact"] and c["supports"] for c in row["citations"])
            )
        for citation in row["citations"]:
            counts["citations"] += 1
            counts["exact_citations"] += citation["exact"]
            counts["jev_supported_citations"] += citation["supports"]
    return {"counts": dict(counts), "raw": pred, "gate": accepted}


def paired_bootstrap(baseline, candidate):
    n = len(baseline)
    gold = [r["gold_label"] for r in baseline]
    a = [r["prediction"] for r in baseline]
    b = [r["prediction"] for r in candidate]
    correct_accept = [int(y["accepted"] == g) - int(x["accepted"] == g)
                      for x, y, g in zip(baseline, candidate, gold)]
    wrong_accept = [int(y["accepted"] not in {g, ABSTAIN}) - int(x["accepted"] not in {g, ABSTAIN})
                    for x, y, g in zip(baseline, candidate, gold)]
    correct_raw = [int(y == g) - int(x == g) for x, y, g in zip(a, b, gold)]
    rng = random.Random(260311)
    values = {k: [] for k in ("accuracy", "macro_f1", "correct_acceptance", "incorrect_acceptance")}
    for _ in range(10_000):
        ids = rng.choices(range(n), k=n)
        sampled_gold = [gold[i] for i in ids]
        ma = classification_metrics(sampled_gold, [a[i] for i in ids])["macro_f1"]
        mb = classification_metrics(sampled_gold, [b[i] for i in ids])["macro_f1"]
        values["macro_f1"].append(mb - ma)
        for key, vector in (("accuracy", correct_raw), ("correct_acceptance", correct_accept),
                            ("incorrect_acceptance", wrong_accept)):
            values[key].append(sum(vector[i] for i in ids) / n)
    return {key: [sorted(draws)[249], sorted(draws)[9749]] for key, draws in values.items()}


def analyze(run, phase):
    protocol = read(run / f"{phase}.json")
    cases = read(Path(protocol["cases"]))
    observed = {}
    audits = []
    for task in protocol["schedule"]:
        directory = attempt_path(run, phase, protocol, task)
        if not (directory / "attempt.json").is_file():
            continue
        path = directory / "result.json"
        job = directory / "job.json"
        if not job.is_file():
            raise SystemExit(f"Attempt still running or requires recovery: {directory}")
        record = read(path) if path.exists() else {}
        result = record.get("result")
        gold = cases[task["case"]]["label"]
        if record and (record["gold_label"] != gold or record["requested_model"] != MODELS[task["model"]]
                       or any(record[k] != task[k] for k in task)):
            raise ValueError(f"Result identity mismatch in {directory}")
        failed = (not result or result["verification_status"] == "execution_error"
                  or read(job)["hard_stop"])
        citations = extract_citations(result, protocol["config"]["jev"]["citation_min_confidence"]) if result else []
        row = {
            **task, "gold_label": gold, "failed": failed,
            "prediction": ABSTAIN if failed else record["predicted_label"],
            "accepted": ABSTAIN if failed else record["accepted_label"],
            "citations": citations, "stop_reason": result["stop_reason"] if result else "worker_failure",
            "gaps": result["gaps"] if result else [], "errors": result["errors"] if result else [],
        }
        observed[task["case"], task["model"], task["arm"]] = row
        if row["accepted"] != ABSTAIN:
            audits.append({**row, "claim": cases[task["case"]]["claim"],
                           "summary": result["prediction_summary"], "audit_decision": None})
    scores = {}
    for model in MODELS:
        arms = {}
        for arm in ("baseline", "candidate"):
            arms[arm] = [r for r in observed.values() if r["model"] == model and r["arm"] == arm]
        a, b = [], []
        for case in cases:
            if (case, model, "baseline") in observed and (case, model, "candidate") in observed:
                a.append(observed[case, model, "baseline"])
                b.append(observed[case, model, "candidate"])
        model_metrics = {arm: summarize(rows) for arm, rows in arms.items()}
        model_metrics["paired"] = {
            "n": len(a), "baseline": summarize(a), "candidate": summarize(b),
            "gained_correct": [x["case"] for x, y in zip(a, b)
                               if x["prediction"] != x["gold_label"] == y["prediction"]],
            "lost_correct": [x["case"] for x, y in zip(a, b)
                             if y["prediction"] != y["gold_label"] == x["prediction"]],
            "gained_correct_acceptance": [x["case"] for x, y in zip(a, b)
                                         if x["accepted"] != x["gold_label"] == y["accepted"]],
            "lost_correct_acceptance": [x["case"] for x, y in zip(a, b)
                                       if y["accepted"] != y["gold_label"] == x["accepted"]],
        }
        if phase == "final" and len(a) == len(cases):
            model_metrics["paired"]["bootstrap_ci95"] = paired_bootstrap(a, b)
        scores[model] = model_metrics
    return {
        "phase": phase, "planned_attempts": len(protocol["schedule"]), "attempted": len(observed),
        "models": scores, "actual_usage": tally(run, phase),
        "reused_attempts": protocol.get("reused_attempts", {}),
        "cases": [{**row, "citations": len(row["citations"])} for row in observed.values()],
        "citation_audit": audits,
    }


def screen(report, audit):
    """Apply the frozen small-sample gate after explicit evidence adjudication."""
    required = 8 if report["phase"] == "development" else 12
    expected = {task_id(row) for row in report["citation_audit"]}
    if set(audit) != expected:
        raise ValueError("Evidence adjudications must cover every accepted case exactly once")
    for decision in audit.values():
        if type(decision["supported"]) is not bool or not decision["reason"].strip():
            raise ValueError("Each adjudication requires a support decision and reason")

    decisions = {}
    for model, metrics in report["models"].items():
        baseline = metrics["baseline"]
        candidate = metrics["candidate"]
        counts = Counter()
        candidate_unsupported = []
        for row in report["citation_audit"]:
            if row["model"] != model:
                continue
            supported = audit[task_id(row)]["supported"]
            counts[row["arm"]] += supported and row["accepted"] == row["gold_label"]
            if row["arm"] == "candidate" and not supported:
                candidate_unsupported.append(row["case"])
        a, b = baseline["counts"], candidate["counts"]
        reasons = {
            "complete": metrics["paired"]["n"] == required,
            "supported_correct_acceptance_gain": counts["candidate"] > counts["baseline"],
            "no_added_incorrect_acceptance": b.get("incorrect_accepted", 0) <= a.get("incorrect_accepted", 0),
            "raw_accuracy_preserved": candidate["raw"]["accuracy"] >= baseline["raw"]["accuracy"],
            "macro_f1_within_margin": candidate["raw"]["macro_f1"] >= baseline["raw"]["macro_f1"] - 0.02,
            "all_accepted_candidate_citations_pass": not b.get("acceptance_missing_citation_checks"),
            "all_candidate_acceptances_supported_on_audit": not candidate_unsupported,
            "no_increase_in_execution_failure": b.get("failed", 0) <= a.get("failed", 0),
        }
        decisions[model] = {"passed": all(reasons.values()), "criteria": reasons,
                            "supported_correct_counts": dict(counts),
                            "unsupported_candidate_cases": candidate_unsupported}
    return {"passed": all(d["passed"] for d in decisions.values()), "models": decisions,
            "audit_scope": "Research-agent adjudications separate from independent human annotation"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    parser.add_argument("phase", choices=("development", "confirmation", "final"))
    parser.add_argument("--adjudications", type=Path)
    args = parser.parse_args()
    report = analyze(args.run, args.phase)
    save(args.run / f"{args.phase}-analysis.json", report)
    if args.adjudications:
        if args.phase == "final":
            parser.error("Only the development and confirmation phases have an advancement screen")
        decision = screen(report, read(args.adjudications))
        decision.update(
            protocol_sha256=digest(args.run / f"{args.phase}.json"),
            adjudications=args.adjudications.as_posix(),
            adjudications_sha256=digest(args.adjudications),
        )
        save(args.run / f"{args.phase}-decision.json", decision)
    print(f"{report['attempted']}/{report['planned_attempts']} attempted")
    for model, metrics in report["models"].items():
        for arm in ("baseline", "candidate"):
            row = metrics[arm]
            print(model, arm, "n", row["raw"]["n"], "accuracy", row["raw"]["accuracy"],
                  "macro F1", row["raw"]["macro_f1"], row["counts"])


if __name__ == "__main__":
    main()
