"""Run a fixed-evidence diagnostic for the optional provenance review."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
import subprocess
import sys
import time

import httpx2
from typesafe_sdk import RetryPolicy, TypeSafeClient

import kaji_langgraph.jev as jev_module
from flash_study import THREADS, digest, read, save, scan
from runtime_pilot import Ledger, load_keys, transport


def run_cell(directory, protocol, case):
    load_keys()
    ledger = Ledger(directory, {"caps": {"jev": 1}})
    ledger.task = case["id"]

    def client(**kwargs):
        return TypeSafeClient(
            **kwargs, retry=RetryPolicy(max_retries=0),
            http_client=httpx2.Client(transport=transport(httpx2, ledger, "jev"),
                                      timeout=15, follow_redirects=False),
        )

    jev_module.TypeSafeClient = client
    review, _ = jev_module.JevClient(model="jev-1.13.0").check_provenance(
        case["claim"], case["verdict"], case["citations"], timeout=12,
    )
    usage = scan(directory, "")
    healthy = (len(usage) == 1 and usage[0]["status"] == 200
               and usage[0].get("model_verified") and not usage[0].get("incomplete")
               and not read(directory / "live-state.json")["stop"])
    matches = review["relation"] in case["expected"]
    if review["relation"] == "independent":
        matches = matches and review["confidence"] >= protocol["minimum_independent_confidence"]
    save(directory / "result.json", {"review": review, "usage": usage,
                                      "passed": bool(matches and healthy)})
    if not healthy:
        raise SystemExit("Unreconciled provenance request")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    parser.add_argument("--cell")
    args = parser.parse_args()
    run = args.run.resolve()
    path = run / "protocol.json"
    protocol = read(path)
    receipt = run / "approval.json"
    if not receipt.is_file() or read(receipt)["approved_protocol_sha256"] != digest(path):
        raise SystemExit("No matching live allowance for this diagnostic")
    cases = {case["id"]: case for case in protocol["cases"]}
    if len(protocol["cases"]) != len(cases) or len(cases) > 3 or protocol["models"] != {"jev": "jev-1.13.0"}:
        raise SystemExit("Unexpected case count or model")
    if args.cell:
        directory = run / args.cell
        if not (directory / "attempt.json").is_file() or list(directory.glob("request-*.json")):
            raise SystemExit("Diagnostic requires a fresh reservation")
        run_cell(directory, protocol, cases[args.cell])
        return
    for case_id in cases:
        directory = run / case_id
        directory.mkdir()
        save(directory / "attempt.json", {"id": case_id, "started_at": datetime.now(timezone.utc).isoformat()})
        save(directory / "live-state.json", {"counts": {"jev": 0}, "deadline": time.time() + 270, "stop": None})
        started = time.monotonic()
        with (directory / "stdout.log").open("wb") as out, (directory / "stderr.log").open("wb") as err:
            try:
                worker = subprocess.run([sys.executable, __file__, str(run), "--cell", case_id],
                                        env={**os.environ, **THREADS, "PYTHONUTF8": "1"},
                                        timeout=300, stdout=out, stderr=err)
                exit_code = worker.returncode
            except subprocess.TimeoutExpired:
                exit_code = None
        save(directory / "job.json", {"exit_code": exit_code, "elapsed_seconds": time.monotonic() - started})
        if exit_code != 0:
            raise SystemExit(f"Preserve and inspect diagnostic attempt {case_id}")
        print(case_id, read(directory / "result.json")["passed"], flush=True)


if __name__ == "__main__":
    main()
