"""Approval-gated, sequential two-claim live development pilot.

No inference occurs without a separately saved approval receipt. Transport-level
accounting includes repairs, failed sends and SDK attempts. Never resumes a send
whose outcome is unknown after a timeout.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf8")


class LimitReached(RuntimeError):
    pass


class Ledger:
    def __init__(self, directory: Path, protocol: dict):
        self.directory, self.protocol = directory, protocol

    def before(self, service, request):
        state = json.loads((self.directory / "live-state.json").read_text(encoding="utf8"))
        if state.get("stop") or time.time() >= state["deadline"]:
            raise LimitReached("Pilot stopped or deadline reached")
        if state["counts"][service] >= self.protocol["caps"][service]:
            state["stop"] = f"{service} request cap"
            write(self.directory / "live-state.json", state)
            raise LimitReached(state["stop"])
        state["counts"][service] += 1
        number = sum(state["counts"].values())
        write(self.directory / "live-state.json", state)  # reserve before sending
        write(self.directory / f"request-{number:03}.json", {
            "service": service, "request": request,
            "task":getattr(self,"task",None),
            "timestamp": datetime.now(timezone.utc).isoformat(), "status": "reserved_outcome_unknown"})
        return number

    def response(self, number, status, body):
        (self.directory / f"response-{number:03}.body").write_bytes(body)
        meta_path=self.directory / f"response-{number:03}.json"
        meta=json.loads(meta_path.read_text(encoding="utf8")) if meta_path.exists() else {}
        write(meta_path, {**meta,"status":status,"bytes":len(body)})
        if status in {401,403,402,429} or status >= 500:
            state = json.loads((self.directory / "live-state.json").read_text(encoding="utf8"))
            state["stop"] = f"HTTP {status}; auth/quota/infrastructure failure"
            write(self.directory / "live-state.json", state)
        # Ollama cloud may not enforce local generation options. Record and stop
        # observed overruns rather than claiming a hard remote cancellation cap.
        request=json.loads((self.directory / f"request-{number:03}.json").read_text(encoding="utf8"))
        if request["service"] == "ollama":
            for line in body.splitlines():
                try:
                    value=json.loads(line)
                except ValueError:
                    continue
                if value.get("eval_count",0) > self.protocol["num_predict"]:
                    state=json.loads((self.directory/"live-state.json").read_text(encoding="utf8"))
                    state["stop"]="Ollama output cap not honored"
                    write(self.directory/"live-state.json",state)

    def failed(self, number, exc):
        meta_path=self.directory / f"response-{number:03}.json"
        meta=json.loads(meta_path.read_text(encoding="utf8")) if meta_path.exists() else {}
        write(meta_path, {**meta,"error":f"{type(exc).__name__}: {exc}"})
        state = json.loads((self.directory / "live-state.json").read_text(encoding="utf8"))
        state["stop"] = "transport failure; no retry"
        write(self.directory / "live-state.json", state)


def transport(module, ledger, service):
    """Wrap actual network sends, rather than counting high-level roles."""
    class Stream(module.SyncByteStream):
        def __init__(self, original, number, status):
            self.original, self.number, self.status = original, number, status
            self.body = bytearray()
        def __iter__(self):
            try:
                for data in self.original:
                    overrun=len(self.body)+len(data) > 2_000_000
                    self.body.extend(data[:2_000_000-len(self.body)])
                    if overrun:
                        raise LimitReached("Response exceeded 2MB capture limit")
                    yield data
            except Exception as exc:
                ledger.failed(self.number, exc)
                raise
            finally:
                ledger.response(self.number,self.status,bytes(self.body))
        def close(self):
            self.original.close()
    class Transport(module.BaseTransport):
        def __init__(self):
            self.inner = module.HTTPTransport(retries=0)
        def handle_request(self, request):
            # Never log authorization headers or query strings containing keys.
            value = json.loads(request.content) if request.content else None
            number = ledger.before(service, {"path":request.url.path,"body":value})
            try:
                response = self.inner.handle_request(request)
                if response.is_stream_consumed:
                    ledger.response(number,response.status_code,response.content)
                else:
                    response.stream = Stream(response.stream,number,response.status_code)
                return response
            except Exception as exc:
                ledger.failed(number,exc)
                raise
        def close(self):
            self.inner.close()
    return Transport()


def load_keys():
    # Match existing project .env convention without displaying secret values.
    for line in Path(".env").read_text(encoding="utf8").splitlines():
        if "=" in line and not line.lstrip().startswith("#"):
            key,value = line.split("=",1)
            if key.strip() in {"TYPESAFE_API_KEY","TINYFISH_API_KEY"}:
                os.environ.setdefault(key.strip(),value.strip().strip('"').strip("'"))
    if not all(os.getenv(k) for k in ["TYPESAFE_API_KEY","TINYFISH_API_KEY"]):
        raise ValueError("Existing retrieval and Jev credentials required")


def worker(directory, task):
    import httpx
    import httpx2
    import kaji_langgraph.jev as jev_module
    import urllib.request
    from typesafe_sdk import RetryPolicy, TypeSafeClient
    from kaji_langgraph.evaluation import load_dataset, model_input, prediction_label
    from kaji_langgraph.graph import run_claim
    from kaji_langgraph.llm import OllamaBackend
    from kaji_langgraph.models import Classification
    from kaji_langgraph.retrieval import TinyFishRetriever
    protocol = json.loads((directory / "pilot-protocol.json").read_text(encoding="utf8"))
    load_keys()
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    urllib.request.install_opener(urllib.request.build_opener(NoRedirect()))
    ledger = Ledger(directory,protocol)
    ledger.task=task
    cfg = deepcopy(protocol["historical_config"])
    cfg["policy"].update(max_retries=0,retry_on_failure=False)
    cfg["policy"]["stop_on_query_exhaustion"] = task.endswith("query_exhaustion")
    backend = OllamaBackend(**{k:v for k,v in {
        "model":cfg["model"]["name"],"base_url":cfg["model"]["base_url"],
        "temperature":cfg["model"]["temperature"],"verdict_mode":"averitec"}.items()})
    from langchain_ollama import ChatOllama
    backend._model = ChatOllama(model=backend.model_name,base_url=backend.base_url,
        temperature=0,num_predict=protocol["num_predict"],validate_model_on_init=False,
        client_kwargs={"transport":transport(httpx,ledger,"ollama"),"timeout":60,"follow_redirects":False})
    def jev_client(**kwargs):
        return TypeSafeClient(**kwargs,retry=RetryPolicy(max_retries=0),
            http_client=httpx2.Client(transport=transport(httpx2,ledger,"jev"),timeout=15,follow_redirects=False))
    jev_module.TypeSafeClient = jev_client
    class Retrieval(TinyFishRetriever):
        def _request(self,url,*,payload=None,timeout):
            import urllib.error
            service = "tinyfish_fetch" if payload is not None else "tinyfish_search"
            number = ledger.before(service,{"url":url,"body":payload})
            try:
                key=self.api_key or os.environ["TINYFISH_API_KEY"]
                request=urllib.request.Request(url,
                    data=json.dumps(payload).encode() if payload is not None else None,
                    headers={"X-API-Key":key,"Accept":"application/json","Content-Type":"application/json"})
                try:
                    response=urllib.request.urlopen(request,timeout=min(60,timeout))
                except urllib.error.HTTPError as exc:
                    response=exc
                with response:
                    body=response.read(2_000_001)
                    status=response.status
                ledger.response(number,status,body[:2_000_000])
                if len(body)>2_000_000:
                    raise LimitReached("TinyFish response exceeded 2MB capture limit")
                if status != 200:
                    raise RuntimeError(f"TinyFish API returned HTTP {status}")
                value=json.loads(body)
                if not isinstance(value,dict):
                    raise ValueError("TinyFish API returned an invalid response")
                return value
            except Exception as exc:
                ledger.failed(number,exc)
                raise
    if task == "smoke":
        result,tokens = backend._structured(Classification,"Classify this claim: A library holds books.")
        write(directory / "smoke.json",{"parsed":result.model_dump(),"tokens":tokens})
        return
    claim_id = int(task.split("-")[0])
    inputs = model_input(load_dataset(Path("evaluation/results/study-20261009-v3/dataset-snapshot.json"))[claim_id])
    with (directory / f"{task}.progress.log").open("w",encoding="utf8") as log:
        def progress(message):
            log.write(message+"\n");log.flush()
        result = run_claim(**inputs,max_rounds=3,config=cfg,model=backend,
                           retriever=Retrieval(),jev=jev_module.JevClient(model=cfg["jev"]["model"]),progress=progress)
    write(directory / f"{task}.result.json",{"claim_id":claim_id,"condition":task.split("-",1)[1],
        "predicted_label":prediction_label(result.predicted_verdict),
        "accepted_label":prediction_label(result.verdict),"result":result.model_dump(mode="json")})


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--run",type=Path,required=True)
    parser.add_argument("--worker")
    parser.add_argument("--continue-unstarted",action="store_true")
    args=parser.parse_args()
    directory=args.run.resolve()
    protocol=json.loads((directory/"pilot-protocol.json").read_text(encoding="utf8"))
    receipt=directory/"LIVE_APPROVAL.json"
    if not receipt.exists() or json.loads(receipt.read_text(encoding="utf8")).get("approved_protocol") != protocol:
        raise SystemExit("No matching explicit user approval receipt; no live calls made")
    if args.worker:
        worker(directory,args.worker)
        return
    if (directory/"live-state.json").exists():
        if not args.continue_unstarted:
            raise SystemExit("Existing live ledger: inspect outcomes; never automatically rerun")
        # Manual recovery of the local UTF-8 logging failure. Never replay a
        # started task, reset a count/deadline, or continue uncertain sends.
        for request_path in directory.glob("request-*.json"):
            number=request_path.stem.split("-")[1]
            response_path=directory/f"response-{number}.json"
            body_path=directory/f"response-{number}.body"
            request=json.loads(request_path.read_text(encoding="utf8"))
            if not response_path.exists() or not body_path.exists():
                raise SystemExit("Unknown dispatched outcome: recovery refused")
            response=json.loads(response_path.read_text(encoding="utf8"))
            if response.get("error") or response.get("status") != 200:
                raise SystemExit("Service/transport failure: recovery refused")
            if not (directory/f"{request['task']}.job.json").exists():
                raise SystemExit("Started task without final job record: recovery refused")
            if request["service"] == "ollama":
                values=[json.loads(line) for line in body_path.read_bytes().splitlines()]
                if not values or not values[-1].get("done"):
                    raise SystemExit("Incomplete Ollama stream: recovery refused")
        write(directory/"recovery-unstarted.json",{"reason":"UTF-8 logging bug fixed; all dispatched responses HTTP200 and complete; skip all started tasks",
            "timestamp":datetime.now(timezone.utc).isoformat(),"deadline_reset":False,"counts_reset":False})
    else:
        write(directory/"live-state.json",{"counts":dict.fromkeys(protocol["caps"],0),
            "deadline":time.time()+protocol["max_seconds"],"stop":None})
    tasks=["smoke"]+[f"{claim}-{condition}" for claim,order in zip(protocol["claim_ids"],protocol["orders"]) for condition in order]
    for task in tasks:
        if (directory/f"{task}.job.json").exists():
            continue
        state=json.loads((directory/"live-state.json").read_text(encoding="utf8"))
        remaining=state["deadline"]-time.time()
        if state["stop"] or remaining <= 0:break
        command=[sys.executable,str(Path(__file__).resolve()),"--run",str(directory),"--worker",task]
        started=time.monotonic()
        with (directory/f"{task}.stdout.log").open("wb") as out,(directory/f"{task}.stderr.log").open("wb") as err:
            try:
                process=subprocess.run(command,stdout=out,stderr=err,
                    timeout=min(300,remaining),env={**os.environ,"OMP_NUM_THREADS":"2","MKL_NUM_THREADS":"2","OPENBLAS_NUM_THREADS":"2","PYTHONUTF8":"1"})
                record={"exit_code":process.returncode,"elapsed_seconds":time.monotonic()-started}
            except subprocess.TimeoutExpired:
                record={"exit_code":None,"elapsed_seconds":time.monotonic()-started,"timed_out":True,"remote_inflight_cancellation":"unknown"}
        write(directory/f"{task}.job.json",record)
        if record["exit_code"] != 0:break
        result_path=directory/f"{task}.result.json"
        if result_path.exists() and json.loads(result_path.read_text(encoding="utf8"))["result"]["verification_status"] == "execution_error":break


if __name__ == "__main__":
    main()
