# Claim-to-evidence map — verified offline, November 2, 2026

| ID | Manuscript statement | Primary evidence | Disposition / boundary |
|---|---|---|---|
| C1 | Full337/500 vs control269/500; paired+13.6 points,95% 8.6–18.6 | Historical full/closed_book JSONL; verified-analysis.json, paired_accuracy and mcnemar | Reproduced; combined-workflow development label difference only |
| C2 | Full gate44/500 accepted;42/44 agree with gold | Raw accepted_label fields; verified-analysis metrics.full_policy; selection-analysis.json | Reproduced;8.8% coverage,8.4% accepted-correct rate; no independent citation correctness |
| C3 | Semantic replay withholds3 correct and3 wrong from50 structurally eligible | Historical policy-replay.csv, saved study-metrics; verified equality of structural/full policies | Descriptive fixed-evidence selection; not live ablation or general reliability proof |
| C4 | First344 correct, final337;18 gains25 losses; acceptance14→44 | Historical raw per-round assessments and diagnostics; existing October21 analysis | Within-trajectory change; not causal retrieval effect or separately executed one-round experiment |
| C5 |252 no-search third rounds use4,154,865 reported tokens;2 gains1 loss,2 new acceptances | stopping-replay.csv/.json and stopping_replay.py; raw budgets, prior next_queries and usable_source_keys | Reproduced post hoc subset; stopping would lose net1 correct and2 acceptances in saved replay |
| C6 | On gate-selected44, workflow42 correct vs control30; gold33 Refuted, 9 Supported, 2 Conflicting | selection-analysis.json + script and selected IDs | Reproduced; post-treatment workflow selection, no causal gate effect |
| C7 |429 High-confidence outputs,326 correct | selection-analysis.json, high_confidence_only | Existing category selection; not calibrated confidence guarantee |
| C8 |208 final cited-host matches | Existing corrected metrics/source_host; verified-analysis.host_match_n | Reproduced exposure proxy; absence does not establish no contamination |
| C9 |2,611 citation occurrences;1,914 literal matches/reviews | Existing saved study-metrics.citations; raw records checked by reviewer | Provenance/automated judgments only;454-row human worksheet remains blank |
| C10 | Accepted errors353/404 illustrate claim-scope issues | selection-analysis.illustrative_errors contains exact saved assessments | Illustrative inspection; no completed independent human adjudication |

Gold NEI does not control gate eligibility. The acceptance design excludes NEI predictions; it can accept an incorrectly decisive prediction on any gold class. In this study no gold-NEI claim was accepted. Human citation validation, held-out generalization, LangGraph-vs-CrewAI superiority, measured hallucination reduction, deployed stopping benefit and candidate-model quality remain unsupported or unmeasured.

The fresh result-to-claim gate completed:yes for these narrow descriptive claims, medium confidence, same-family/provisional; integrity_status unavailable because no standalone integrity audit was run. Deterministic reproduction alone does not validate broader scientific claims. Historical results/code remain unchanged. Figures derive from unchanged completed metrics.
