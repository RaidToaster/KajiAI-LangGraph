"""Refresh included audit records after final logging; preserve validated PDF bytes."""
import hashlib
import json
from pathlib import Path
import zipfile

WORK = Path(__file__).resolve().parent
EVALUATION = WORK.parents[1]
archive_path = EVALUATION / "paper-source.zip"
temporary = WORK / "paper-source-refresh.zip"

with zipfile.ZipFile(archive_path) as old, zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as new:
    names = set(old.namelist())
    for name in old.namelist():
        current = EVALUATION / name
        new.writestr(name, current.read_bytes() if current.is_file() else old.read(name))
    for path in WORK.iterdir():
        if path.is_file() and path.suffix in {".md", ".json", ".csv", ".py", ".txt", ".diff", ".jsonl"}:
            name = path.relative_to(EVALUATION).as_posix()
            if name not in names:
                new.write(path, name)
with zipfile.ZipFile(temporary) as new:
    assert new.testzip() is None
    assert new.read("paper.tex") == (EVALUATION / "paper.tex").read_bytes()
    assert new.read("aris/20261102_120247/RESEARCH_STATE.md") == (WORK / "RESEARCH_STATE.md").read_bytes()
temporary.replace(archive_path)
validation_path = WORK / "paper-build-final/pdf-validation.json"
validation = json.loads(validation_path.read_text(encoding="utf8"))
assert validation["pdf_sha256"] == hashlib.sha256((EVALUATION / "paper.pdf").read_bytes()).hexdigest()
validation["source_zip_sha256"] = hashlib.sha256(archive_path.read_bytes()).hexdigest()
validation["audit_package_refresh"] = "Final records refreshed; ZIP CRC and exact packaged source/state checked. PDF unchanged."
validation_path.write_text(json.dumps(validation, indent=2), encoding="utf8")
print("PASS: final package matches current source/audit records; validated PDF unchanged")
