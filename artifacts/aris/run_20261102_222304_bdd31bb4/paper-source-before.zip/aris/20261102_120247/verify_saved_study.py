"""Read-only verification of the completed study; write only this run's outputs."""
from collections import Counter
import csv
import json
import math
from pathlib import Path
import zipfile

from kaji_langgraph.evaluation import ABSTAIN, LABELS, load_dataset
from kaji_langgraph.study_analysis import paired_accuracy, read_rows, replay_labels, scored, source_host

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
STUDY = ROOT / "evaluation/results/study-20261009-v3"


def main():
    manifest = json.loads((STUDY / "manifest.json").read_text())
    saved = json.loads((STUDY / "study-metrics.json").read_text())
    full, control = [sorted(read_rows(STUDY / c / "results.jsonl"), key=lambda r: r["claim_id"]) for c in ("full", "closed_book")]
    data = load_dataset(STUDY / "dataset-snapshot.json")
    expected = set(manifest["claim_ids"])
    for rows in (full, control):
        assert len(rows) == len(expected) == 500
        assert {r["claim_id"] for r in rows} == expected
        assert all(r["gold_label"] == data[r["claim_id"]]["label"] for r in rows)
        assert all(r["result"]["claim"] == data[r["claim_id"]]["claim"] for r in rows)
    assert all(f["claim_id"] == c["claim_id"] and f["gold_label"] == c["gold_label"] for f, c in zip(full, control))
    gold = [r["gold_label"] for r in full]
    policies = [replay_labels(r, manifest["config"]) for r in full]
    values = {"full_predictions": [r["predicted_label"] for r in full], "closed_book_predictions": [r["predicted_label"] for r in control]}
    values.update({name: [p[name] for p in policies] for name in policies[0]})
    values["majority_baseline"] = [Counter(gold).most_common(1)[0][0]] * len(gold)
    verified = {}
    for name, predictions in values.items():
        verified[name] = scored(gold, predictions)
        assert verified[name] == saved["metrics"][name], name
    assert values["semantic_threshold_0.80"] == [r["accepted_label"] for r in full]
    paired = paired_accuracy(gold, values["closed_book_predictions"], values["full_predictions"])
    assert paired == saved["paired_accuracy_comparisons"]["full_minus_closed_book"]
    discordant = Counter((f["predicted_label"] == f["gold_label"], c["predicted_label"] == c["gold_label"]) for f, c in zip(full, control))
    a, b = discordant[(True, False)], discordant[(False, True)]
    p_value = min(1, 2 * sum(math.comb(a+b, k) for k in range(min(a,b)+1)) / 2**(a+b))
    class_rows = []
    for label in LABELS:
        ids = [i for i, y in enumerate(gold) if y == label]
        accepted = [i for i in ids if full[i]["accepted_label"] != ABSTAIN]
        class_rows.append({"gold_class": label, "n": len(ids), "full_correct": sum(values["full_predictions"][i] == label for i in ids), "control_correct": sum(values["closed_book_predictions"][i] == label for i in ids), "accepted": len(accepted), "accepted_correct": sum(full[i]["accepted_label"] == label for i in accepted)})
    host_groups = {True: [], False: []}
    for i, row in enumerate(full):
        h = row["result"]["research_history"]
        urls = [u for e in h[-1]["assessment"]["evidence"] for u in e["source_urls"]] if h else []
        host = source_host(data[row["claim_id"]].get("fact_checking_article", ""))
        host_groups[bool(host and any(source_host(u) == host for u in urls))].append(i)
    assert len(host_groups[True]) == saved["same_host_as_gold_fact_check_cited"]
    archive = zipfile.ZipFile(STUDY / "source-snapshot.zip")
    changed = [name for name in archive.namelist() if (ROOT/name).read_bytes() != archive.read(name)]
    output = {"scope": "Offline verification and post hoc class-stratified analysis; historical inference untouched", "authoritative_study": str(STUDY.relative_to(ROOT)), "n": len(full), "metric_equalities": list(verified), "metrics": verified, "paired_accuracy": paired, "mcnemar": {"workflow_only_correct": a, "control_only_correct": b, "p_exact_two_sided": p_value}, "gold_class_breakdown": class_rows, "host_match_n": len(host_groups[True]), "execution_errors": {name: [r["claim_id"] for r in rows if r["result"]["verification_status"] == "execution_error"] for name, rows in [("full", full), ("closed_book", control)]}, "working_files_different_from_archive": changed, "human_annotation_fields_blank": None}
    human = list(csv.DictReader((STUDY/"human-citation-audit.csv").open(encoding="utf-8-sig")))
    output["human_annotation_fields_blank"] = all(not r[k] for r in human for k in ("human_supports_finding", "human_source_credibility", "human_notes"))
    assert output["human_annotation_fields_blank"]
    (WORK/"verified-analysis.json").write_text(json.dumps(output, indent=2), encoding="utf8")
    with (WORK/"class-breakdown.csv").open("w", newline="", encoding="utf8") as f:
        writer = csv.DictWriter(f, fieldnames=list(class_rows[0])); writer.writeheader(); writer.writerows(class_rows)
    print(json.dumps({k: output[k] for k in ("n", "metric_equalities", "paired_accuracy", "mcnemar", "gold_class_breakdown", "execution_errors", "working_files_different_from_archive", "human_annotation_fields_blank")}, indent=2))


if __name__ == "__main__":
    main()
