# Research audit — November 2, 2026

Run: run_20261102_f991201b. Native Codex review, same-family/provisional. Initial score: 5/10, not ready. This audit supports an empirical workflow case study; it does not certify submission readiness.

## Authoritative completed study

`evaluation/results/study-20261009-v3` contains 500 unique full-workflow and 500 matching model-only attempts, completed 2026-10-10T06:31:25.613125Z. Its manifest dataset/source digests, source archive, raw records, completion state, incident report and analysis-correction record agree. Earlier preflight, study and v2 directories are separate/interrupted conditions and were not pooled. The current inference files match the frozen archive; only study_analysis.py carries the previously documented archive-aware hostname correction. The original metrics/report and source archive remain unchanged. October21 diagnostics are post hoc saved-trajectory analysis.

The starting Git tree was clean at 2693216; baseline/starting-state.zip preserves the manuscript, PDF, implementation, configuration, tests, scripts and study metadata. No credentials were included. The full raw inference remains in its original location and matches the existing recorded provenance. No historical inference was rerun.

## Priority and disposition

| Finding | Importance / effort | Offline disposition | Remaining evidence |
|---|---|---|---|
| R1 independent citation support unmeasured | High / human annotation | Retain limitation; inspect IDs 353/404 illustratively | Independent support/credibility/claim-scope labels, two annotators and adjudication |
| R2 combined-workflow effect and development reuse | High / new controlled evidence | RQs/contribution narrowed; matched44 and class breakdown reported | Declared mechanism comparison and held-out evaluation if warranted |
| R3 empty-query repeated assessment | Medium / cheap diagnosis, live evaluation later | Fixed-trace replay; no runtime policy change | Prospective quality/resource comparison before claiming savings |
| R4 prose regeneration clobbers working drafts | Medium / cheap | Both generators import-safe, separate default destinations | Regression passes; historical generated output byte-identical |
| R5 stale diagnostic status | Medium / cheap | Historical text preserved with current-status boundaries | None for corrected status |
| R6 pytest temp setup | Low / cheap | Explicit workspace --basetemp;63 tests pass | Fresh invocation check assigned at final artifact boundary |

## Verified results

| Output | N | Correct | Accuracy | Macro F1 |
|---|---:|---:|---:|---:|
| Full prediction |500|337|67.4%|0.500|
| Model-only prediction |500|269|53.8%|0.417|
| First saved round |500|344|68.8%|0.530|
| Full gate accepted |44|42|95.5% conditional|Not comparable to four-class full coverage|

Coverage is 44/500=8.8%; end-to-end accepted-correct rate is 42/500=8.4%. Twenty-one saved metric sets, the seeded paired bootstrap and exact McNemar calculation reproduce. Full-minus-control is 13.6 points (paired 95% interval8.6–18.6), with 117 workflow-only correct and 49 control-only correct; p=1.345315555092414e-7. The relative accuracy increase is 25.28% of the control's 53.8%; percentage-point change is the clearer primary comparison. Thirteen failures remain in the denominator. No repeated seeds or service-drift uncertainty were measured.

The gate-selected gold composition is 33 Refuted, 9 Supported, 2 Conflicting; its predicted composition is 35 Refuted, 9 Supported. On the same 44 IDs, control correctness is 30/44 and the workflow 42/44. This subset is selected by workflow outputs. High-confidence-only selection retains 429 outputs with 326 correct (76.0%). These descriptive selections do not isolate a gate effect or prove citation validity. NEI predictions are excluded from acceptance by design; gold labels are not inputs to the gate.

For gold classes Supported/Refuted/NEI/Conflicting, workflow correctness is 80/122,232/305,6/35,19/38; control correctness is 74/122,172/305,14/35,9/38. Preserve the NEI regression and class imbalance.

First-to-final raw correctness falls 344→337 while accepted outputs rise 14→44 and accepted-correct outputs 14→42. Among 252 third rounds with no new searches, unchanged usable-source versions and empty prior model queries, later assessment consumes 4,154,865 observed tokens, produces 2 label gains and 1 loss, and 2 new acceptances. Stopping before those calls is a candidate condition, not a proven improvement. No runtime model, gate, threshold, prompt or stopping rule changed.

The 454-row human worksheet remains blank. Accepted errors353/404 are illustrative saved cases, not independent annotations. Contemporary host matching 208/500 remains an exposure proxy; unmatched claims are not established contamination-free. Literal quote matches are provenance, not truth or entailment. Policy replay is fixed-evidence analysis, not executed Jev-disabled/retrieval-only ablation.

## Reproduce the offline checks

From the project root, use the existing .venv; no package installation is required. Each command records stdout/stderr, exit code, timing and a 300-second subprocess deadline, with two numerical threads. The session allowance is 900 seconds. Use fresh job names and fresh pytest base directories for another run.

```powershell
.venv/Scripts/python.exe evaluation/aris/20261102_120247/run_job.py verify-saved-study .venv/Scripts/python.exe evaluation/aris/20261102_120247/verify_saved_study.py
.venv/Scripts/python.exe evaluation/aris/20261102_120247/run_job.py stopping-replay-verified .venv/Scripts/python.exe evaluation/aris/20261102_120247/stopping_replay.py
.venv/Scripts/python.exe evaluation/aris/20261102_120247/run_job.py selection-analysis-job .venv/Scripts/python.exe evaluation/aris/20261102_120247/selection_analysis.py
.venv/Scripts/python.exe evaluation/aris/20261102_120247/run_job.py both-generators-regression .venv/Scripts/python.exe evaluation/aris/20261102_120247/check_generation.py
.venv/Scripts/python.exe evaluation/aris/20261102_120247/run_job.py workspace-tests .venv/Scripts/python.exe -m pytest --basetemp evaluation/aris/20261102_120247/pytest-baseline
```

These are exact recorded commands; reusing their names intentionally refuses overwrite. Change only the new job name/temp directory when repeating. Analysis outputs: verified-analysis.json,class-breakdown.csv,stopping-replay.json/.csv,selection-analysis.json. See jobs.jsonl for commands and timing. Historical final_analysis.py/study_analysis.py are not rerun against their original output directory, because they overwrite metrics and annotation worksheets.

## Compact action plan

Completed offline work: preserve baseline; verify source/data/paired metrics; protect generation; update status; clarify claims and selection/iteration diagnostics. Completed: second research review (5/10 not ready), two writing reviews (7→9), claim gate (yes/medium for narrow description), final compilation and all-page visual inspection. Prioritize independent human annotation next. Full new inference is no-go; no live calls without a separately approved bounded budget.
