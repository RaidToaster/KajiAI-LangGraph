# Experiment tracker — November 2, 2026

| Run / check | Status | Result / artifacts |
|---|---|---|
| Historical authoritative v3 | Completed; independently verified |500 full +500 control;13 failures retained; no rerun |
| Earlier preflight/study/v2 and pilots | Preserved separately | Not pooled into authoritative study |
| Baseline tests, default temp | Failed setup |58 passed,5 tmp_path errors; baseline-tests logs retained |
| Workspace temp tests | Completed | 63 passed; workspace-tests stdout |
| Fresh documented invocation | Completed | 63 passed; documented-tests stdout; fresh paper-reviewer ran verbatim |
| Saved metric and provenance audit | Completed |21 metric equalities; paired bootstrap and exact McNemar reproduce; verified-analysis.json |
| Selection analysis | Completed, exploratory | Same44:42 vs30 correct; selection-analysis.json |
| No-query saved-trajectory replay | Completed, exploratory |252 rounds; mixed outcomes; stopping-replay.json/.csv |
| Generator regression | Completed | Both imports/default-safe functions preserve prose; byte-identical historical outputs |
| Early generator wrapping attempts | Failed; corrected | Whitespace equality failures retained in logs; no manuscript loss |
| First stopping report | Instrumentation collision; recovered | JSON job metadata collision corrected with .job.json; affected analysis regenerated; raw CSV/stdout retained |
| Ollama endpoint discovery | Unavailable | Metadata-only requests refused;0 generation calls |
| Research revision compile | Completed after cache/network retry | Tectonic0.17;6 pages; original build failure retained |
| New live smoke / paired pilot | Not authorized or executed | Proposal only in FULL_EXPERIMENT_READINESS.md |
| Full new study / historical rerun | NO GO, not authorized | No justified frozen/authorized protocol; human evidence validation prioritized |

All new analysis uses CPU, two numerical threads and one experiment process. jobs.jsonl is authoritative for commands, exit status and observed elapsed time. Paper/claim reviews and visual checks are tracked separately. No jobs remain running after handoff unless explicitly recorded.

Final artifact checks:final generator import/default regression passed; final Tectonic build6pages/no overfull; all6 final pages visually inspected. No experiment processes remain running. Final package validation recorded separately.

Final package validation:completed, exit0;6pages,embedded fonts,4tables,2figures,11references,zero unresolved citations/overfull boxes. Relative-audit-path failure and successful correction retained in jobs ledger.
