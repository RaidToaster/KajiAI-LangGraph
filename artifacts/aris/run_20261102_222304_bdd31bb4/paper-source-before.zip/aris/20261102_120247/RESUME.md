# Resume summary

The authorized offline work is complete. Read RESEARCH_STATE.md, DECISION_LOG.md, CLAIM_EVIDENCE.md and review-stage/REVIEW_STATE.json first. Current paper:evaluation/paper.tex and evaluation/paper.pdf. Baseline:baseline/starting-state.zip, paper.tex, paper.pdf and paper-source.zip. Original inference remains evaluation/results/study-20261009-v3 and matches its existing provenance.

Research verdict5→5 not ready; writing7→9 ready for author review; narrow claim gate yes/medium. All same-family/provisional.63 tests pass,21 saved metric sets reproduce. New live inference calls0. No automatic experiment continuation is authorized.

Exact next action:obtain two independent human annotations of the existing454-row blinded citation worksheet, following evaluation/results/study-20261009-v3/human-audit-instructions.md, retaining annotator disagreement and adjudication. Hide human-audit-key.json from annotators. Do not insert model judgments as human labels. Confirm annotation time/budget with the humans involved; no messages were sent to them.

If later considering model alternatives, inspect MODEL_INTEGRATION.md and the proposed bounded smoke in FULL_EXPERIMENT_READINESS.md. Local Ollama endpoint was refused; model identifiers/capabilities were not confirmed locally. No new subscriptions, weights or billing. A pilot/full run needs the explicit staged authorizations in the original USER_BRIEF.txt.

Important files are local; evaluation/ is gitignored. Do not commit/push without instruction. MANIFEST.md indexes generated outputs; scripts and exact commands/timings are in this run. Do not regenerate paper.tex from the historical template:the fixed generator defaults to paper-regenerated.tex. A future study must use a new output directory.
