# Resource usage — observed through research revision

New live inference requests: **0**. Endpoint metadata requests:4 total (2 sandbox-denied,2 unsandboxed connection-refused). No new model downloads, billing, keys, service launches or subscriptions.

Bounded job ledger: 13 entries, 30.971 observed seconds, including failed attempts and TeX compilation. Additional initial-reviewer read-only subprocesses:4.244s beyond its baseline test (already in ledger). Known total so far:35.215s against900s conservative allowance; max300s/job, two numerical threads, one experiment process. Renderer/metadata/tool wall times not uniformly instrumented; unknown rather than estimated as zero.

Fresh research reviewer calls:2 rounds requested (second pending completion at this update). Final writing reviewer:round1 requested. Claim gate:pending. Requested native models/efforts are recorded in traces; independently reported actual model/effort unknown. Exact tokens and dollar cost of native Codex reviews are unknown. No cross-family assurance claimed.

Historical34,452,832 workflow and183,416 control tokens are saved provider-reported totals, with incomplete provider accounting. They are not this session's usage. The4,154,865 no-query-round tokens describe historical observations and are not guaranteed prospective savings. Historical hosted revisions and exact monetary cost cannot be reconstructed.

Tooling:existing project Python3.12.4 and dependencies reused unchanged; bundled PDF runtime reused; Tectonic0.17.0+20260731 reused with normal TeX cache/network access after sandbox cache failure. No global/project Python package installations. Remaining final compilation/review timings will be appended at handoff.

Final recorded pre-package ledger:16 jobs, 35.519s elapsed plus4.268s separate research-review subprocesses. Final packaging duration is in its job record when complete. Renderer/metadata/model-review time and exact tokens/cost remain incompletely measured. Research2 rounds; writing2 completed rounds plus1 failed interrupted call; fresh claim gate1. No fresh reviewer calls are planned. User requested token conservation at continuation; reviewers returned compact responses and unchanged analyses were reused.

Final measured bounded-job total including validation:41.991s (18 ledger jobs plus4.268s separate reviewer checks); below900s. Packaging first failed on relative/absolute audit path normalization; fixed and rerun succeeded in1.000s. Exact final native-review token counts/cost remain unknown.
