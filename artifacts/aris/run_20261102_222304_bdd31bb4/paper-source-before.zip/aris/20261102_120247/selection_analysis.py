"""Descriptive selection comparisons on frozen outputs, with matched claim IDs."""
from collections import Counter
import json
from pathlib import Path

from kaji_langgraph.evaluation import ABSTAIN
from kaji_langgraph.study_analysis import read_rows, scored

WORK = Path(__file__).resolve().parent
STUDY = WORK.parents[2] / "evaluation/results/study-20261009-v3"


def main():
    full = read_rows(STUDY/"full/results.jsonl")
    control = {r["claim_id"]: r for r in read_rows(STUDY/"closed_book/results.jsonl")}
    selected = [r for r in full if r["accepted_label"] != ABSTAIN]
    gold = [r["gold_label"] for r in selected]
    high = [r for r in full if r["result"]["research_history"] and r["result"]["research_history"][-1]["assessment"]["confidence"] == "High"]
    examples = [{"claim_id": r["claim_id"], "gold_label": r["gold_label"], "predicted_label": r["predicted_label"], "accepted_label": r["accepted_label"], "claim": r["result"]["claim"], "final_assessment": r["result"]["research_history"][-1]["assessment"]} for r in selected if r["predicted_label"] != r["gold_label"]]
    output = {"scope": "Post hoc descriptive selection audit, not a causal gate comparison or held-out estimate", "selected_ids": sorted(r["claim_id"] for r in selected), "selected_gold_distribution": dict(Counter(gold)), "selected_prediction_distribution": dict(Counter(r["predicted_label"] for r in selected)), "selected_full": scored(gold, [r["predicted_label"] for r in selected]), "selected_control": scored(gold, [control[r["claim_id"]]["predicted_label"] for r in selected]), "selected_always_refuted": scored(gold, ["Refuted"]*len(gold)), "high_confidence_only": scored([r["gold_label"] for r in high], [r["predicted_label"] for r in high]), "high_confidence_n": len(high), "illustrative_errors": examples, "human_validation_performed": False}
    (WORK/"selection-analysis.json").write_text(json.dumps(output, indent=2),encoding="utf8")
    print(json.dumps({"n": len(selected), "full_correct": round(output["selected_full"]["accuracy"]*len(selected)), "control_correct": round(output["selected_control"]["accuracy"]*len(selected)), "gold_distribution": output["selected_gold_distribution"], "high_confidence_n": len(high), "high_confidence_correct": round(output["high_confidence_only"]["accuracy"]*len(high)), "illustrative_error_ids": [r["claim_id"] for r in examples]},indent=2))


if __name__ == "__main__":
    main()
