# Ollama integration inspection

No new model inference was run. Existing study model: gemma4:31b-cloud, localhost:11434, temperature 0, AVeriTeC mode. Main adapter uses LangChain JSON mode, permissive JSON extraction and one schema-format repair. It does not invoke model tools; source ranking and citation review are separate Jev roles. Thinking controls are not explicitly configured. Classification/schema/repair/failure tests run offline.

Read-only GET /api/version and /api/tags first failed under sandbox socket restrictions; a permitted unsandboxed metadata-only attempt returned connection-refused for both. Records:ollama-discovery.json and ollama-discovery-unsandboxed.json. No service was started and no credentials were read or changed.

Public model cards confirm local tags and different direct-cloud identifiers: [DeepSeek](https://ollama.com/library/deepseek-v4.1-flash), [GLM](https://ollama.com/library/glm-5.3-flash). Local tags have :cloud; documented direct-cloud request names omit it. Endpoint acceptance/authentication, thinking defaults and actual capabilities remain unverified. Never silently substitute one form.

[Ollama structured-output documentation](https://docs.ollama.com/capabilities/structured-outputs) currently says cloud structured outputs are unsupported. Historical saved success with the existing adapter does not establish compatibility for either candidate. Prompted JSON validity, schema adherence and repair behavior need explicit smoke evidence. [Thinking documentation](https://docs.ollama.com/capabilities/thinking) recommends /api/show for model-specific values and defaults; no assumption that both candidates support the same switch is justified. Candidate cards advertise cloud, thinking and tools, but no local capability or integration check has completed. Context advertised is 1M; the project's 20,000-character source truncation is not a measured context-capacity check.

Available model digests/revisions and response metadata must be recorded in any future authorized pilot. Hosted tags do not promise immutable behavior. No separate DeepSeek/Z.ai access, paid service, weight download, plugin or global dependency was introduced. These candidates are runtime inference alternatives, not the native Codex reviewer used in this session. No cross-family review is claimed.

Discovery documentation checked 2026-11-02. Full-experiment readiness remains no-go; the proposed bounded smoke is in FULL_EXPERIMENT_READINESS.md.
