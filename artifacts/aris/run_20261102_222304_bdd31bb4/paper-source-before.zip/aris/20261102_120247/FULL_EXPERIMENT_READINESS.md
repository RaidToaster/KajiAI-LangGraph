# Full-experiment readiness — NO GO

Decision date: 2026-11-02. No full new experiment is authorized or launched. The existing completed study is sufficient for its bounded descriptive claims and must not be rerun without explicit scientific need and approval.

## Candidate scientific question

Does explicitly stopping when query construction is exhausted improve resource use while retaining an acceptable prediction-and-evidence outcome compared with repeated assessment? Existing traces show a real tradeoff, including 2 label gains, 1 loss and 2 new acceptances among 252 no-search third rounds. Therefore a zero-quality-cost saving is already contradicted by the simplest saved truncation. New runtime behavior has not been implemented or evaluated.

## Readiness evidence

| Requirement | Current state |
|---|---|
| Clear question and nonredundant value | Stopping tradeoff is informative; availability of a model alone is insufficient motivation |
| Relevant offline checks | 63 project tests pass; saved metric equality and generator regressions pass |
| Live integration smoke | Not run; localhost11434 refused metadata requests |
| Controlled pilot | Not run; no live budget authorized |
| Independent evidence quality | Human worksheet blank; unresolved |
| Frozen candidate protocol | Proposal below only; not frozen/confirmatory |
| Sample size justification | No confirmatory size justified from current evidence; must specify acceptable loss/cost outcomes first |
| Calls/runtime/quota | Historical observed tokens incomplete; model-specific pilot observations unavailable |
| Recovery/logging/stop checks | Historical boundaries inspected; revised runtime/pilot not tested |
| Authorization | None for new live pilots or full studies |

## Proposed staged continuation

1. First complete independent human citation support/credibility annotation for existing accepted/rejected strata; retain separate judgments, adjudication and denominators. This adds evidence without repeating inference.
2. If model substitution remains useful, authorize only an integration smoke first: existing gemma4:31b-cloud plus deepseek-v4.1-flash:cloud and glm-5.3-flash:cloud; two synthetic structured-output tasks per model, at most 6 logical requests and one repair each (12 actual requests maximum), sequential, at most 60s/request and 10 min total scheduling time, output target 256 tokens/request. No TinyFish/TypeSafe calls, no real private claims, no weights downloaded, no billing changes. This is a proposed budget, not an authorization or guaranteed token-spend cap. Verify tags/capabilities with the actual endpoint before generation; stop on first auth/quota/infrastructure error and do not substitute models. The present adapter does not expose a hard per-response token budget, so that output constraint and actual underlying-call accounting must be implemented and tested before starting.
3. Only after successful smoke, specify a paired development pilot for one factor at a time. A candidate 12-claim sample would be 3 per gold class selected with a declared seed from the reused development split, no quality-based selection, with the unchanged baseline and only one candidate condition. Include all attempts/failures, prediction accuracy, acceptance coverage, blinded citation support, validity, latency and observed usage. Treat the sample as exploratory, not a power-supported generalization estimate. Do not combine runtime-model changes and a stopping-policy change in the same comparison.
4. Decide whether a larger study adds enough information, using a fixed protocol, independent evidence labels, a justified sample size and measured call/quota estimates. Obtain explicit approval before launching it. No held-out labels should be inspected to tune this design.

Recommendation: stop at the completed offline audit and paper revision; prioritize human evidence validation. A future pilot may demonstrate feasibility regardless of whether it improves accuracy. Reframe, reduce scope or stop if its question is already answered. No promised full-study improvement or exact monetary estimate is supported.
