# Tooling and environment — final

Existing project .venv Python3.12.4 and exact packages are recorded in environment.json and .aris/env-spec.json. No environment rebuild or Python dependency change. OMP/MKL/OPENBLAS_NUM_THREADS=2; one experiment process;300s/job and900s aggregate scheduling allowance. Seeded CPU witness recorded. Fresh documented invocation passed63 tests; initial sandbox-temp setup failure retained separately.

PDF work reused bundled primary-runtime Python with pypdf/pypdfium2. Tectonic0.17.0+20260731 used existing native executable and normal TeX cache. Initial sandbox build lacked cache/network; approved cache/network execution succeeded. Final build6 pages, no overfull boxes; underfull/font-fallback warnings retained in compilation log. Final fonts/references/package checks use validate_paper.py with explicit current build and audit directories. No TeX Live or speculative tooling installation.

Minimal code changes:update_paper_results.py and write_paper_notes.py are import-safe and default to separate historical-regenerated outputs; explicit --output remains available. validate_paper.py accepts the current build directory and audit files for source packaging. Final default/import regression preserves revised authored files and reproduces historical content exactly. Historical inference code/config remain unchanged.

Ollama metadata discovery only:socket-denied in sandbox, connection-refused outside. No generation, service launch, credentials, weights, billing or new external model service. Public official documentation and existing adapter code were inspected; runtime candidate compatibility remains unverified. Reviews use native Codex; requested identities/efforts and independently unknown observed identities are separated in traces.
