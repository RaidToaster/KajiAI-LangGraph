# Change log

2026-11-02: Preserved manuscript, scripts, runtime source, configuration, tests and Git state before edits. No inference changes.

Offline revision: protected update_paper_results.py and write_paper_notes.py import/default destinations; baseline-equivalent outputs verified. README/evaluation README and historical diagnostic header identify authoritative study. Manuscript RQs, contribution, accepted subset/error cases and iteration interpretation revised; source values/historical runtime unchanged. New verified-analysis, class-breakdown, selection-analysis and stopping-replay outputs. No package/config/model changes.

Final:two writing rounds complete,7→9; independent claim gateyes/medium for narrow description. Six-page PDF visually checked; final package validation passed. Validator audit directory normalization corrected from observed failure. Native research score5→5 not ready; no live usage.

Observed a separate .gitignore addition for .aris during the session interruption; preserved it without editing. evaluation/ was already ignored at baseline. Final source package refreshed to include current records, with CRC/content verification; original source package remains in baseline/.
