"""Regression check: historical generation cannot silently replace revised prose."""
import importlib.util
from pathlib import Path

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
manuscript = ROOT / "evaluation/paper.tex"
before = manuscript.read_bytes()
candidate = ROOT / "evaluation/paper-regenerated.tex"
candidate_before = candidate.read_bytes() if candidate.exists() else None
spec = importlib.util.spec_from_file_location("paper_generation", ROOT / "evaluation/update_paper_results.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert manuscript.read_bytes() == before
assert (candidate.read_bytes() if candidate.exists() else None) == candidate_before
output = WORK / "historical-regenerated.tex"
module.generate(output)
assert output.read_bytes() == (WORK / "baseline/paper.tex").read_bytes()
assert manuscript.read_bytes() == before
print("PASS: import is read-only; generated draft matches baseline; working prose preserved")

notes = ROOT / "evaluation/paper-notes.md"
notes_before = notes.read_bytes()
spec = importlib.util.spec_from_file_location("notes_generation", ROOT / "evaluation/write_paper_notes.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert notes.read_bytes() == notes_before
output = WORK / "historical-notes-regenerated.md"
module.generate(output)
import zipfile
baseline = zipfile.ZipFile(WORK / "baseline/starting-state.zip").read("evaluation/paper-notes.md")
assert output.read_bytes() == baseline
assert notes.read_bytes() == notes_before
print("PASS: notes import and generation preserve authored notes and reproduce historical output")

# Check the documented CLI defaults against the revised authored files too.
import subprocess
import sys
for script in ("update_paper_results.py", "write_paper_notes.py"):
    subprocess.run([sys.executable, str(ROOT / "evaluation" / script)],
                   cwd=ROOT, check=True, timeout=30)
assert manuscript.read_bytes() == before
assert notes.read_bytes() == notes_before
assert candidate.read_bytes() == (WORK / "baseline/paper.tex").read_bytes()
assert (ROOT / "evaluation/paper-notes-regenerated.md").read_bytes() == baseline
print("PASS: both default CLI invocations preserve the revised manuscript and notes")
