"""Prespecified post hoc query-exhaustion replay; no inference or historical writes."""
from collections import Counter
import csv
import json
from pathlib import Path

from kaji_langgraph.evaluation import ABSTAIN, prediction_label
from kaji_langgraph.study_analysis import read_rows, scored

WORK = Path(__file__).resolve().parent
STUDY = WORK.parents[2] / "evaluation/results/study-20261009-v3"


def accepted(trace):
    return prediction_label(trace["assessment"]["proposed_verdict"]) if not trace["gaps"] and not trace["fatal_error"] else ABSTAIN


def main():
    selected = []
    counts = Counter()
    for row in read_rows(STUDY / "full/results.jsonl"):
        history = row["result"]["research_history"]
        for previous, current in zip(history, history[1:]):
            if current["round_number"] != 3 or current["budget"]["search_calls"] != previous["budget"]["search_calls"]:
                continue
            assert not previous["assessment"]["next_queries"]
            assert set(map(tuple, previous["usable_source_keys"])) == set(map(tuple, current["usable_source_keys"]))
            before = prediction_label(previous["assessment"]["proposed_verdict"])
            after = row["predicted_label"]
            a_before, a_after = accepted(previous), row["accepted_label"]
            selected.append({"claim_id": row["claim_id"], "gold": row["gold_label"], "before": before, "after": after, "accepted_before": a_before, "accepted_after": a_after, "observed_token_delta": current["budget"]["tokens_used"]-previous["budget"]["tokens_used"], "fatal_final": row["result"]["verification_status"] == "execution_error"})
            counts["wrong_to_correct"] += int(before != row["gold_label"] and after == row["gold_label"])
            counts["correct_to_wrong"] += int(before == row["gold_label"] and after != row["gold_label"])
            counts["newly_accepted"] += int(a_before == ABSTAIN and a_after != ABSTAIN)
            counts["lost_acceptance"] += int(a_before != ABSTAIN and a_after == ABSTAIN)
    gold = [r["gold"] for r in selected]
    output = {"scope": "Post hoc fixed-trajectory truncation for query-exhausted third rounds; not an executed stopping ablation", "selection": "round_number=3 and no additional search calls; verified empty prior next_queries and unchanged usable-source keys", "n": len(selected), "before": scored(gold, [r["before"] for r in selected]), "after": scored(gold, [r["after"] for r in selected]), "accepted_before": scored(gold, [r["accepted_before"] for r in selected]), "accepted_after": scored(gold, [r["accepted_after"] for r in selected]), "transitions": dict(counts), "observed_token_delta": sum(r["observed_token_delta"] for r in selected), "fatal_final_n": sum(r["fatal_final"] for r in selected), "caveats": ["Claim selection uses observed workflow behavior, so this is a post-treatment subset.", "Provider token totals are incomplete and are not a monetary saving guarantee.", "Saved later model assessments can change with identical evidence; stopping may lose useful reassessment.", "Pending source reviews cannot be reconstructed solely from final review flags.", "No policy threshold or runtime model was changed."]}
    (WORK/"stopping-replay.json").write_text(json.dumps(output, indent=2), encoding="utf8")
    with (WORK/"stopping-replay.csv").open("w", newline="", encoding="utf8") as f:
        writer=csv.DictWriter(f, fieldnames=list(selected[0]));writer.writeheader();writer.writerows(selected)
    print(json.dumps({k: output[k] for k in ["scope", "n", "transitions", "observed_token_delta", "fatal_final_n"]}, indent=2))


if __name__ == "__main__":
    main()
