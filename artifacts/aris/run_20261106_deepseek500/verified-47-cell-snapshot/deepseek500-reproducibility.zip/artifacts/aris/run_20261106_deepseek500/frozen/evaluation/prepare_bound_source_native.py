"""New source-bound choice interface, never a retry of global-ID origin output."""
from pathlib import Path
from flash_study import read,save
import prepare_evidence_adjudicated_native as previous

ROOT=Path('artifacts/bound-source-native-20261106')
OLD=Path('artifacts/evidence-adjudicated-native-20261105')


def main():
    assert read(OLD/'readiness-decision.json')['closed']
    previous.ROOT=ROOT
    previous.main()
    save(ROOT/'prior-accounting.json',read(OLD/'continuation-accounting.json'))
    entry=read(ROOT/'review-disposition.json')
    entry.update(bound_source_anchors=True,
        additional_helpers=['evaluation/run_bound_source_native.ps1',
            'evaluation/prepare_bound_source_native.py','evaluation/prepare_evidence_adjudicated_native.py',
            'evaluation/prepare_path_adjudicated_native.py',(ROOT/'prior-accounting.json').as_posix(),
            'src/kaji_langgraph/config/default.yaml','pyproject.toml','uv.lock'],
        mechanism='Typed per-source anchor choices combined with early evidence-path review in one Jev call; language path model cannot emit origin/action IDs. Semantic field ownership remains explicit, raw confidence/choices retained, no response repair.')
    save(ROOT/'review-disposition.json',entry)
    print('New source-bound packet prepared; same4Flash8Jev/zero retrieval, no live calls.')


if __name__=='__main__':main()
