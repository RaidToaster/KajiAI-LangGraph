"""Prospective two-head claim/path diagnostic; offline preparation only."""
from pathlib import Path
from flash_study import read,save

ROOT=Path('artifacts/path-adjudicated-native-20261105')
OLD=Path('artifacts/path-feedback-native-20261105')


def main():
    assert not (ROOT/'protocol.json').exists()
    ROOT.mkdir(exist_ok=True)
    assert read(OLD/'readiness-decision.json')['closed']
    for name in ('diagnostic-authority.json','current-headroom-approval.json','session-boundary.json'):
        save(ROOT/name,read(OLD/name))
    save(ROOT/'prior-accounting.json',read(OLD/'continuation-accounting.json'))
    save(ROOT/'user-scope-choice.json',read(OLD/'user-scope-choice.json'))
    entry=read(OLD/'review-disposition.json')
    entry.update(assessment_mode='path_adjudicated',
        caps_by_kind={'anchor':{'ollama':2,'jev':3}},
        planned_max_sends={'ollama':4,'jev':6,'search':0,'fetch':0},
        requested_output_token_cap_total=24576,
        review_report=(ROOT/'REVIEW.md').as_posix(),
        prior_accounting=(ROOT/'prior-accounting.json').as_posix(),
        additional_helpers=['evaluation/run_path_adjudicated_native.ps1',
            'evaluation/prepare_path_adjudicated_native.py',
            (ROOT/'prior-accounting.json').as_posix(),
            'src/kaji_langgraph/config/default.yaml','pyproject.toml','uv.lock'],
        mechanism='Separate claim and explicit evidentiary-path heads; source head is blind to first verdict/confidence, with complete source-pair classification and consistency validation. All raw issues retained; no client judgment override.',
        postreview_delta=None)
    save(ROOT/'review-disposition.json',entry)
    save(ROOT/'request-estimates.json',dict(max_sends=entry['planned_max_sends'],
        max_requested_output_tokens=24576,estimated_input_tokens_per_flash=10000,
        monetary_scheduling_caps_usd={'ollama':3,'jev':.30},zero_retrieval=True,
        existing_credits_only=True,final_launch_in_this_chat=False,
        scope='Scheduling estimates, not provider bill/cap. All earlier usage stays accounted.'))
    print('Prepared new claim/path head review packet; no services or protected-case reads.')


if __name__=='__main__':main()
