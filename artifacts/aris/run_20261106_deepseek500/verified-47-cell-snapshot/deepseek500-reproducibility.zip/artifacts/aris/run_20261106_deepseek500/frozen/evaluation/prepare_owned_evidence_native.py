"""Single acceptance-materiality owner, all class leads explicitly adjudicated."""
from pathlib import Path
from flash_study import read,save
import prepare_bound_source_native as previous

ROOT=Path('artifacts/owned-evidence-native-20261106')
OLD=Path('artifacts/bound-source-native-20261106')


def main():
    assert read(OLD/'readiness-decision.json')['closed']
    previous.ROOT=ROOT
    previous.main()
    save(ROOT/'prior-accounting.json',read(OLD/'continuation-accounting.json'))
    entry=read(ROOT/'review-disposition.json')
    entry.update(single_materiality_owner=True,
        additional_helpers=['evaluation/run_owned_evidence_native.ps1',
            'evaluation/prepare_owned_evidence_native.py','evaluation/prepare_bound_source_native.py',
            'evaluation/prepare_evidence_adjudicated_native.py','evaluation/prepare_path_adjudicated_native.py',
            (ROOT/'prior-accounting.json').as_posix(),'src/kaji_langgraph/config/default.yaml','pyproject.toml','uv.lock'],
        mechanism='Claim head owns only class effects and unverified uncertainty leads, no acceptance classifications. Path head alone must assign material/nonblocking to every client-indexed lead, plus all additional concerns. All raw leads/assignments survive; class-undermining or acceptance-material always blocks. Source-bound Jev records text once with compact unit index; no source evidence removed.')
    save(ROOT/'review-disposition.json',entry)
    print('New single-owner packet ready for review; no live requests.')


if __name__=='__main__':main()
