"""New claim-relation semantic ownership diagnostic, offline preparation."""
from pathlib import Path
from flash_study import read,save
import prepare_path_adjudicated_native as previous

ROOT=Path('artifacts/evidence-adjudicated-native-20261105')


def main():
    previous.ROOT=ROOT
    previous.OLD=Path('artifacts/path-adjudicated-native-20261105')
    previous.main()
    entry=read(ROOT/'review-disposition.json')
    entry.update(assessment_mode='evidence_adjudicated',
        caps_by_kind={'anchor':{'ollama':2,'jev':4}},
        planned_max_sends={'ollama':4,'jev':8,'search':0,'fetch':0},
        additional_helpers=['evaluation/run_evidence_adjudicated_native.ps1',
            'evaluation/prepare_evidence_adjudicated_native.py','evaluation/prepare_path_adjudicated_native.py',
            (ROOT/'prior-accounting.json').as_posix(),
            'src/kaji_langgraph/config/default.yaml','pyproject.toml','uv.lock'],
        mechanism='Claim head selects literal units but cannot assign stance; one batched Jev judgment owns each exact claim-to-passage relation. Separate path head owns shared/independent/unestablished origins, without unsupported obtaining-process claims. All raw judgments/issues remain retained, no semantic field repair/pruning.')
    save(ROOT/'review-disposition.json',entry)
    estimate=read(ROOT/'request-estimates.json');estimate['max_sends']=entry['planned_max_sends']
    save(ROOT/'request-estimates.json',estimate)
    print('New semantic stance/path packet ready for review; no live calls.')


if __name__=='__main__':main()
