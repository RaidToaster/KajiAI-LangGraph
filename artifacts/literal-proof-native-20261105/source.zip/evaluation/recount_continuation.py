"""Rebuild continuation usage from raw replies without reading held-out cases."""
from collections import Counter
from pathlib import Path
import json
import gzip
import zipfile

from flash_study import digest, read, save, scan
from recount_question_ledger import recount, frozen_source_digest


def rebuild():
    prior = recount(Path("artifacts/question-ledger-20261104"))
    totals = Counter(prior["totals"])
    by_model = Counter(prior["flash_sends_by_requested_model"])
    rows = prior["attempt_directories"][:]
    freezes = prior["frozen_sources"][:]
    active = []
    released = False
    for root in [Path("artifacts/indexed-ledger-20261104"), Path("artifacts/reference-first-20261104"),
            Path("artifacts/scope-first-20261104"), Path("artifacts/factored-readiness-20261104"),
            Path("artifacts/extractive-readiness-20261104"), Path("artifacts/adjudicated-readiness-20261104"),
            Path("artifacts/adjudicated-readiness-20261104-v2"), Path("artifacts/adjudicated-readiness-20261104-v3"), Path("artifacts/isolated-readiness-20261105"),
            Path("artifacts/catalogued-readiness-20261105"), Path("artifacts/catalogued-readiness-20261105-v2"), Path("artifacts/native-catalogue-readiness-20261105"), Path("artifacts/native-catalogue-readiness-20261105-v2"), Path("artifacts/native-catalogue-readiness-20261105-v3"), Path("artifacts/proof-native-readiness-20261105"),
            *[p for p in [Path("artifacts/bound-proof-native-20261105"), Path("artifacts/literal-proof-native-20261105")] if (p / "protocol.json").exists()]]:
        protocol = read(root / "protocol.json")
        decision_path = root / "readiness-decision.json"
        if decision_path.exists():
            decision = read(decision_path)
            assert decision["closed"] is True
            released = released or decision.get("development_released") is True
        else:
            active.append(root.as_posix())
        source_digest = frozen_source_digest(root / "source.zip")
        assert source_digest == protocol["source_sha256"]
        with zipfile.ZipFile(root / "source.zip") as archive:
            import hashlib
            for name, expected in protocol["helpers_sha256"].items():
                assert hashlib.sha256(archive.read(name)).hexdigest() == expected
        freezes.append({"phase": root.as_posix(), "archived_source_matches": True, "source_sha256": source_digest})
        directories = {p.parent for p in root.rglob("request-*.json") if not any(x.startswith("pytest") for x in p.relative_to(root).parts)}
        for directory in sorted(directories):
            requests = [read(p) for p in directory.glob("request-*.json")]
            model = next(r["request"]["body"]["model"] for r in requests if r["service"] == "ollama")
            usage = scan(directory, model)
            assert usage == read(directory / "usage.json")
            counts = Counter(s["service"] for s in usage)
            assert all(counts[k] == v for k, v in read(directory / "live-state.json")["counts"].items())
            job = read(directory / "job.json")
            assert job["exit_code"] is not None, "Unknown local execution outcome"
            for item in usage:
                assert item["status"] == 200 and item["model_verified"] is True
                assert not any(item.get(k) for k in ["incomplete", "accounting_error", "transport_error"])
                totals[item["service"]] += 1
                for key in ["input_tokens", "output_tokens"]:
                    totals[item["service"] + "_" + key] += item.get(key, 0)
                if item["service"] == "ollama":
                    by_model[item["requested_model"]] += 1
            result_path = directory / "result.json"
            rows.append({"directory": directory.as_posix(), "sends": usage,
                "result_sha256": digest(result_path) if result_path.exists() else None,
                "execution_failed": job["exit_code"] != 0, "hard_stop": job["hard_stop"]})
    retrieval_rows = []
    for retrieval_root, service, expected in [(Path("artifacts/temporal-retrieval-20261104-corrected"), "tinyfish_search", 4),
            (Path("artifacts/primary-record-fetch-20261104-bounded"), "tinyfish_fetch", 1)]:
        found = []
        for request in sorted(retrieval_root.rglob("request-*.json")):
            reservation = read(request)
            assert reservation["service"] == service
            response = request.with_name(request.name.replace("request-", "response-"))
            body = response.with_suffix(".body")
            assert read(response)["status"] == 200 and read(response)["bytes"] == len(body.read_bytes())
            encoded = body.read_bytes()
            decoded = gzip.decompress(encoded) if encoded.startswith(b"\x1f\x8b") else encoded
            json.loads(decoded.decode("utf-8"))
            assert read(request.parent / "job.json")["hard_stop"] is False
            found.append({"request": request.as_posix(), "service": service, "response_sha256": digest(body)})
        assert len(found) == expected
        retrieval_rows.extend(found)
    return {"scope": "New question/compiled/reference/scope and retrieval investigations; historical Flash-study reservations remain separate.",
        "totals": dict(totals), "flash_sends_by_requested_model": dict(by_model),
        "attempt_directories": rows, "frozen_sources": freezes,
        "new_unknown_outcomes": 0, "new_workflow_search": sum(r["service"] == "tinyfish_search" for r in retrieval_rows),
        "new_workflow_fetch": sum(r["service"] == "tinyfish_fetch" for r in retrieval_rows),
        "new_failed_local_executions": sum(row.get("execution_failed", False) for row in rows),
        "retrieval_raw_records": retrieval_rows,
        "retrieval_scope": "Four free Search calls in temporal-retrieval-20261104-corrected, one free/included original-post Fetch in primary-record-fetch-20261104-bounded. Model diagnostic packets made no new retrieval. Manual public literature/SCF reads/downloads are separate.",
        "historical_usage": "artifacts/question-ledger-20261104/prior-development-usage.json; one historical refused-loopback request has unknown token usage, never converted to zero.",
        "final_manifest_digest_matches": prior["final_manifest_digest_matches"],
        "final_manifest_n": prior["final_manifest_n"], "confirmation_attempts": 0, "final_attempts": 0,
        "current_paper_unchanged": prior["current_paper_unchanged_from_historical_verification"],
        "active_frozen_phases": active, "workflow_screen_released": released,
        "study_complete": False, "current_balance_verified": False}


if __name__ == "__main__":
    result = rebuild()
    save(Path("artifacts/reference-first-20261104/continuation-accounting.json"), result)
    print(json.dumps({k: v for k, v in result.items() if k not in {"attempt_directories", "frozen_sources"}}, indent=2))
