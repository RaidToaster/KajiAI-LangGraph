"""Client-created exact passage IDs; no model-generated citation endpoints."""
import json
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from kaji_langgraph.adjudicated_assessment import AdjudicatedDecision, adjudication_prompt, compile_adjudicated_selection
from kaji_langgraph.selected_assessment import selected_ranges


class CatalogueFinding(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str
    reference: str
    finding: str = Field(min_length=1, description="Narrow attributed paraphrase supported by this exact passage. Use quotation marks only for a word-for-word substring; never quote a rewritten paraphrase.")
    stance: Literal["supports", "refutes", "context"]


class CatalogueOrigin(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source: str
    origin: str | None = None
    verification_action: str | None = None
    unresolved_material_questions: list[str] = Field(default_factory=list)


class CatalogueDecision(AdjudicatedDecision):
    findings: list[CatalogueFinding]
    origins: list[CatalogueOrigin]


def passage_catalogue(records, selection, components):
    """Every complete <=250-word paragraph plus the selector's intact ranges.

    Does not enumerate quadratic combinations or truncate long paragraphs.
    All original records remain supplied, including non-cataloguable text.
    """
    return _catalogue(records, selected_ranges(selection, components, records))


def _catalogue(records, ranges):
    entries = {}
    def add(source, first, last, quote):
        key = f"{source}:{first}:{last}"
        if quote and len(quote.split()) <= 250:
            entries[key] = {"reference": {"source": source,
                "first_paragraph": first, "last_paragraph": last}, "literal_quote": quote}
    for record in records:
        for pid, quote in record["passages"].items():
            if "paragraph_offsets" not in record or pid in record["paragraph_offsets"]:
                add(record["id"], pid, pid, quote)
    for row in ranges:
        ref = row["reference"]
        add(ref["source"], ref["first_paragraph"], ref["last_paragraph"], row["literal_quote"])
    return entries


def catalogue_prompt(context, selection, ranges):
    records = context.get("records", [])
    catalogue = _catalogue(records, ranges)
    enriched = {**context, "passage_catalogue": catalogue}
    prefix = adjudication_prompt(enriched, selection, ranges).split("\nReturn ONLY JSON matching:\n", 1)[0]
    prefix = prefix.replace("First choose one source's inclusive LOCAL\nparagraph range of at most250words", "First choose one client-created passage_catalogue ID")
    prefix = prefix.replace("with local paragraph references", "with catalogue IDs")
    prefix = prefix.replace("Select origin/action ranges within that same source", "Select origin/action catalogue IDs belonging to that same source")
    schema = CatalogueDecision.model_json_schema()
    # Request-specific enumerations guide generation; local binding checks still
    # reject invented IDs. Cloud JSON mode is not schema-enforced decoding.
    defs = schema["$defs"]
    defs["ComponentClass"]["properties"]["id"]["enum"] = list(context.get("required_components", {}))
    defs["CatalogueFinding"]["properties"]["reference"]["enum"] = list(catalogue)
    defs["CatalogueOrigin"]["properties"]["source"]["enum"] = [r["id"] for r in records]
    for name in ("origin", "verification_action"):
        defs["CatalogueOrigin"]["properties"][name]["enum"] = [None, *catalogue]
    return ("CITATION CONTRACT: finding.reference, origin and verification_action are\n"
        "single exact keys from passage_catalogue, such as S1:P1:P1. Never return\n"
        "a source/range object or invent endpoints. The client copies the ID's\n"
        "entire retained passage without editing. Origin/action IDs must belong\n"
        "to that origin's source. Null unknown origin/action anchors. IDs prove\n"
        "literal lookup only, never entailment, reliability or independence.\n"
        "components[].id uses ONLY required_components keys (C0, C1, ...),\n"
        "never selection-lead IDs. Keep every required component. Their enum\n"
        "is separate from source IDs and passage-catalogue IDs in the schema.\n"
        "All original records remain available. Catalogue contains complete short\n"
        "paragraphs and selected intact ranges, not every possible combination;\n"
        "do not assert that uncatalogued text is absent evidence. If the needed\n"
        "passage is unavailable, retain the actual gap instead of inventing an ID.\n\n"
        + prefix + "\nReturn ONLY JSON matching:\n"
        + json.dumps(schema, separators=(",", ":")))


def compile_catalogue(selection, decision, components, records):
    catalogue = passage_catalogue(records, selection, components)
    failures = []
    def ref(key):
        if key is None:
            return None
        if key not in catalogue:
            failures.append(f"Unknown passage catalogue ID: {key}")
            return {"source": "UNKNOWN", "first_paragraph": "UNKNOWN", "last_paragraph": "UNKNOWN"}
        return catalogue[key]["reference"]
    data = decision.model_dump(mode="json")
    data["findings"] = [{**f.model_dump(), "reference": ref(f.reference)} for f in decision.findings]
    data["origins"] = [{**o.model_dump(), "origin": ref(o.origin),
        "verification_action": ref(o.verification_action)} for o in decision.origins]
    data["gaps"] = [*data["gaps"], *failures]
    translated = AdjudicatedDecision.model_validate(data)
    result = compile_adjudicated_selection(selection, translated, components, records)
    result.indexed_input.update(catalogue_response=decision.model_dump(mode="json"),
        passage_catalogue=catalogue, assessment_mode="catalogued")
    return result
