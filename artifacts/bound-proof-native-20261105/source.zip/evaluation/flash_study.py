"""Sequential Flash workflow comparison with an auditable per-attempt journal."""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from runtime_pilot import Ledger, LimitReached, load_keys, transport


MODELS = {
    "glm": "glm-5.3-flash:cloud",
    "deepseek": "deepseek-v4.1-flash:cloud",
}
CAPS = {"ollama": 8, "jev": 40, "tinyfish_search": 6, "tinyfish_fetch": 12}
THREADS = dict.fromkeys(("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                        "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"), "2")


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def task_id(task):
    return f"{task['case']}-{task['model']}-{task['arm']}"


def attempt_path(run, phase, protocol, task):
    identity = task_id(task)
    if identity in protocol.get("reused_attempts", {}):
        return Path(protocol["reused_attempts"][identity])
    return run / phase / identity


def scan(directory, model):
    """Read raw response bodies, including compressed SDK responses."""
    sends = []
    for path in sorted(directory.glob("request-*.json")):
        request = read(path)
        service = request["service"]
        suffix = path.stem.split("-")[1]
        meta = directory / f"response-{suffix}.json"
        body = directory / f"response-{suffix}.body"
        response = read(meta) if meta.exists() else {}
        record = {"service": service, "request_id": suffix, "sent_at": request["timestamp"],
                  "status": response.get("status"), "transport_error": response.get("error")}
        if not body.exists() or not meta.exists():
            record["incomplete"] = True
        elif response["status"] == 200 and service in {"ollama", "jev"}:
            try:
                raw = body.read_bytes()
                if raw.startswith(b"\x1f\x8b"):
                    raw = gzip.decompress(raw)
                if service == "ollama":
                    value = json.loads(raw.splitlines()[-1])
                    record.update(returned_model=value["model"], requested_model=model,
                                  done=value["done"], done_reason=value.get("done_reason"),
                                  input_tokens=value["prompt_eval_count"], output_tokens=value["eval_count"])
                    record["model_verified"] = value["model"] in {model, model.removesuffix(":cloud")}
                    record["incomplete"] = not value["done"]
                else:
                    value = json.loads(raw)
                    record.update(returned_model=value["model"], requested_model="jev-1.13.0",
                                  model_verified=value["model"] == "jev-1.13.0", **value["usage"])
            except (ValueError, OSError, IndexError, KeyError) as exc:
                record["accounting_error"] = str(exc)
        sends.append(record)
    return sends


class FlashLedger(Ledger):
    def __init__(self, directory, protocol, model):
        super().__init__(directory, protocol)
        self.model = model

    def response(self, number, status, body):
        super().response(number, status, body)
        path = self.directory / f"request-{number:03}.json"
        if read(path)["service"] != "ollama" or status != 200:
            return
        try:
            response = json.loads(body.splitlines()[-1])
            if not response.get("done") or response.get("model") not in {
                self.model, self.model.removesuffix(":cloud")
            }:
                raise LimitReached("Unexpected Ollama model ID or incomplete terminal reply")
        except (ValueError, IndexError, LimitReached) as exc:
            self.failed(number, exc)
            raise


def run_cell(directory, protocol, task, case):
    import httpx
    import httpx2
    import urllib.error
    import urllib.request
    from langchain_ollama import ChatOllama
    from typesafe_sdk import RetryPolicy, TypeSafeClient
    import kaji_langgraph.jev as jev_module
    from kaji_langgraph.evaluation import model_input, prediction_label
    from kaji_langgraph.graph import run_claim
    from kaji_langgraph.llm import OllamaBackend
    from kaji_langgraph.retrieval import TinyFishRetriever

    load_keys()
    model = MODELS[task["model"]]
    config = deepcopy(protocol["config"])
    config["model"].update(name=model, canonical_evidence_prompt=task["arm"] == "candidate")
    recover = task["arm"] == "candidate" and protocol.get("recover_empty_assessment", False)
    compact = task["arm"] == "candidate" and protocol.get("compact_evidence_prompt", False)
    brief_tokens = protocol.get("brief_assessment_tokens") if compact else None
    compiled = task["arm"] == "candidate" and protocol.get("compiled_ledger_candidate", False)
    if compiled:
        assessment_mode = protocol.get("compiled_assessment_mode", "ledger")
        if assessment_mode not in {"ledger", "reference_first", "scope_first", "factored", "extractive", "adjudicated", "catalogued", "proof", "bound_proof"}:
            raise ValueError("Unsupported compiled candidate assessment mode")
        config["model"].update(assessment_mode=assessment_mode, decomposition_method="questions_as_guidance")
        brief_tokens = protocol.get("brief_assessment_tokens", 6144)
    if task["arm"] == "candidate" and protocol.get("require_independent_provenance_review"):
        config["policy"]["require_independent_provenance_review"] = True
    if task["arm"] == "candidate" and protocol.get("search_source_references"):
        config["policy"]["search_source_references"] = True
    ledger = FlashLedger(directory, {**protocol, "num_predict": brief_tokens or protocol["num_predict"]}, model)
    ledger.task = task_id(task)
    effort = None
    if task["arm"] == "candidate":
        effort = protocol.get("candidate_reasoning_effort", {}).get(task["model"])
        if effort is None and task["model"] == "glm" and protocol.get("glm_low_reasoning"):
            effort = "low"
        if effort is not None and effort is not False and effort not in {"low", "high", "max"}:
            raise ValueError("Unsupported frozen candidate reasoning effort")
    backend = OllamaBackend(model=model, base_url=config["model"]["base_url"], temperature=0,
                            verdict_mode="averitec",
                            canonical_evidence_prompt=config["model"]["canonical_evidence_prompt"],
                            recover_empty_assessment=recover, compact_evidence_prompt=compact,
                            brief_assessment_tokens=brief_tokens,
                            assessment_mode=config["model"].get("assessment_mode", "standard"),
                            line_assessment_prompt=compact and protocol.get("line_assessment_prompt", False),
                            line_reasoning_effort=effort or None)
    backend._model = ChatOllama(
        model=model, base_url=backend.base_url, temperature=0,
        num_predict=protocol["num_predict"], validate_model_on_init=False,
        client_kwargs={"transport": transport(httpx, ledger, "ollama"), "timeout": 90,
                       "follow_redirects": False, "trust_env": False},
    )

    def jev_client(**kwargs):
        return TypeSafeClient(**kwargs, retry=RetryPolicy(max_retries=0),
                              http_client=httpx2.Client(
                                  transport=transport(httpx2, ledger, "jev"), timeout=15,
                                  follow_redirects=False))

    jev_module.TypeSafeClient = jev_client

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None

    opener = urllib.request.build_opener(NoRedirect())

    class LoggedRetriever(TinyFishRetriever):
        def _request(self, url, *, payload=None, timeout):
            service = "tinyfish_search" if payload is None else "tinyfish_fetch"
            number = ledger.before(service, {"url": url, "body": payload})
            request = urllib.request.Request(
                url, data=None if payload is None else json.dumps(payload).encode("utf-8"),
                headers={"X-API-Key": os.environ["TINYFISH_API_KEY"], "Accept": "application/json",
                         "Content-Type": "application/json"},
            )
            try:
                try:
                    response = opener.open(request, timeout=timeout)
                except urllib.error.HTTPError as exc:
                    response = exc
                with response:
                    status = response.status
                    body = response.read(2_000_001)
                ledger.response(number, status, body[:2_000_000])
                if status != 200 or len(body) > 2_000_000:
                    raise RuntimeError(f"TinyFish HTTP {status}; response size {len(body)}")
                value = json.loads(body)
                if not isinstance(value, dict):
                    raise ValueError("Expected TinyFish JSON object")
                return value
            except Exception as exc:
                ledger.failed(number, exc)
                raise

    with (directory / "progress.log").open("w", encoding="utf-8") as log:
        def progress(message):
            print(message, file=log, flush=True)

        result = run_claim(
            **model_input(case), config=config, max_rounds=protocol["rounds"],
            model=backend, retriever=LoggedRetriever(),
            jev=jev_module.JevClient(model=config["jev"]["model"]), progress=progress,
        )
    save(directory / "result.json", {
        **task, "requested_model": model, "gold_label": case["label"],
        "predicted_label": prediction_label(result.predicted_verdict),
        "accepted_label": prediction_label(result.verdict), "result": result.model_dump(mode="json"),
    })


def check_protocol(run, phase, protocol):
    from kaji_langgraph.evaluation import code_digest

    if protocol["source_sha256"] != code_digest():
        raise SystemExit("Runtime source differs from the frozen phase")
    for name, expected in protocol["file_sha256"].items():
        if digest(Path(name)) != expected:
            raise SystemExit(f"Frozen input changed: {name}")
    if protocol["models"] != MODELS or protocol["caps"] != CAPS:
        raise SystemExit("Unexpected service model or request limits")
    if not (run / "headroom.json").is_file():
        raise SystemExit("Included service headroom has not been recorded")
    approval = run / f"{phase}-approval.json"
    if not approval.is_file() or read(approval).get("approved_protocol_sha256") != digest(run / f"{phase}.json"):
        raise SystemExit("No matching live allowance for the frozen phase")
    if phase == "final" and set(protocol.get("retrieval_rate_limits", {})) != {
        "tinyfish_search", "tinyfish_fetch"
    }:
        raise SystemExit("Final release requires frozen Search and Fetch pacing windows")
    if phase != "development":
        prior = "development" if phase == "confirmation" else "confirmation"
        decision = run / f"{prior}-decision.json"
        if not decision.is_file() or read(decision).get("passed") is not True:
            raise SystemExit(f"{prior} quality screen has not passed")


def validate_schedule(protocol, required):
    cases = read(Path(protocol["cases"]))
    expected = {(case, model, arm) for case in cases for model in MODELS
                for arm in ("baseline", "candidate")}
    scheduled = [(task["case"], task["model"], task["arm"]) for task in protocol["schedule"]]
    if len(cases) != required or len(scheduled) != len(expected) or set(scheduled) != expected:
        raise SystemExit(f"Expected exactly {required} paired claims on both Flash models")
    return cases


def check_advancement(run, phase, protocol):
    """Recount the preceding screen before reserving any new service call."""
    from analyze_flash_study import analyze, screen

    prior = "development" if phase == "confirmation" else "confirmation"
    previous_path = run / f"{prior}.json"
    previous = read(previous_path)
    for manifest in (previous, protocol):
        for path in (Path(manifest["cases"]), Path("evaluation/analyze_flash_study.py")):
            if manifest["file_sha256"].get(path.as_posix()) != digest(path):
                raise SystemExit(f"Release requires a frozen case set and scorer: {path}")
    for key in ("source_sha256", "config", "models", "caps", "rounds", "num_predict",
                "recover_empty_assessment", "compact_evidence_prompt", "brief_assessment_tokens",
                "require_independent_provenance_review", "line_assessment_prompt", "search_source_references",
                "glm_low_reasoning", "candidate_reasoning_effort", "compiled_ledger_candidate", "compiled_assessment_mode"):
        if protocol.get(key) != previous.get(key):
            raise SystemExit(f"Released configuration differs from {prior}: {key}")
    for name, expected in previous["file_sha256"].items():
        if digest(Path(name)) != expected:
            raise SystemExit(f"Frozen {prior} input changed: {name}")
    before = validate_schedule(previous, 8 if prior == "development" else 12)
    after = validate_schedule(protocol, 12 if phase == "confirmation" else 500)
    def normalized(cases):
        return {" ".join(row["claim"].casefold().split()) for row in cases.values()}

    if before.keys() & after.keys() or normalized(before) & normalized(after):
        raise SystemExit(f"{phase} cases overlap with {prior}")
    if phase == "final":
        development = read(run / "development.json")
        development_cases = read(Path(development["cases"]))
        if development_cases.keys() & after.keys() or normalized(development_cases) & normalized(after):
            raise SystemExit("Final cases overlap with development")
        manifest_path = Path(protocol["final_case_manifest"])
        manifest = read(manifest_path)
        if (protocol["file_sha256"].get(manifest_path.as_posix()) != digest(manifest_path)
                or manifest["cases_sha256"] != digest(Path(protocol["cases"]))
                or list(after) != manifest["ids"] or manifest["n"] != len(after)):
            raise SystemExit("Final cases do not match the shared frozen manifest")
    decision = read(run / f"{prior}-decision.json")
    previous_sha = digest(previous_path)
    if decision.get("protocol_sha256") != previous_sha:
        raise SystemExit(f"{prior} decision is not bound to the current protocol")
    reused = previous.get("reused_attempts", {})
    for task in previous["schedule"]:
        directory = attempt_path(run, prior, previous, task)
        attempt = directory / "attempt.json"
        if task_id(task) in reused:
            for name in ("attempt.json", "job.json", "result.json", "usage.json"):
                if (directory / name).as_posix() not in previous["file_sha256"]:
                    raise SystemExit(f"Reused attempt lacks a frozen {name}: {directory}")
        elif not attempt.is_file() or read(attempt)["protocol_sha256"] != previous_sha:
            raise SystemExit(f"Attempt is missing or belongs to a different protocol: {directory}")
    adjudications = Path(decision["adjudications"])
    if decision["adjudications_sha256"] != digest(adjudications):
        raise SystemExit(f"{prior} citation adjudications changed")
    if not screen(analyze(run, prior), read(adjudications))["passed"]:
        raise SystemExit(f"{prior} no longer passes on the retained attempt records")


def tally(run, phase):
    sends = []
    for path in (run / phase).glob("*/usage.json"):
        sends.extend(read(path))
    totals = Counter()
    for send in sends:
        totals[send["service"]] += 1
        for key in ("input_tokens", "output_tokens"):
            totals[f"{send['service']}_{key}"] += send.get(key, 0)
        if send["service"] == "ollama":
            requested_model = send.get("requested_model")
            if requested_model not in MODELS.values():
                # Transport failures are journaled before a model response exists.
                totals["ollama_sends_without_usage"] += 1
                continue
            inp, out = (0.15, 0.50) if requested_model == MODELS["glm"] else (0.30, 1.20)
            totals["ollama_estimated_usd"] += (
                inp * send.get("input_tokens", 0) + out * send.get("output_tokens", 0)
            ) / 1_000_000
    totals["jev_estimated_usd"] = totals["jev_input_tokens"] * 0.042 / 1_000_000
    return dict(totals)


def recorded_retrieval_sends(root):
    """Count durable sends, including requests with no terminal response."""
    sends = []
    for attempt in root.rglob("attempt.json"):
        directory = attempt.parent
        usage = directory / "usage.json"
        if usage.is_file():
            sends.extend(read(usage))
        else:
            for path in directory.glob("request-*.json"):
                request = read(path)
                sends.append({"service": request["service"], "sent_at": request["timestamp"]})
    return [send for send in sends if send["service"] in {"tinyfish_search", "tinyfish_fetch"}]


def retrieval_pause_until(sends, limits, now):
    """Reserve a full cell's worst-case sends before allocating its directory."""
    resume_at = now
    for service, windows in limits.items():
        timestamps = sorted(datetime.fromisoformat(send["sent_at"]).timestamp()
                            for send in sends if send["service"] == service)
        for seconds, maximum in windows:
            reserve = CAPS[service]
            if seconds <= 0 or maximum < reserve:
                raise ValueError(f"Invalid retrieval window for {service}")
            recent = [stamp for stamp in timestamps if stamp > now - seconds]
            overflow = len(recent) + reserve - maximum
            if overflow > 0:
                resume_at = max(resume_at, recent[overflow - 1] + seconds)
    return resume_at


def launch(run, phase, protocol, limit):
    stage = run / phase
    stage.mkdir(exist_ok=True)
    # An exclusive claim of the phase prevents concurrent execution.
    lock = stage / "running.lock"
    with lock.open("x", encoding="utf-8") as handle:
        print(os.getpid(), file=handle)
    try:
        for directory in stage.iterdir():
            if not directory.is_dir():
                continue
            job = directory / "job.json"
            if not job.exists():
                raise SystemExit(f"Started attempt needs adjudication: {directory.name}")
            if read(job).get("hard_stop") and not (directory / "resume-review.json").is_file():
                raise SystemExit(f"Unresolved service/transport stop: {directory.name}")
        limits = protocol.get("retrieval_rate_limits", {})
        sends = []
        if limits:
            scope = Path(protocol["retrieval_usage_scope"]).resolve()
            if not run.is_relative_to(scope) or not scope.is_relative_to(Path.cwd().resolve()):
                raise SystemExit("Retrieval usage scope must contain the run and stay in the workspace")
            sends = recorded_retrieval_sends(scope)
        started = 0
        for task in protocol["schedule"]:
            directory = attempt_path(run, phase, protocol, task)
            if directory.exists():
                continue
            totals = tally(run, phase)
            if any(totals.get(key, 0) >= amount for key, amount in protocol["usage_stop"].items()):
                raise SystemExit(f"Phase allowance reached: {totals}")
            if started == limit:
                break
            now = time.time()
            resume_at = retrieval_pause_until(sends, limits, now)
            if resume_at > now:
                resume = datetime.fromtimestamp(resume_at, timezone.utc).isoformat()
                save(run / f"{phase}-retrieval-pause.json", {
                    "next_untouched_attempt": task_id(task), "resume_at": resume,
                    "reason": "Reserve capacity for every retrieval send in the next cell.",
                })
                print(f"Retrieval window exhausted. Next cell can start at {resume}.", flush=True)
                break
            directory.mkdir()
            started += 1
            begin = time.monotonic()
            save(directory / "attempt.json", {
                **task, "started_at": datetime.now(timezone.utc).isoformat(),
                "protocol_sha256": digest(run / f"{phase}.json"),
            })
            save(directory / "live-state.json", {
                "counts": dict.fromkeys(CAPS, 0), "deadline": time.time() + 285, "stop": None,
            })
            with (directory / "stdout.log").open("wb") as out, (directory / "stderr.log").open("wb") as err:
                try:
                    result = subprocess.run(
                        [sys.executable, __file__, str(run), phase, "--cell", task_id(task)],
                        timeout=300, stdout=out, stderr=err,
                        env={**os.environ, **THREADS, "PYTHONUTF8": "1"},
                    )
                    exit_code = result.returncode
                except subprocess.TimeoutExpired:
                    exit_code = None
            usage = scan(directory, MODELS[task["model"]])
            save(directory / "usage.json", usage)
            sends.extend(send for send in usage if send["service"] in limits)
            counts = Counter(send["service"] for send in usage)
            state = read(directory / "live-state.json")
            invalid_usage = (
                any(send.get("status") != 200 or send.get("incomplete") or send.get("accounting_error")
                    or send.get("model_verified") is False or send.get("transport_error") for send in usage)
                or any(counts[key] != value for key, value in state["counts"].items())
            )
            hard_stop = bool(exit_code != 0 or state["stop"] or invalid_usage)
            save(directory / "job.json", {
                "exit_code": exit_code, "elapsed_seconds": time.monotonic() - begin,
                "hard_stop": hard_stop, "stop_reason": state["stop"],
                "accounting_problem": invalid_usage,
            })
            totals = tally(run, phase)
            print(task_id(task), "STOP" if hard_stop else "DONE", totals, flush=True)
            if hard_stop:
                raise SystemExit(f"Inspect retained attempt before resuming: {directory.name}")
    finally:
        lock.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    parser.add_argument("phase", choices=("development", "confirmation", "final"))
    parser.add_argument("--limit", type=int, default=1)
    parser.add_argument("--cell")
    args = parser.parse_args()
    run = args.run.resolve()
    protocol = read(run / f"{args.phase}.json")
    check_protocol(run, args.phase, protocol)
    if args.cell:
        task = next(task for task in protocol["schedule"] if task_id(task) == args.cell)
        cases = read(Path(protocol["cases"]))
        directory = run / args.phase / args.cell
        if not (directory / "attempt.json").is_file() or list(directory.glob("request-*.json")):
            raise SystemExit("Worker requires a reserved untouched attempt")
        run_cell(directory, protocol, task, cases[task["case"]])
    else:
        if args.limit < 1:
            parser.error("--limit must be positive")
        if args.phase != "development":
            check_advancement(run, args.phase, protocol)
        launch(run, args.phase, protocol, args.limit)


if __name__ == "__main__":
    main()
