"""Client-created exact passage IDs; no model-generated citation endpoints."""
import json
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from kaji_langgraph.adjudicated_assessment import AdjudicatedDecision, adjudication_prompt, compile_adjudicated_selection
from kaji_langgraph.selected_assessment import selected_ranges


class CatalogueFinding(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str
    reference: str
    finding: str = Field(min_length=1)
    stance: Literal["supports", "refutes", "context"]


class CatalogueOrigin(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source: str
    origin: str | None = None
    verification_action: str | None = None
    unresolved_material_questions: list[str] = Field(default_factory=list)


class CatalogueDecision(AdjudicatedDecision):
    findings: list[CatalogueFinding]
    origins: list[CatalogueOrigin]


def passage_catalogue(records, selection, components):
    """Every complete <=250-word paragraph plus the selector's intact ranges.

    Does not enumerate quadratic combinations or truncate long paragraphs.
    All original records remain supplied, including non-cataloguable text.
    """
    entries = {}
    def add(source, first, last, quote):
        key = f"{source}:{first}:{last}"
        if quote and len(quote.split()) <= 250:
            entries[key] = {"reference": {"source": source,
                "first_paragraph": first, "last_paragraph": last}, "literal_quote": quote}
    for record in records:
        for pid, quote in record["passages"].items():
            if "paragraph_offsets" not in record or pid in record["paragraph_offsets"]:
                add(record["id"], pid, pid, quote)
    for row in selected_ranges(selection, components, records):
        ref = row["reference"]
        add(ref["source"], ref["first_paragraph"], ref["last_paragraph"], row["literal_quote"])
    return entries


def catalogue_prompt(context, selection, ranges):
    # Public prompt records may omit offset tables. Restore offsets from their
    # intact paragraph strings solely to validate already-selected ranges.
    from kaji_langgraph.reference_assessment import paragraph_records
    from kaji_langgraph.models import SourceRecord
    records = context.get("records", [])
    restored = []
    for record in records:
        if "paragraph_offsets" in record:
            restored.append(record)
        else:
            text = "\n\n".join(record["passages"].values())
            rebuilt = paragraph_records([SourceRecord(url=record["url"], page_text=text)])[0]
            # IDs and exact paragraph contents must survive reconstruction.
            if rebuilt["passages"] != record["passages"]:
                raise ValueError("Cannot reconstruct literal catalogue paragraphs")
            restored.append({**record, "visible_text": rebuilt["visible_text"],
                "paragraph_offsets": rebuilt["paragraph_offsets"]})
    components = context.get("required_components", {})
    catalogue = passage_catalogue(restored, selection, components)
    enriched = {**context, "passage_catalogue": catalogue}
    prefix = adjudication_prompt(enriched, selection, ranges).split("\nReturn ONLY JSON matching:\n", 1)[0]
    prefix = prefix.replace("First choose one source's inclusive LOCAL\nparagraph range of at most250words", "First choose one client-created passage_catalogue ID")
    prefix = prefix.replace("with local paragraph references", "with catalogue IDs")
    return ("CITATION CONTRACT: finding.reference, origin and verification_action are\n"
        "single exact keys from passage_catalogue, such as S1:P1:P1. Never return\n"
        "a source/range object or invent endpoints. The client copies the ID's\n"
        "entire retained passage without editing. Origin/action IDs must belong\n"
        "to that origin's source. Null unknown origin/action anchors. IDs prove\n"
        "literal lookup only, never entailment, reliability or independence.\n"
        "All original records remain available. Catalogue contains complete short\n"
        "paragraphs and selected intact ranges, not every possible combination;\n"
        "do not assert that uncatalogued text is absent evidence. If the needed\n"
        "passage is unavailable, retain the actual gap instead of inventing an ID.\n\n"
        + prefix + "\nReturn ONLY JSON matching:\n"
        + json.dumps(CatalogueDecision.model_json_schema(), separators=(",", ":")))


def compile_catalogue(selection, decision, components, records):
    catalogue = passage_catalogue(records, selection, components)
    failures = []
    def ref(key):
        if key is None:
            return None
        if key not in catalogue:
            failures.append(f"Unknown passage catalogue ID: {key}")
            return {"source": "UNKNOWN", "first_paragraph": "UNKNOWN", "last_paragraph": "UNKNOWN"}
        return catalogue[key]["reference"]
    data = decision.model_dump(mode="json")
    data["findings"] = [{**f.model_dump(), "reference": ref(f.reference)} for f in decision.findings]
    data["origins"] = [{**o.model_dump(), "origin": ref(o.origin),
        "verification_action": ref(o.verification_action)} for o in decision.origins]
    data["gaps"] = [*data["gaps"], *failures]
    translated = AdjudicatedDecision.model_validate(data)
    result = compile_adjudicated_selection(selection, translated, components, records)
    result.indexed_input.update(catalogue_response=decision.model_dump(mode="json"),
        passage_catalogue=catalogue, assessment_mode="catalogued")
    return result
