"""Small source-blind decomposition diagnostic, with retained transport records."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

from flash_study import MODELS, THREADS, FlashLedger, digest, read, save, scan
from kaji_langgraph.evaluation import code_digest
from kaji_langgraph.llm import OllamaBackend, heuristic_decomposition
from kaji_langgraph.models import QuestionDecomposition
from runtime_pilot import transport


class Capture(OllamaBackend):
    def __init__(self):
        pass

    def _structured(self, schema, prompt):
        return prompt


def prepare(out):
    out.mkdir(exist_ok=False)
    cases = [
        {"id": "sufficient", "claim": "On 1 June 2024, Northport council approved the bridge plan by seven votes to two."},
        {"id": "insufficient", "claim": "Mayor Imani said that Eastport unemployment fell by 20 percent between 2022 and 2023."},
        {"id": "conflicting", "claim": "In 2023, the independently measured median delivery time in Westport was less than 30 minutes."},
        {"id": "shared", "claim": "In 2024, Southport's new signal system caused a 15 percent reduction in junction delays compared with 2023."},
    ]
    study = Path("artifacts/flash-workflow-20261103")
    old = read(study / "development-cases.json")["train-1225"]
    cases.append({"id": "train-1225", "claim": old["claim"]})
    for case in cases:
        case["reference_date"] = "2024-06-30" if case["id"] != "train-1225" else old.get("claim_date", old.get("date", "2020-02-26"))
        case["statement_only"] = list(dict.fromkeys([case["claim"], *heuristic_decomposition(case["claim"])]))
    prompt = Capture().decompose_with_questions("PLACEHOLDER", reference_date="CONTEXT")
    prompt = prompt.split("\nReference date:", 1)[0]
    prompt += ("\nApply this source-blind planning task independently to each case below. "
               "Return ONLY JSON: {\"plans\":{\"case_id\":{\"assertions\":[...],\"questions\":[...]}}}. "
               "Use at most 4 statements and 5 questions per case, one concise sentence each. "
               "No evidence is supplied and no conclusion is requested. Cases:\n"
               + json.dumps([{k:v for k,v in c.items() if k != "statement_only"} for c in cases]))
    tasks = []
    for model in MODELS:
        tasks.append({"id": model + "-planning", "model": model, "body": {
            "model": MODELS[model], "stream": False, "think": "low" if model == "glm" else False,
            "options": {"temperature": 0, "num_predict": 2048},
            "messages": [{"role": "user", "content": prompt}]}})
    save(out / "protocol.json", {
        "stage": "source_blind_planning", "models": MODELS,
        "caps": {"ollama": 1}, "num_predict": 2048, "cases": cases, "tasks": tasks,
        "source_sha256": code_digest(), "runner_sha256": digest(Path(__file__)),
        "planned_total_sends": {"ollama": 2, "jev": 0, "search": 0, "fetch": 0},
        "estimate": {"input_tokens_total_estimate": 3000, "requested_output_tokens_total": 4096,
                     "token_estimate_is_not_a_billed_amount_or_remote_hard_cap": True},
        "screen": {
            "required": ["All five plans parse without repairs; failures retained.",
                         "Preserve subject, dates, quantity, population, attribution and causal qualifications.",
                         "Neutral research questions cover material components and counterevidence; do not supply conclusions.",
                         "Attribution and embedded truth distinguished in insufficient control.",
                         "Historical measurement and people-versus-household conversion addressed on train-1225.",
                         "No invented factual premise; no final/confirmation cases or labels enter prompts."],
            "decision": "A planning pass only permits preparing a separate frozen matched evidence diagnostic. It does not release a workflow screen or demonstrate supported acceptance. Any defect is diagnosed before deciding the next justified action."},
        "next_diagnostic_design": {
            "controls": "Authored sufficient, missing embedded-content evidence, conflicting measurements, and shared-lineage causal evidence; all marked authored, not real-world findings. Retained train-1225 evidence is a separate development anchor.",
            "factors": "Compare statements-only and statements-plus-questions under identical retrieval ceilings; separately compare ledger off/on with identical evidence. Freeze exact packets, expected coverage and decisions before assessment calls.",
            "ledger": "Original claim remains required. Map components to exact source-version passages, literal event/data dates, origins and unresolved material questions. Literal audit cannot certify semantics or independence.",
            "metrics": ["whole_claim_coverage", "scope_preservation", "useful_discovery", "unsupported_acceptance", "execution_failure", "tokens_and_sends"],
            "zero_retrieval_note": "This stage spends zero matched retrieval calls; discovery is not measured and cannot be claimed."},
        "screen_scope_resolution": {
            "user_authorized_conditionally": True, "new_development_attempts": 20,
            "reused_development_baselines": 12, "confirmation_attempts": 48,
            "total_new_workflow_attempts": 68,
            "condition": "Only after the small diagnostic justifies a new candidate; unchanged frozen guards, existing credits, inspected batches."}})
    with zipfile.ZipFile(out / "source.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for root in (Path("src"), Path("tests")):
            for path in root.rglob("*.py"):
                archive.write(path, path.as_posix())
        archive.write(__file__, Path(__file__).as_posix())
    save(out / "receipt.json", {
        "protocol_sha256": digest(out / "protocol.json"),
        "authorization": "User permits a few targeted online requests and continued low-risk work. Two source-blind planning sends only; no workflow release.",
        "caps": {"ollama": 2, "jev": 0, "search": 0, "fetch": 0},
        "restrictions": "Existing credits/included quota only; no retry; one worker, two numerical threads, 300s/job; stop on unknown outcome, quota, wrong model or output overrun."})


def worker(out, p, task):
    import httpx
    directory = out / task["id"]
    ledger = FlashLedger(directory, p, MODELS[task["model"]])
    ledger.task = task["id"]
    with httpx.Client(transport=transport(httpx, ledger, "ollama"), timeout=90,
                      trust_env=False, follow_redirects=False) as client:
        response = client.post("http://localhost:11434/api/chat", json=task["body"])
        response.raise_for_status()
        body = response.json()
    text = body["message"]["content"]
    save(directory / "answer.json", {"text": text})
    error = None
    plans = {}
    try:
        raw = json.loads(text)
        if set(raw["plans"]) != {c["id"] for c in p["cases"]}:
            raise ValueError("Missing/extra case IDs")
        plans = {k: QuestionDecomposition.model_validate(v).model_dump() for k,v in raw["plans"].items()}
    except (ValueError, KeyError, TypeError) as exc:
        error = str(exc)
    save(directory / "result.json", {"parsed": error is None, "parse_error": error,
                                     "plans": plans, "efficacy_claim": False})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--worker")
    parser.add_argument("--limit", type=int, default=1)
    args = parser.parse_args()
    if args.prepare:
        prepare(args.directory)
        return
    out = args.directory
    p = read(out / "protocol.json")
    assert p["runner_sha256"] == digest(Path(__file__))
    assert p["source_sha256"] == code_digest()
    assert p["models"] == MODELS
    assert read(out / "receipt.json")["protocol_sha256"] == digest(out / "protocol.json")
    if args.worker:
        worker(out, p, next(t for t in p["tasks"] if t["id"] == args.worker))
        return
    assert args.limit in {1,2}
    count = 0
    for task in p["tasks"]:
        d = out / task["id"]
        if d.exists():
            assert (d / "job.json").exists() and not read(d / "job.json")["hard_stop"], "Inspect retained failure; never retry"
            continue
        if count >= args.limit:
            break
        d.mkdir()
        save(d / "attempt.json", {"started_at": datetime.now(timezone.utc).isoformat(),
                                  "protocol_sha256": digest(out / "protocol.json"), "task": task["id"]})
        save(d / "live-state.json", {"counts": {"ollama": 0}, "deadline": time.time()+270, "stop": None})
        start = time.monotonic()
        with (d / "stdout.log").open("wb") as stdout, (d / "stderr.log").open("wb") as stderr:
            try:
                proc = subprocess.run([sys.executable, __file__, str(out), "--worker", task["id"]],
                                      timeout=300, stdout=stdout, stderr=stderr,
                                      env={**os.environ, **THREADS, "PYTHONUTF8": "1"})
                code = proc.returncode
            except subprocess.TimeoutExpired:
                code = None
        usage = scan(d, MODELS[task["model"]])
        save(d / "usage.json", usage)
        state = read(d / "live-state.json")
        bad = len(usage) != state["counts"]["ollama"] or any(
            r.get("status") != 200 or r.get("transport_error") or r.get("accounting_error")
            or r.get("model_verified") is not True or r.get("incomplete") for r in usage)
        hard = bool(code != 0 or bad or state["stop"])
        save(d / "job.json", {"exit_code": code, "elapsed_seconds": time.monotonic()-start,
                               "hard_stop": hard, "accounting_problem": bad})
        print(task["id"], "STOP" if hard else "DONE", flush=True)
        count += 1
        if hard:
            raise SystemExit("Inspect retained failed/unknown attempt; no retry")


if __name__ == "__main__":
    main()
