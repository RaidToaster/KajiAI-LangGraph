"""Offline global passage allocation with fixed total text/source ceilings.

This changes per-source allocation explicitly: it is not a same-per-source
comparison. Every source keeps at least one passage; no historical packet is
edited. Exposure checks remain distinct from support verification.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import re

from flash_study import read,save,digest
from flash_method_windows import select
from gap_passage_selection_v2 import dimensions
from kaji_langgraph.study_analysis import replay_sources


def components(text):
    result=dimensions(text)
    result.discard("calculation_method")
    if re.search(r"sort|summ?ed|added|multipl|Python|raw sample",text,re.I):result.add("explicit_method")
    if re.search(r"former mayor|senator|mayor|minister|council",text,re.I):result.add("identity_role")
    return result


def allocate(claim,sources,reference,leads):
    lookup={s.url:s for s in sources}
    max_words=sum(len(w.split()) for r in reference for w in r["passages"].values())
    max_count=sum(len(r["passages"]) for r in reference)
    terms=set(re.findall(r"\w{3,}"," ".join([claim,*leads]).lower()))
    windows={}
    for record in reference:
        text=lookup[record["url"]].retrieved_text;words=list(re.finditer(r"\S+",text))
        windows[record["id"]]=list(dict.fromkeys(text[words[start].start():words[min(start+72,len(words))-1].end()] for start in range(0,len(words),56)))
    selected={r["id"]:[] for r in reference};covered=set();used=0
    def score(w):return (len(components(w)-covered),len(terms.intersection(re.findall(r"\w{3,}",w.lower()))))
    # Reserve at least one passage per source in unchanged source order.
    for i,record in enumerate(reference):
        remaining_ids=[r["id"] for r in reference[i+1:]]
        reserve=sum(min(len(w.split()) for w in windows[id]) for id in remaining_ids)
        choices=[w for w in windows[record["id"]] if used+len(w.split())+reserve<=max_words]
        if not choices:raise ValueError("No source-preserving allocation fits original total words")
        winner=max(choices,key=score);selected[record["id"]].append(winner)
        covered.update(components(winner));used+=len(winner.split())
    while sum(len(v) for v in selected.values())<max_count:
        choices=[(r["id"],w) for r in reference for w in windows[r["id"]]
                 if w not in selected[r["id"]] and used+len(w.split())<=max_words]
        if not choices:break
        id,w=max(choices,key=lambda pair:score(pair[1]));selected[id].append(w)
        covered.update(components(w));used+=len(w.split())
    result=deepcopy(reference)
    for record in result:record["passages"]={f"P{i}":w for i,w in enumerate(selected[record["id"]],start=1)}
    return result


def main():
    root=Path("artifacts/question-ledger-20261104");out=root/"global-allocation-offline";out.mkdir(exist_ok=False)
    p=read(root/"component-diagnostic/protocol.json");r=read(Path(p["reference"]["source_result"]))["result"]
    sources=replay_sources(r,r["research_history"][0]);claim=r["claim"]
    _,method=select(claim,sources)
    failed=read(root/"component-diagnostic/glm-questions_ledger/result.json")["decisions"][-1]
    questions=read(root/"glm-runtime-compatible-plans.json")["plans"]["train-1225"]["questions"]
    protocol={"runner_sha256":digest(Path(__file__)),
        "selection_rule":"Reserve one contiguous <=72-word window for every retained source in source order, greedily maximizing novel material dimensions then claim/question/gap overlap. Reserve minimum space for remaining sources. Fill remaining total passage/word allowance by same stable ranking. No source removed. Stride56 unchanged.",
        "actual_resource_change":"Same total selected-passage count and words or fewer; same source inventory. Per-source max2 is replaced by global allocation and can be exceeded. This is an explicit allocation intervention, not a same-per-source result.",
        "reference_budget":{"sources":len(method),"passages":sum(len(s["passages"]) for s in method),"words":sum(len(w.split()) for s in method for w in s["passages"].values())},
        "screen":"Inspect exact historic monetary valuation, original identity role, conversion, independent reported replication and explicit method; retain adverse/qualifying text. No cue-only efficacy claim; existing semantic gates unchanged. No service sends.",
        "prior_negative":"V1 did not add needed dated evidence; V2 added dated valuation but traded away the only former-mayor passage. Both failures are retained.",
        "development_only":True}
    save(out/"protocol.json",protocol)
    revised=allocate(claim,sources,method,[*questions,*failed["gaps"]])
    full={s.url:s.retrieved_text for s in sources}
    assert [s["url"] for s in revised]==[s["url"] for s in method]
    assert all(w in full[s["url"]] and len(w.split())<=72 for s in revised for w in s["passages"].values())
    save(out/"results.json",{"protocol_sha256":digest(out/"protocol.json"),"records":revised,
        "source_count":len(revised),"passage_count":sum(len(s["passages"]) for s in revised),
        "word_count":sum(len(w.split()) for s in revised for w in s["passages"].values()),
        "per_source_passage_counts":{s["id"]:len(s["passages"]) for s in revised},
        "live_sends":0,"workflow_release":False})
    for s in revised:
        if s["id"]=="S2":print(s["passages"])


if __name__=="__main__":main()
