"""Offline revision: distinguish dated monetary estimates from population counts."""
from __future__ import annotations

from pathlib import Path
import re

import gap_passage_selection as prior
from flash_study import read,save,digest
from flash_method_windows import select
from kaji_langgraph.study_analysis import replay_sources


def dimensions(text):
    cues=base_dimensions(text)
    cues.discard("dated_value")
    monetary=bool(re.search(r"\$\s*[\d.]|\b(?:dollars|USD|billion in (?:wealth|net worth))\b",text,re.I))
    dated=bool(re.search(r"\b(?:19|20)\d\d\b|\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d",text,re.I))
    if monetary and dated:cues.add("dated_monetary_value")
    return cues


def main():
    root=Path("artifacts/question-ledger-20261104");out=root/"gap-selection-offline-v2";out.mkdir(exist_ok=False)
    p=read(root/"component-diagnostic/protocol.json")
    r=read(Path(p["reference"]["source_result"]))["result"]
    sources=replay_sources(r,r["research_history"][0]);claim=r["claim"]
    failed=read(root/"component-diagnostic/glm-questions_ledger/result.json")["decisions"][-1]
    questions=read(root/"glm-runtime-compatible-plans.json")["plans"]["train-1225"]["questions"]
    protocol={"runner_sha256":digest(Path(__file__)),"prior_runner_sha256":digest(Path(prior.__file__)),
        "change":"Replace dated_value cue (which incorrectly combined a date with a count of people) with dated_monetary_value requiring explicit currency notation. All other scoring, tie-breaks, source order and 2x72-word/56-stride ceilings unchanged. This still detects exposure only, not entailment.",
        "diagnosed_failure":"V1 S2 kept the debate quote because 125 million people was treated as a dated wealth value. No missing dated valuation or calculation exposure followed.",
        "post_hoc_development_revision":True,"new_live_calls":0,
        "screen":"Inspect literal dated monetary valuation, conversion and replication passages, retain contrary qualifications. No gold labels/answer-specific constants used; no efficacy or workflow release from exposure."}
    save(out/"protocol.json",protocol)
    prior.dimensions=dimensions
    revised=prior.gap_records(claim,sources,questions,failed["gaps"])
    _,method=select(claim,sources)
    save(out/"results.json",{"protocol_sha256":digest(out/"protocol.json"),"method_records":method,
        "gap_directed_records":revised,"source_count":len(revised),
        "passage_count":sum(len(r["passages"]) for r in revised),
        "word_count":sum(len(w.split()) for r in revised for w in r["passages"].values()),
        "workflow_release":False,"live_sends":0})
    print(next(s["passages"] for s in revised if s["id"]=="S2"))


base_dimensions=prior.dimensions


if __name__=="__main__":main()
