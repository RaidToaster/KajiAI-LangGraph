$ErrorActionPreference = 'Stop'
$env:OMP_NUM_THREADS='2'
$env:MKL_NUM_THREADS='2'
$env:OPENBLAS_NUM_THREADS='2'
$env:NUMEXPR_NUM_THREADS='2'
$env:PYTHONUTF8='1'
$env:OLLAMA_HOST='127.0.0.1:11434'
$taskHelper = Start-Process -FilePath 'C:\Users\Axioo Pongo\AppData\Local\Programs\Ollama\ollama.exe' -ArgumentList 'serve' -WindowStyle Hidden -PassThru -RedirectStandardOutput 'artifacts/question-ledger-20261104/ollama-live-stdout.log' -RedirectStandardError 'artifacts/question-ledger-20261104/ollama-live-stderr.log'
try {
    $taskReady=$false
    for ($taskCheck=0; $taskCheck -lt 30; $taskCheck++) {
        try {
            $taskVersion=Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/version' -TimeoutSec 2 -NoProxy
            $taskReady=$true
            break
        } catch { Start-Sleep -Milliseconds 250 }
    }
    if (-not $taskReady) { throw 'Loopback helper unavailable; no diagnostic dispatched' }
    $taskVersion | ConvertTo-Json | Set-Content -LiteralPath 'artifacts/question-ledger-20261104/ollama-version.json'
    & .venv/Scripts/python.exe evaluation/flash_question_ledger.py artifacts/question-ledger-20261104 --limit 1
    if ($LASTEXITCODE -ne 0) { throw "Diagnostic stopped with code $LASTEXITCODE; inspect retained records" }
} finally {
    if (-not $taskHelper.HasExited) { Stop-Process -Id $taskHelper.Id }
}
