"""Offline raw-response recount of the question/ledger investigation."""
from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path,PurePosixPath
import zipfile

from flash_study import read,save,digest,scan


def frozen_source_digest(path):
    with zipfile.ZipFile(path) as archive:
        names=sorted(n for n in archive.namelist() if PurePosixPath(n).parent==PurePosixPath("src/kaji_langgraph") and n.endswith(".py"))
        h=hashlib.sha256()
        for name in names:h.update(PurePosixPath(name).name.encode());h.update(archive.read(name))
    return h.hexdigest()


def recount(root):
    totals=Counter();by_model=Counter();rows=[]
    for path in sorted(root.rglob("usage.json")):
        if any(part.startswith("pytest") for part in path.relative_to(root).parts[:-1]):continue
        d=path.parent;requests=[read(p) for p in sorted(d.glob("request-*.json"))]
        model=next((r["request"]["body"]["model"] for r in requests if r["service"]=="ollama"),"")
        rebuilt=scan(d,model)
        assert rebuilt==read(path),f"Usage mismatch: {path}"
        state=read(d/"live-state.json");counts=Counter(s["service"] for s in rebuilt)
        assert all(counts[k]==v for k,v in state["counts"].items())
        assert read(d/"job.json")["hard_stop"] is False
        for s in rebuilt:
            assert s["status"]==200 and not s.get("transport_error") and not s.get("accounting_error") and s.get("model_verified") is True and not s.get("incomplete")
            totals[s["service"]]+=1
            for key in ("input_tokens","output_tokens"):totals[s["service"]+"_"+key]+=s.get(key,0)
            if s["service"]=="ollama":by_model[s["requested_model"]]+=1
        rows.append({"directory":d.as_posix(),"sends":rebuilt,"result_sha256":digest(d/"result.json")})
    # No request can be hidden merely by omitting usage.json.
    directories={p.parent for p in root.rglob("request-*.json") if not any(part.startswith("pytest") for part in p.relative_to(root).parts[:-1])}
    assert directories=={Path(row["directory"]) for row in rows}
    freezes=[]
    for phase in (root,root/"component-diagnostic",root/"allocation-diagnostic"):
        p=read(phase/"protocol.json")
        expected=p.get("source_sha256")
        if expected:
            actual=frozen_source_digest(phase/"source.zip")
            assert actual==expected
            freezes.append({"phase":phase.as_posix(),"archived_source_matches":True,"source_sha256":actual})
    study=Path("artifacts/flash-workflow-20261103")
    manifest=read(study/"final-case-manifest.json")
    assert digest(study/"final-cases.json")==manifest["cases_sha256"]
    protected_attempts=[p.as_posix() for p in study.rglob("attempt.json") if any(part in {"final","confirmation"} for part in p.relative_to(study).parts)]
    assert not protected_attempts
    verify=read(study/"manuscript/verification.json")
    assert digest(study/"manuscript/paper.pdf")==verify["paper_sha256"]
    assert digest(study/"manuscript/paper.tex")==verify["source_sha256"]
    costs=Counter()
    for row in rows:
        for s in row["sends"]:
            if s["service"]=="ollama":
                inp,out=(.15,.5) if s["requested_model"].startswith("glm") else (.3,1.2)
                costs["ollama_estimated_usd"]+=(inp*s["input_tokens"]+out*s["output_tokens"])/1e6
            elif s["service"]=="jev":costs["jev_estimated_usd"]+=s["input_tokens"]*.042/1e6
    return {"scope":"New question/ledger development diagnostics only; not final or confirmation attempts.",
            "totals":dict(totals),"flash_sends_by_requested_model":dict(by_model),"attempt_directories":rows,
            "frozen_sources":freezes,"new_outcome_unknowns":0,
            "estimates_at_retained_historical_list_rates":dict(costs),
            "estimate_caveat":"Uncached estimates at the earlier recorded rates; not current balances, billed amounts, or verified current prices.",
            "final_manifest_digest_matches":True,"final_manifest_n":manifest["n"],"protected_attempts":protected_attempts,
            "all_final_attempts":0,"confirmation_attempts":0,"current_paper_unchanged_from_historical_verification":True,
            "workflow_screen_released":False,"study_complete":False}


if __name__=="__main__":
    root=Path("artifacts/question-ledger-20261104")
    result=recount(root);save(root/"accounting.json",result)
    print(json.dumps({k:v for k,v in result.items() if k not in {"attempt_directories","frozen_sources"}},indent=2))
