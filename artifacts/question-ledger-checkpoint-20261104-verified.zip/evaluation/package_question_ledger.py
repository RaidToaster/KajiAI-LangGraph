"""Build and clean-extraction verify an incomplete development checkpoint."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

from flash_study import read,save,digest,THREADS


def main():
    root=Path("artifacts/question-ledger-20261104")
    archive_path=Path("artifacts/question-ledger-checkpoint-20261104-verified.zip")
    extraction=Path("artifacts/question-ledger-checkpoint-extracted-20261104")
    assert not archive_path.exists() and not extraction.exists(),"Preserve existing checkpoint/extraction"
    files=set()
    for path in root.rglob("*"):
        if not path.is_file():continue
        parts=path.relative_to(root).parts
        if any(p.startswith("pytest") or p=="__pycache__" for p in parts[:-1]):continue
        if path.name in {"checkpoint-manifest.json","checkpoint-package-verification.json"} or path.suffix==".tmp":continue
        files.add(path)
    for directory in (Path("src"),Path("tests")):
        files.update(p for p in directory.rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix in {".py",".yaml",".json"})
    for pattern in ("*.py","*.ps1"):
        files.update(Path("evaluation").glob(pattern))
    files.update(Path(".aris/traces/research-review/2026-11-04_question-ledger").glob("*"))
    for name in ("AGENTS.md","SESSION_HANDOFF.md","CONTINUATION.md","CONTINUE_RESEARCH_PROMPT.md","pyproject.toml"):
        files.add(Path(name))
    study=Path("artifacts/flash-workflow-20261103")
    for name in ("PROTOCOL.md","ORIGINAL_USER_REQUEST.txt","development-cases.json","final-cases.json","final-case-manifest.json","confirmation-cases.json","confirmation.json","method-packet-replay/protocol.json","manuscript/paper.pdf","manuscript/paper.tex","manuscript/verification.json","package-verification-20261104.json"):
        files.add(study/name)
    reference=read(root/"component-diagnostic/protocol.json")["reference"]
    files.update(Path(reference[key]) for key in ("source_result","source_request"))
    assert all(p.is_file() and p.name!=".env" and not any(part in {".git",".venv"} for part in p.parts) for p in files)
    manifest={"scope":"Incomplete development checkpoint, not the requested final study or final reproducibility package.",
              "files":[{"path":p.as_posix(),"sha256":digest(p),"bytes":p.stat().st_size} for p in sorted(files)],
              "historical_source_note":"Per-phase source.zip files preserve earlier freezes; current source includes a later unintegrated quantity prototype.",
              "study_complete":False,"final_attempts":0}
    save(root/"checkpoint-manifest.json",manifest)
    with zipfile.ZipFile(archive_path,"x",zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(files):archive.write(path,path.as_posix())
        archive.write(root/"checkpoint-manifest.json",(root/"checkpoint-manifest.json").as_posix())
    extraction.mkdir()
    with zipfile.ZipFile(archive_path) as archive:archive.extractall(extraction)
    for entry in manifest["files"]:
        target=extraction/entry["path"]
        assert target.stat().st_size==entry["bytes"] and digest(target)==entry["sha256"],entry["path"]
    env={**os.environ,**THREADS,"PYTHONUTF8":"1","PYTHONPATH":str((extraction/"src").resolve())}
    start=time.monotonic()
    with (root/"checkpoint-extracted-recount.log").open("wb") as log:
        result=subprocess.run([sys.executable,"evaluation/recount_question_ledger.py"],cwd=extraction,env=env,
                              timeout=300,stdout=log,stderr=subprocess.STDOUT)
    assert result.returncode==0,"See clean-extraction recount log"
    expected=read(root/"accounting.json")
    actual=read(extraction/root/"accounting.json")
    assert actual==expected,"Extracted recount differs from retained raw-response recount"
    verification={"status":"verified incomplete development checkpoint; goal not achieved",
        "archive":archive_path.as_posix(),"sha256":digest(archive_path),"bytes":archive_path.stat().st_size,
        "manifested_files":len(manifest["files"]),"all_payload_digests_match_clean_extraction":True,
        "extraction_root":extraction.as_posix(),"extracted_recount_equal":True,
        "extracted_recount_seconds":time.monotonic()-start,"recount_process_returncode":result.returncode,
        "actual_new_sends":expected["totals"],"unknown_new_outcomes":0,
        "final_manifest_unchanged":True,"final_attempts":0,"confirmation_attempts":0,
        "historical_pdf_source_hashes_match":True,"study_complete":False}
    save(root/"checkpoint-package-verification.json",verification)
    print(json.dumps(verification,indent=2))


if __name__=="__main__":main()
