"""Freeze a fresh matched evidence-allocation diagnostic; never reopen QL cells."""
from copy import deepcopy
import json
from pathlib import Path
import zipfile

from flash_study import read,save,digest
from kaji_langgraph.evaluation import code_digest


def main():
    root=Path("artifacts/question-ledger-20261104")
    out=root/"allocation-diagnostic";out.mkdir(exist_ok=False)
    old=read(root/"component-diagnostic/protocol.json")
    selected=read(root/"global-allocation-offline/results.json")
    original=old["cases"][-1]["records"]
    new=selected["records"]
    assert [r["url"] for r in original]==[r["url"] for r in new]
    assert sum(len(r["passages"]) for r in original)==sum(len(r["passages"]) for r in new)==11
    assert sum(len(w.split()) for r in original for w in r["passages"].values())==sum(len(w.split()) for r in new for w in r["passages"].values())==654
    schedule=[]
    for model in old["models"]:
        for allocation in ("method","global"):
            id=f"{model}-{allocation}";cell=out/id;cell.mkdir()
            p=deepcopy(old)
            template=deepcopy(next(t for t in old["tasks"] if t["id"]==f"{model}-questions_ledger"))
            before,text=template["request"]["messages"][0]["content"].split("Cases:\n",1)
            inputs=json.loads(text)
            records=original if allocation=="method" else new
            inputs[-1]["records"]=deepcopy(records)
            inputs[-1]["reference_date"]="2020-02-19"
            before += "\nFor every ledger, copy the exact original claim in required_assertions[0] VERBATIM as one component (no prefix or paraphrase). Other rows map distinct material components. An answered question uses an empty unresolved_material_question string, never 'None' or explanatory text in that field; keep explanations in summary. This is a response contract, not permission to erase a gap. Use at most two concise ledger rows per authored target and six for the development anchor. Use at most six narrow anchor findings, with one source/passage each, so every citation fits one Jev review batch. Record a date or origin as not established when it is missing; do not invent one.\n"
            before=before.replace("four on the development anchor","six on the development anchor")
            template["request"]["messages"][0]["content"]=before+"Cases:\n"+json.dumps(inputs,ensure_ascii=False)
            template["id"]=id;template["allocation"]=allocation
            # Keep the legacy arm key so its strict ledger validator applies in both arms.
            template["arm"]="questions_ledger"
            template["request"]["options"]["num_predict"]=6144
            p["num_predict"]=6144;p["cases"][-1]["records"]=deepcopy(records);p["tasks"]=[template]
            p["source_sha256"]=code_digest()
            p["runner_sha256"]=digest(Path("evaluation/flash_component_diagnostic.py"))
            p["selector_sha256"]=digest(Path("evaluation/flash_method_windows.py"))
            p["preparer_sha256"]=digest(Path(__file__))
            p["diagnostic_identity"]="new matched allocation diagnostic; not a continuation or retry of closed component diagnostic"
            p["release_prerequisite"]=[
                "Both arms parse without repair. The global arm must be correctly gate eligible on the development anchor, at High confidence, with complete whole-claim coverage and all citations/provenance/qualifications passing separate passage-level audit.",
                "The concurrent method arm must be substantively ineligible; no gain solely from formatting is credited. All authored controls must preserve correct targets, supported attribution and material uncertainty; no unsupported acceptance or invented evidence.",
                "After the GLM pair, stop if its substantive prerequisite fails; leave both new DeepSeek cells untouched. Advance to DeepSeek only with a recorded positive GLM passage/support audit. A candidate needs both-model gains before the 68 workflow attempts.",
                "No removed findings, post hoc quote repair, confidence forcing, threshold changes or resumed closed cells. Retain every started failure; no retry. Zero live retrieval; this is an allocation/evidence-use diagnostic, not discovery or workflow efficacy."]
            p["planned_maximum_sends"]={"ollama":1,"jev":2,"search":0,"fetch":0}
            p["estimate"]={"input_tokens_estimate":4500,"requested_output_tokens":6144,"jev_input_tokens_estimate":6000,"jev_output_tokens_estimate":300,"not_a_balance_or_bill":True}
            save(cell/"protocol.json",p)
            save(cell/"receipt.json",{"protocol_sha256":digest(cell/"protocol.json"),"scope":"One new matched-allocation cell; one Flash +at most2 Jev, no retrieval or retries. Separate new phase under continuing user low-risk authorization. Existing credits only.","scientific_premise":"Offline global allocation restores dated historical monetary value and retains identity/conversion/reported replication at identical total source/passage/word ceilings. Per-source allocation explicitly changes. Prior QL candidate remains closed."})
            schedule.append({"id":id,"directory":cell.as_posix(),"protocol_sha256":digest(cell/"protocol.json")})
    protocol={"stage":"new_matched_allocation_diagnostic","source_sha256":code_digest(),"schedule":schedule,
        "planned_maximum_sends":{"ollama":4,"jev":8,"search":0,"fetch":0},
        "total_investigation_maximum_including_completed":{"ollama":9,"jev":10,"search":0,"fetch":0},
        "actual_completed_before_this_phase":{"ollama":5,"jev":2,"search":0,"fetch":0},
        "resources":"One worker, two numerical threads, 300s/job; 6144 requested output tokens/cell; no retries or replacements. Same generation settings across matched allocation arms.",
        "frozen_guards":"Unchanged. Only a both-model substantive pass with correct controls and passage support can release the conditionally authorized 68 required workflow attempts.",
        "stop":"Inspect each cell. After GLM pair, a failed global-acceptance/gain/support prerequisite closes this phase and leaves DeepSeek untouched. Do not spend more to format-rescue or force High.",
        "selection_files":{path:digest(Path(path)) for path in ("evaluation/global_component_selection.py","evaluation/gap_passage_selection_v2.py","evaluation/gap_passage_selection.py")}}
    save(out/"protocol.json",protocol)
    with zipfile.ZipFile(out/"source.zip","w",zipfile.ZIP_DEFLATED) as archive:
        for folder in (Path("src"),Path("tests")):
            for path in folder.rglob("*.py"):archive.write(path,path.as_posix())
        for file in [__file__,"evaluation/flash_component_diagnostic.py",*protocol["selection_files"]]:archive.write(file,Path(file).as_posix())


if __name__=="__main__":main()
