"""One Jev request: falsify a typed objection/cohort review mechanism.

It is advisory. It never edits an assessment, clears gaps, or accepts a claim.
"""
from __future__ import annotations

import argparse
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from flash_study import THREADS,read,save,digest,scan
from kaji_langgraph.jev import JevClient
from runtime_pilot import Ledger,load_keys,transport


def build_questions(cases):
    questions={}
    for i,_ in enumerate(cases):
        context=f"For cases[{i}], use only that case's claim, objection, and supplied records. "
        questions[f"basis_{i}"]={"type":"choice","instructions":context+
            "Is the objection's factual description consistent with the records? Keep population, metric and dates distinct; an objection's relevance is a separate question.",
            "criteria":{"consistent":"The records support the objection's description of what is given, missing or different.",
                        "inconsistent":"The objection misstates, conflates or contradicts the records, including a different population, date or measurement.",
                        "unclear":"The supplied records do not determine whether the objection's factual description is accurate."}}
        questions[f"material_{i}"]={"type":"noul","instructions":context+
            "Does this objection identify a currently unresolved MATERIAL issue preventing the original claim from being established as worded by these records? Do not require proof of embedded content to establish speech attribution. A difference irrelevant to a stated inequality is not by itself material, but uncertain data comparability, population/time scope, causal identification and source independence may be material. An objection contradicted by the records does not itself establish an unresolved question. Do not judge by the proposed label, and never assume that an advisory check can authorize acceptance.",
            "criteria":{"true":"A material original-claim component remains unsupported or uncertain for the concrete reason stated.",
                        "false":"The supplied evidence already answers the objection, its premise is contradicted, or the concern cannot change the claimed relation under the explicitly comparable given measurements."}}
    return questions


def prepare(out):
    root=Path("artifacts/question-ledger-20261104")
    def case(id,claim,objection,text,basis,material):
        return {"id":id,"claim":claim,"objection":objection,"records":[{"id":"T1","text":text}],
                "expected_basis":basis,"expected_material":material,"authored":True}
    cases=[
        case("speech","Mayor Imani said unemployment fell 20%.","The unemployment statistic was not independently verified.","Independent recordings A and B both contain Mayor Imani saying unemployment fell 20%. Neither recording verifies unemployment data.","consistent",False),
        case("embedded","Unemployment fell 20%.","The unemployment statistic was not independently verified.","Independent recordings A and B both contain Mayor Imani saying unemployment fell 20%. Neither recording verifies unemployment data.","consistent",True),
        case("inequality","Firm A had more net assets than group B in 2020.","Two verified comparable group B totals differ.","For the same date, population, USD net-asset measure and fully verified inputs: A=64.2 billion. Independent methods report B=6 billion and B=11.4 billion. For this authored control, these two estimates cover the stipulated alternatives; no additional input uncertainty is at issue.","consistent",False),
        case("threshold_crossing","Firm A had more net assets than group B in 2020.","Two comparable group B totals differ across A's value.","For the same date, population and USD net-asset measure: A=12 billion. Independent methods report B=11 billion and B=14 billion. Neither alternative has been resolved.","consistent",True),
        case("cohort","The bottom 38% of households had positive combined wealth.","The bottom 38% had negative combined wealth.","The bottom 37% collectively had -44 billion dollars. The 38th percentile held 50 billion. The bottom 38% combined held about +6 billion dollars.","inconsistent",False),
        case("causal","The signal system caused the 15% reduction in delays.","No analysis controls alternative explanations.","A vendor measured a 15% before/after delay change. It did not control traffic volume, roadworks, seasonality or other changes.","consistent",True),
        case("shared","The vendor's 15% reduction was independently verified.","The second story only repeats the original vendor figures.","Outlet B states it repeats the vendor's figures and did not collect or independently verify measurements.","consistent",True),
        case("date_mismatch","The official's wealth was 64.2 billion in February 2020.","The valuation is for a different period.","The supplied valuation of 64.2 billion is explicitly dated February 2025. No 2020 value is provided.","consistent",True),
        case("date_given","The official's wealth was 64.2 billion in February 2020.","The supplied date is February 2020.","The source reports the official's net worth was 64.2 billion at the February 19, 2020 event and lists its valuation-source access date as February 19, 2020.","consistent",False),
        case("population_proxy","The poorest 125 million individual residents held less wealth than A.","The population was estimated from household averages rather than ranked individuals.","The study ranks households and multiplies their number by citywide average household size. It does not observe individual wealth ranking or household size by wealth group.","consistent",True),
    ]
    p=read(root/"allocation-diagnostic/glm-global/protocol.json")
    r=read(root/"allocation-diagnostic/glm-global/glm-global/result.json")["decisions"][-1]
    for i,gap in enumerate(r["gaps"]):
        cases.append({"id":f"observed_gap_{i}","claim":p["cases"][-1]["claim"],"objection":gap,
                      "records":p["cases"][-1]["records"],"authored":False})
    out.mkdir(exist_ok=False)
    state_cases=[{k:v for k,v in c.items() if not k.startswith("expected_")} for c in cases]
    protocol={"model":"jev-1.13.0","caps":{"jev":1},"cases":cases,"state":{"cases":state_cases},
              "questions":build_questions(cases),"runner_sha256":digest(Path(__file__)),
              "planned_sends":{"jev":1,"ollama":0,"search":0,"fetch":0},
              "estimate":{"input_tokens":14000,"output_tokens":1600,"not_a_balance_or_bill":True},
              "screen":"All ten authored basis judgments must match and all ten materiality probabilities must be <=0.2 for nonmaterial or >=0.8 for material. The observed cohort-conflation objection must be inconsistent and nonmaterial (<=0.2); other observed objections are exploratory, not gold-scored. Any failed control closes this typed checker as tested. No retries or threshold changes. A pass only permits designing a separate matched advisory-feedback diagnostic, not clearing gaps or releasing 68 workflow attempts.",
              "assurance":"Choice confidence/probability is not semantic truth or workflow correctness. Preserve raw judgments; no gate changes or automatic acceptance.",
              "mechanism_premise":"Observed ledger incorrectly transfers negative bottom37% wealth to bottom38%, and prior outputs block attributed speech on unverified content. Separate narrow factual consistency from unresolved materiality; use advisory feedback only if controlled behavior is adequate.",
              "docs":["https://docs.typesafe.ai/sdk/python","https://docs.typesafe.ai/primitives/choice","https://docs.typesafe.ai/cookbooks/citation_check","https://docs.typesafe.ai/confidence"]}
    save(out/"protocol.json",protocol)
    save(out/"receipt.json",{"protocol_sha256":digest(out/"protocol.json"),"scope":"One Jev 1.13.0 request,26 typed judgments, no Flash or retrieval, no retry. Existing credits only, one worker/two threads/300s. New falsification diagnostic, not a resumed closed attempt.","authorization":"Continued low-risk targeted work. No 68-workflow release."})


def worker(out,p):
    import httpx2
    from typesafe_sdk import TypeSafeClient,RetryPolicy
    import kaji_langgraph.jev as jm
    load_keys();ledger=Ledger(out,p);ledger.task="typed-materiality"
    def client(**kwargs):return TypeSafeClient(**kwargs,retry=RetryPolicy(max_retries=0),http_client=httpx2.Client(
        transport=transport(httpx2,ledger,"jev"),timeout=30,follow_redirects=False))
    jm.TypeSafeClient=client
    answers,tokens=JevClient(model="jev-1.13.0")._ask(p["state"],p["questions"],timeout=30)
    rows=[]
    for i,c in enumerate(p["cases"]):
        basis,confidence=JevClient._choice(answers[f"basis_{i}"],{"consistent","inconsistent","unclear"})
        material=JevClient._noul(answers[f"material_{i}"])
        passed=None
        if c["authored"]:passed=basis==c["expected_basis"] and (material>=.8 if c["expected_material"] else material<=.2)
        rows.append({"id":c["id"],"basis":basis,"basis_confidence":confidence,"material_probability":material,"control_passed":passed})
    observed=rows[-1]
    pass_controls=all(r["control_passed"] for r in rows if r["control_passed"] is not None)
    cohort_pass=observed["basis"]=="inconsistent" and observed["material_probability"]<=.2
    save(out/"result.json",{"answers":answers,"rows":rows,"tokens":tokens,"control_passed":pass_controls,
        "cohort_conflation_detected":cohort_pass,"passed":pass_controls and cohort_pass,
        "automatic_gap_changes":0,"workflow_release":False})


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("directory",type=Path)
    parser.add_argument("--prepare",action="store_true");parser.add_argument("--worker",action="store_true")
    args=parser.parse_args();out=args.directory
    if args.prepare:prepare(out);return
    p=read(out/"protocol.json")
    assert p["runner_sha256"]==digest(Path(__file__))
    assert read(out/"receipt.json")["protocol_sha256"]==digest(out/"protocol.json")
    if args.worker:worker(out,p);return
    assert not (out/"attempt.json").exists(),"Started outcomes are never replaced/retried"
    save(out/"attempt.json",{"started_at":datetime.now(timezone.utc).isoformat(),"protocol_sha256":digest(out/"protocol.json")})
    save(out/"live-state.json",{"counts":{"jev":0},"deadline":time.time()+270,"stop":None})
    start=time.monotonic()
    with (out/"stdout.log").open("wb") as stdout,(out/"stderr.log").open("wb") as stderr:
        try:
            proc=subprocess.run([sys.executable,__file__,str(out),"--worker"],timeout=300,stdout=stdout,stderr=stderr,env={**os.environ,**THREADS,"PYTHONUTF8":"1"});code=proc.returncode
        except subprocess.TimeoutExpired:code=None
    usage=scan(out,"");save(out/"usage.json",usage)
    bad=len(usage)!=read(out/"live-state.json")["counts"]["jev"] or any(s.get("status")!=200 or s.get("transport_error") or s.get("accounting_error") or s.get("model_verified") is not True for s in usage)
    save(out/"job.json",{"exit_code":code,"elapsed_seconds":time.monotonic()-start,"accounting_problem":bad,"hard_stop":bool(code!=0 or bad or read(out/"live-state.json")["stop"])})
    print("STOP" if code!=0 or bad else "DONE")


if __name__=="__main__":main()
