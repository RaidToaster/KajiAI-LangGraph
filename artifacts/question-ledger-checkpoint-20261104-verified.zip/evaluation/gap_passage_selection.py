"""Offline material-dimension selection under the existing passage ceiling.

These lexical cues expose text. They do not resolve the corresponding issue.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import re

from flash_study import read,save,digest
from flash_component_diagnostic import controls
from flash_method_windows import select
from kaji_langgraph.llm import _compact_records
from kaji_langgraph.models import SourceRecord
from kaji_langgraph.study_analysis import replay_sources


def dimensions(text):
    money=bool(re.search(r"\$\s*[\d.]|\b(?:billion|million|percent|minutes|votes)\b",text,re.I))
    date=bool(re.search(r"\b(?:19|20)\d\d\b|\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d",text,re.I))
    cues={
        "quantified_value":money,
        "dated_value":money and date,
        "population_conversion":bool(re.search(r"household|population|sample|citywide",text,re.I) and re.search(r"averag|multipl|people|member|same population|citywide",text,re.I)),
        "calculation_method":bool(re.search(r"sort|summ?ed|added|calculation|Python|raw sample|methodolog",text,re.I)),
        "origin_verification":bool(re.search(r"replicat|independent|own (?:sample|observations|calculations)|audio.record",text,re.I)),
        "adverse_or_limit":bool(re.search(r"\b(?:not|no|rather than|unresolved|discrepancy|confound|didn.t|did not)\b",text,re.I)),
        "attribution":bool(re.search(r"\bsaid|transcript|interview|press release",text,re.I)),
    }
    return {k for k,v in cues.items() if v}


def gap_records(claim,sources,questions,gaps):
    baseline,_=_compact_records(claim,sources)
    mapped={s.url:s for s in sources}
    query=set(re.findall(r"\w{3,}"," ".join([claim,*questions,*gaps]).lower()))
    result=deepcopy(baseline)
    for record in result:
        source=mapped[record["url"]];text=source.retrieved_text
        words=list(re.finditer(r"\S+",text));windows=[]
        for start in range(0,len(words),56):
            windows.append(text[words[start].start():words[min(start+72,len(words))-1].end()])
        windows=list(dict.fromkeys(windows));chosen=[];covered=set()
        for _ in range(min(2,len(windows))):
            def score(window):
                novelty=len(dimensions(window)-covered)
                overlap=len(query.intersection(re.findall(r"\w{3,}",window.lower())))
                return novelty,overlap
            winner=max((w for w in windows if w not in chosen),key=score)
            chosen.append(winner);covered.update(dimensions(winner))
        record["passages"]={f"P{i}":w for i,w in enumerate(chosen,start=1)}
    return result


def main():
    root=Path("artifacts/question-ledger-20261104")
    out=root/"gap-selection-offline";out.mkdir(exist_ok=False)
    p=read(root/"component-diagnostic/protocol.json")
    r=read(Path(p["reference"]["source_result"]))["result"]
    sources=replay_sources(r,r["research_history"][0]);claim=r["claim"]
    failed=read(root/"component-diagnostic/glm-questions_ledger/result.json")["decisions"][-1]
    plan=read(root/"glm-runtime-compatible-plans.json")["plans"]["train-1225"]
    protocol={"runner_sha256":digest(Path(__file__)),"source_result_sha256":digest(Path(p["reference"]["source_result"])),
        "selection_rule":"Same top12 source order, max2 contiguous 72-word windows/source, stride56. Greedily maximize novel lexical material dimensions, then overlap with claim/questions/actual gaps; stable document order ties. Each dimension equally weighted. Same rule for authored adverse/scope controls. No labels or answer-specific names/numbers enter selector.",
        "dimensions":["quantified_value","dated_value","population_conversion","calculation_method","origin_verification","adverse_or_limit","attribution"],
        "screen":"Report actual selected spans, coverage, repeated windows and residual material questions. Need retained historical valuation, conversion, independently reported replication and adverse qualifications under unchanged ceilings; lexical cue gains alone cannot release live model reruns or workflow screens.",
        "scope":"Post hoc gap-directed exposure investigation on retained development evidence and authored controls; no service sends, discovery, gate decisions or efficacy claims."}
    save(out/"protocol.json",protocol)
    original,method=select(claim,sources)
    revised=gap_records(claim,sources,plan["questions"],failed["gaps"])
    arms={"original":original,"method":method,"gap_directed":revised}
    summary={}
    for arm,records in arms.items():
        summary[arm]={"source_count":len(records),"passage_count":sum(len(s["passages"]) for s in records),
                      "word_count":sum(len(w.split()) for s in records for w in s["passages"].values()),
                      "source_dimensions":{s["id"]:sorted(set().union(*(dimensions(w) for w in s["passages"].values()))) for s in records}}
        full={s.url:s.retrieved_text for s in sources}
        assert all(len(s["passages"])<=2 and all(w in full[s["url"]] and len(w.split())<=72 for w in s["passages"].values()) for s in records)
        assert [s["url"] for s in records]==[s["url"] for s in original]
    authored=[]
    for case in controls():
        ss=[]
        for n,record in enumerate(case["records"]):
            text=" ".join(record["passages"].values())
            # Long irrelevant prefix tests whether adverse text stays exposed.
            prefix="Community calendar lists routine office hours and meeting locations. "*18
            text=prefix+text
            ss.append(SourceRecord(url=record["url"],title=record["title"],page_text=text,
                retrieved_at="2026-11-04",content_hash=f"authored-{case['id']}-{n}",query="",provider="authored-offline-control"))
        records=gap_records(case["claim"],ss,[],["Check event date, population, independent origin and contrary evidence."])
        authored.append({"id":case["id"],"records":records,"note":"Authored exposure control, not a real-world source or model decision."})
    save(out/"results.json",{"protocol_sha256":digest(out/"protocol.json"),"summary":summary,"arms":arms,"authored_controls":authored,"live_sends":0,"workflow_release":False})
    print(summary)


if __name__=="__main__":main()
