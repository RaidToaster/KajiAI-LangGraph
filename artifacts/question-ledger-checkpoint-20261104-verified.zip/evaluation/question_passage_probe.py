"""Offline matched-budget passage exposure from retained development text.

Not web discovery, semantic evidence verification, or a workflow outcome.
The word-overlap ranker is fixed before inspecting its results.
"""
from __future__ import annotations

from collections import Counter
import math
from pathlib import Path
import re

from flash_study import digest, read, save
from kaji_langgraph.graph import WorkflowNodes
from kaji_langgraph.llm import DeterministicBackend
from kaji_langgraph.models import EvidenceAssessment
from kaji_langgraph.study_analysis import replay_sources


STOP = set("a an the what was were is are do does did of in on at to for by with and or than that this which how it its as from about have had more less claim evidence".split())


def terms(text):
    return [w for w in re.findall(r"[\w.]+", text.lower()) if w not in STOP]


def main():
    out = Path("artifacts/question-ledger-20261104")
    dest = out / "offline-passage-probe"
    dest.mkdir(exist_ok=False)
    old = Path("artifacts/flash-workflow-20261103/method-packet-replay/protocol.json")
    p = read(old)
    case = next(c for c in p["cases"] if c["id"] == "glm-method")
    retained = read(Path(case["source_result"]))["result"]
    sources = replay_sources(retained, retained["research_history"][0])
    queries = {}
    for mode in ("statements", "glm_questions", "deepseek_questions"):
        plan = None if mode == "statements" else read(out / (mode.split("_")[0]+"-runtime-compatible-plans.json"))["plans"]["train-1225"]
        state = {"claim": retained["claim"], "assertions": retained["assertions"],
                 "policy": {}, "assessment": EvidenceAssessment(), "search_queries": []}
        if plan:
            state.update(assertions=list(dict.fromkeys([retained["claim"], *plan["assertions"]])),
                         verification_questions=plan["questions"])
        queries[mode] = WorkflowNodes(DeterministicBackend(), None, {"jev": {}})._research_queries(state)[:2]
    protocol = {
        "source_result": case["source_result"], "source_result_sha256": digest(Path(case["source_result"])),
        "source_request_sha256": case["source_request_sha256"], "queries": queries,
        "per_arm_query_budget": 2, "passages_per_query": 2, "words_per_passage": 72,
        "window_stride": 56, "all_sources_retained": True,
        "ranking": "Sum IDF * (1+log term frequency) for unique query terms; IDF=log((N+1)/(df+1))+1. Descending, stable source/document order. No semantic model or gold labels.",
        "material_exposure_cues": {
            "net_worth": r"Forbes|64\.2", "aggregate_wealth": r"11\.4|\$6 billion",
            "population_conversion": r"2\.63|47\.8|125\.7",
            "separate_calculation": r"replicat|Gross", "data_year": r"2016|2019",
            "former_mayor": r"former mayor"},
        "cues_note": "Presence only. Cues do not establish sufficiency, independence, causal support, or truth.",
        "scope": "Post hoc development-only fixed corpus; measures selected passage exposure. Zero live retrieval on all arms, no discovery/acceptance effect claim.",
        "runner_sha256": digest(Path(__file__))}
    save(dest / "protocol.json", protocol)
    windows = []
    for source in sources:
        text = source.retrieved_text
        words = list(re.finditer(r"\S+", text))
        for start in range(0, len(words), 56):
            begin, end = words[start].start(), words[min(start+72,len(words))-1].end()
            passage = text[begin:end]
            windows.append({"url": source.url, "source_hash": source.content_hash,
                            "quote": passage, "quote_start": begin, "quote_end": end,
                            "counts": Counter(terms(passage))})
    frequencies = Counter(w for row in windows for w in row["counts"])
    results = {}
    for mode, qs in queries.items():
        selected = []
        for query in qs:
            qterms = set(terms(query))
            def score(row):
                return sum((math.log((len(windows)+1)/(frequencies[w]+1))+1)
                           * (1+math.log(row["counts"][w])) for w in qterms if row["counts"][w])
            ranked = sorted(windows,key=score,reverse=True)[:2]
            selected.extend({k:v for k,v in row.items() if k != "counts"} | {"query":query,"score":score(row)} for row in ranked)
        cues = {name: any(re.search(pattern,row["quote"],re.I) for row in selected)
                for name,pattern in protocol["material_exposure_cues"].items()}
        results[mode] = {"queries":qs,"selected":selected,"cue_presence":cues,
                         "distinct_sources":len({r["url"] for r in selected}),
                         "distinct_passages":len({(r["url"],r["quote_start"]) for r in selected})}
    save(dest / "results.json", {"source_count":len(sources),"window_count":len(windows),
                                  "protocol_sha256":digest(dest/"protocol.json"),"arms":results})
    print({k:v["cue_presence"] for k,v in results.items()})


if __name__ == "__main__":
    main()
