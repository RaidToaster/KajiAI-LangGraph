"""Retained-text audit of concrete QL failure gaps; no service requests."""
from __future__ import annotations

from pathlib import Path
import re

from flash_study import digest,read,save
from kaji_langgraph.study_analysis import replay_sources


def excerpt(source, pattern, before=100, after=650):
    match=re.search(pattern,source.retrieved_text,re.I)
    if not match:
        return {"found":False,"pattern":pattern}
    text=source.retrieved_text
    start=max(0,match.start()-before);end=min(len(text),match.end()+after)
    return {"found":True,"source_url":source.url,"source_hash":source.content_hash,
            "quote":text[start:end],"quote_start":start,"quote_end":end,
            "scope":"Literal retained passage; semantic interpretation recorded separately."}


def main():
    root=Path("artifacts/question-ledger-20261104")
    p=read(root/"component-diagnostic/protocol.json")
    r=read(Path(p["reference"]["source_result"]))["result"]
    sources=replay_sources(r,r["research_history"][0])
    source=next(s for s in sources if "politifact.com" in s.url)
    passages={
        "historical_forbes_estimate":excerpt(source,r"Bloomberg.s net worth, as listed"),
        "forbes_access_date":excerpt(source,r'Forbes, .Real Time Billionaires'),
        "calculation_method":excerpt(source,r"When we contacted Bruenig",after=1100),
        "population_conversion":excerpt(source,r"Then, he determined",after=550),
        "replication_detail":excerpt(source,r"Matthew Gross",after=1400),
    }
    # These are explicitly sourced reported estimates, not an uncertainty model.
    bounds={"left_reported_estimate_billion_usd":64.2,"right_reported_estimates_billion_usd":[6.0,11.4],
            "strict_inequality_holds_for_each_reported_estimate":all(64.2>x for x in (6.,11.4)),
            "smallest_reported_estimate_margin_billion_usd":64.2-max(6.,11.4),
            "status":"Conditional two-estimate sensitivity check; not a confidence interval, exhaustive bound, or independent verification of inputs.",
            "unresolved_assumptions":["Historical applicability and reliability of the underlying estimates.",
                "Household ranking and average size conversion adequately represent the claimed bottom 125 million people.",
                "Meaningful independence of calculation/measurement paths, including shared Forbes and SCF inputs."]}
    audit={"source_result":p["reference"]["source_result"],"source_result_sha256":digest(Path(p["reference"]["source_result"])),
        "source_url":source.url,"source_hash":source.content_hash,"passages":passages,
        "gap_mapping":[
            {"gap":"Historical Forbes date/value not visible in sent method windows.","evidence":"historical_forbes_estimate, forbes_access_date",
             "finding":"The full report dates $64.2B to the Feb.19 debate and lists Forbes accessed Feb.19. This answers what the report attributes to Forbes at that time, without supplying the primary Forbes record.","status":"partial_material_exposure_opportunity"},
            {"gap":"No calculation method in packet.","evidence":"calculation_method, replication_detail",
             "finding":"Full report describes sorting households, summing bottom 38%, using Python and a separately named replication. Additional calculation detail is retained; underlying code/data and cause of the $6B/$11.4B difference are not established by this excerpt.","status":"partial_material_exposure_opportunity"},
            {"gap":"Population conversion uncertain.","evidence":"population_conversion",
             "finding":"The same 47.8M times 2.63 conversion is explicitly described. It is a model-based household-to-person approximation, not a newly measured count of the poorest individuals. Repetition cannot eliminate its uncertainty.","status":"material_assumption_retained"},
            {"gap":"Numerically inconsistent estimates.","evidence":"replication_detail",
             "finding":"The report shows -44B plus 50B equals about 6B and states both reported totals support the inequality. A conditional inequality check can show insensitivity to these two totals; it cannot explain their discrepancy or certify an uncertainty interval.","status":"conditional_robustness_only"},
            {"gap":"SCF vintage 2019.","evidence":"calculation_method",
             "finding":"The sent anchor windows do not state a 2019 survey vintage. That year in GLM's S-arm objection is not established by its input. Do not replace it with another year from memory. Primary dataset/version and its historical availability remain to be verified.","status":"unsupported_generated_specificity_and_missing_primary_metadata"},
        ],"numerical_sensitivity":bounds,
        "control_implications":["An attributed 20% statistic cannot become measured unemployment evidence by arithmetic.",
            "An estimate pair spanning the comparison threshold cannot yield the same robust inequality.",
            "A 15% observed change does not establish causation or independence when both stories share a vendor origin.",
            "Dates and population definitions remain material when different measurements refer to different targets."],
        "decision":"Retained text supports offline investigation of gap-directed exposure and numerical sensitivity, but leaves genuine provenance/population/primary-metadata assumptions. Do not rerun or repair the closed QL diagnostic, and do not release 68 workflow attempts on this audit alone.",
        "next_new_evidence_needed":"Verify original dataset identity/vintage and accessible primary historical wealth input or reproducible calculation. Any targeted primary-source acquisition requires a new bounded receipt; no model assessment reruns are justified by this audit alone.",
        "scope":"Post hoc failure diagnosis, not a scored new candidate or proof of study-wide futility."}
    save(root/"gap-directed-offline-audit.json",audit)
    print({"passages_found":{k:v['found'] for k,v in passages.items()},"live_sends":0,"workflow_release":False})


if __name__=="__main__":main()
