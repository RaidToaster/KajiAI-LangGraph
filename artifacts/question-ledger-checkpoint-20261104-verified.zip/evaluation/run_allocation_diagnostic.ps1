$ErrorActionPreference='Stop'
$taskRoot='artifacts/question-ledger-20261104/allocation-diagnostic'
if (Test-Path -LiteralPath "$taskRoot/decision.json") {
    $taskDecision=Get-Content -LiteralPath "$taskRoot/decision.json" -Raw | ConvertFrom-Json
    if ($taskDecision.closed) { throw 'Allocation diagnostic closed; do not resume untouched cells.' }
}
$taskProtocol=Get-Content -LiteralPath "$taskRoot/protocol.json" -Raw | ConvertFrom-Json
$taskNext=$null
foreach ($taskCell in $taskProtocol.schedule) {
    $taskAttempt="$($taskCell.directory)/$($taskCell.id)"
    if (Test-Path -LiteralPath "$taskAttempt/attempt.json") {
        if (-not (Test-Path -LiteralPath "$taskAttempt/job.json")) { throw 'Unresolved prior outcome; no retry.' }
        $taskJob=Get-Content -LiteralPath "$taskAttempt/job.json" -Raw | ConvertFrom-Json
        if ($taskJob.hard_stop) { throw 'Retained service/accounting failure; no further sends.' }
    } else { $taskNext=$taskCell; break }
}
if ($null -eq $taskNext) { throw 'All planned attempts already started; do not rerun.' }
if ($taskNext.id.StartsWith('deepseek') -and -not (Test-Path -LiteralPath "$taskRoot/glm-release.json")) { throw 'DeepSeek requires a positive GLM scientific/support audit first.' }
$env:OMP_NUM_THREADS='2'; $env:MKL_NUM_THREADS='2'; $env:OPENBLAS_NUM_THREADS='2'; $env:NUMEXPR_NUM_THREADS='2'; $env:PYTHONUTF8='1'; $env:OLLAMA_HOST='127.0.0.1:11434'
$taskSuffix=Get-Date -Format 'yyyyMMdd_HHmmss'
$taskHelper=Start-Process -FilePath 'C:\Users\Axioo Pongo\AppData\Local\Programs\Ollama\ollama.exe' -ArgumentList 'serve' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$taskRoot/ollama-$taskSuffix-stdout.log" -RedirectStandardError "$taskRoot/ollama-$taskSuffix-stderr.log"
try {
    $taskReady=$false
    for ($taskCheck=0; $taskCheck -lt 30; $taskCheck++) {
        try { $taskVersion=Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/version' -NoProxy -TimeoutSec 2; $taskReady=$true; break }
        catch { Start-Sleep -Milliseconds 250 }
    }
    if (-not $taskReady) { throw 'No helper; no diagnostic dispatched.' }
    $taskVersion | ConvertTo-Json | Set-Content -LiteralPath "$taskRoot/ollama-version-$taskSuffix.json"
    & .venv/Scripts/python.exe evaluation/flash_component_diagnostic.py $taskNext.directory --limit 1
    if ($LASTEXITCODE -ne 0) { throw "Retained worker failure, code $LASTEXITCODE; inspect records." }
} finally { if (-not $taskHelper.HasExited) { Stop-Process -Id $taskHelper.Id } }
